class Course {
  constructor(id, name, price, likes, rating, imageUrl) {
    this.id = id;
    this.name = name;
    this.price = price;
    this.likes = likes;
    this.rating = rating;
    this.imageUrl = imageUrl;
  }
}
// Data will be arriving from a server !
let listOfCourses = [
  new Course(
    1,
    "React",
    4000,
    200,
    4,
    "https://miro.medium.com/max/3840/1*yjH3SiDaVWtpBX0g_2q68g.png"
  ),
];

for (const course of listOfCourses) {
  DisplayCourse(course);
}

function DisplayCourse(course) {
  let courseCard = document.createElement("div");
  courseCard.className = "course-card";
  // courseCard.style.border = "1px solid lightgrey"; // bad practise
  // courseCard.setAttribute("class", "course-card");

  let cardHeaderTitle = document.createElement("h2");
  cardHeaderTitle.innerText = course.name;

  let cardHeaderDeleteBtn = document.createElement("button");
  cardHeaderDeleteBtn.setAttribute("style", "height:3em;width:3em");

  cardHeaderDeleteBtn.addEventListener("click", function () {
    confirm("Are you sure ?");
  });

  let deleteGlyphIcon = document.createElement("i");
  deleteGlyphIcon.className = "fas fa-trash";

  cardHeaderDeleteBtn.appendChild(deleteGlyphIcon);

  let cardHeader = document.createElement("div");
 
  cardHeader.className = "card-header";
  cardHeader.appendChild(cardHeaderTitle);
  cardHeader.appendChild(cardHeaderDeleteBtn);

  courseCard.appendChild(cardHeader);
  var container = document.querySelector(".container");
  container.appendChild(courseCard);
}
