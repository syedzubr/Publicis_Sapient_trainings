var EventEmitter = require("events");
// Publisher
function IterationCount(maxIteration) {
  var e = new EventEmitter();
  // Biz Logic !
  let count = 0;
  let timerId = setInterval(function () {
    if (count == 0) {
      e.emit("start"); // emit the event [data]
    }
    e.emit("count", ++count); // emit the event [data]
    if (count == maxIteration) {
      e.emit("finish", count);
      clearInterval(timerId);
    }
    if (count == 8) {
      e.emit("error", count);
      clearInterval(timerId);
    }
  }, 1000);
  return e;
}

// Subscriber
let evtEmtr = IterationCount(10); // returns EventEmitter instance
evtEmtr.on("count", function (currCount) {
  console.log("Current count is : " + currCount);
});

evtEmtr.on("finish", function (currCount) {
  console.log("Done Iteration with last count : " + currCount);
});

evtEmtr.on("error", function (currCount) {
  console.log("Error Encounter with last count : " + currCount);
});

console.log("Program Ended !");
