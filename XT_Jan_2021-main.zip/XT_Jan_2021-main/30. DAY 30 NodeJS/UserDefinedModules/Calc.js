var MathModule = require("./Math");
console.log(MathModule.Addition(20, 30));
