//let x = 100; // Type inference
// x = "Hello";
var x; // Type annotation
var booleanVar;
var str;
var o;
var i;
i = "Anytype";
i = 100;
i = true;
i = { name: 'any' };
console.log(typeof i);
// functions
function Add(x, y) {
    if (x > 0) {
        return x + y;
    }
    else {
        return "X should be greater than 0";
    }
}
//Add();
var result = Add(10, 20);
console.log('The result is : ' + result);
// optional parameters
// function PrintBooks(author: string, title?: string) {
// }
// PrintBooks('Ranjit Desai', "Mrutyunjay");
// Default paramters
// function PrintBooks(author: string = "Unknown", title: string = "Unknown") {
//     console.log(author, title)
// }
// PrintBooks();
// PrintBooks('Ranjit Desai', "Mrutyunjay");
function PrintBooks(author) {
    if (author === void 0) { author = "Unknown"; }
    var titles = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        titles[_i - 1] = arguments[_i];
    }
    console.log(author, titles);
}
PrintBooks();
PrintBooks('Ranjit Desai', "Mrutyunjay", "Chava", "Radhey");
// Arrays
var strArray = ['HTML5', 'CSS3', 'Typescript'];
// OR
// (Generics)
var strArrayGen = new Array();
