let userList = [];
function GetUserData() {
  // xmlhttpreq
  // fetch

  var xmlhttpReq = new XMLHttpRequest();
  xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/users");
  xmlhttpReq.send(); // make an ajax request
  xmlhttpReq.onreadystatechange = function () {
    if (xmlhttpReq.readyState == 4 && xmlhttpReq.status === 200) {
      userList = JSON.parse(xmlhttpReq.responseText);
      AddUserToList();
    }
  };
}

function AddUserToList() {
  // if user exists then add it to the list
  // else display an error message

  let txtUsername = document.querySelector("#txtUsername").value;

  let theUser = userList.find((user) => user.username === txtUsername);
  if (theUser) {
    // add to the lists
    let ul_users = document.querySelector(".userslistfromjph");
    let newUserLi = document.createElement("li");
    newUserLi.setAttribute("id", theUser.id);
    newUserLi.addEventListener("click", ShowUserDetails);
    newUserLi.append(theUser.name);
    ul_users.appendChild(newUserLi);
  } else {
    document.querySelector(".errorMsg").innerHTML = "Invalid User ";
  }
}

function ShowUserDetails(e = event) {
  console.log(e.target.id);
}
