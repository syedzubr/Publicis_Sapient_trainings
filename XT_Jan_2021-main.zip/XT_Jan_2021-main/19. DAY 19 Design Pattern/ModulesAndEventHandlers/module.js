export function CalledOnLoad() {
  console.log("CalledOnLoad !");
}
export function CalledOnDOMLoaded() {
  console.log("CalledOnDOMLoaded !");
}
