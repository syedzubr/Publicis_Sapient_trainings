gb="";
async function getData(){
    // let response = await fetch('https://jsonplaceholder.typicode.com/users');
    let response = await fetch('https://inventorydb-3f0f.restdb.io/rest/userunits', {
      headers: {
        "x-apikey": "6025d7df5ad3610fb5bb5f06",
        "content-type": "application/json",
      },
    });


    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    } else {
      return await response.json();
    }
}

  
getData().then((res) => {
console.log(res);   // the data fetched form the url gets printed here
gb = res;

allUsers = [];
for(let i of res){
  let found = allUsers.find(user => user.username == i.username)
  if( !found )
      allUsers.push(i)
}
console.log('------');
// console.log(allUsers);

for(let users of allUsers){

    let div1 = document.createElement('div');
    div1.className = "name";
    div1.append(users.username);

    let div2 = document.createElement('div');
    div2.className = "gmail-id";
    div2.append(users.email);   
    
    let div = document.createElement('div');
    div.className = "users-gmail";
    div.append(div1,div2);
    div.addEventListener('click', getResources);

    let mainDiv = document.querySelector('.users-contacts');
    mainDiv.appendChild(div);
}
})
.catch((e) =>
console.log(e)
);

function notSubmit(){
  event.preventDefault();
}

let editButton = document.querySelector('.fa-pen');
editButton.addEventListener('click',formPopUp);

function formPopUp(){
  let right = document.querySelector(".right-popup");
  right.classList.add("display-none");

  let formpop = document.querySelector(".form-popup");
  formpop.classList.remove("display-none");
}


let closeButton = document.querySelector('.popup-header-left-form>button');
closeButton.addEventListener('click',formClose);

function formClose(){
  let right = document.querySelector(".form-popup");
  right.classList.add("display-none");

  let formpop = document.querySelector(".right-popup");
  formpop.classList.remove("display-none");
}

function getResources(e) {
  let parentUsers = e.target;
  if(e.target.className == "name" || e.target.className=="gmail-id")
      parentUsers = e.target.parentNode;
  // console.log(parentUsers.children[0]);
  let userContact = document.querySelectorAll('.user-contact-id');
  // console.log(userContact[0].inner);
  userContact[0].innerText = parentUsers.children[1].innerText;
  // userContact[1].innerText = parentUsers.children[1].innerText;
  // let skype = parentUsers.children[0].innerText;
    let mail = parentUsers.children[1].innerText;
    // console.log(skype);
    console.log(mail);
    console.log("---------");

    
    let mainRow = document.querySelector('.main-data-after-header');
    mainRow.innerHTML="";
    // console.log(skype);
    console.log("syeeddd-------");
    // console.log(typeof(skype));
    for(let i of gb){
        // console.log(i.skype);
        if( i.email ==  mail){
            // console.log("hey");
            skype = i.skype;
            let div1 = document.createElement('div');

            let div2 = document.createElement('div');
            // let icon = icons("Monitor");
            div2.append(i.type);
            // document.write(icon);

            let div3 = document.createElement('div');
            div3.append(i.serial);

            let div4 = document.createElement('div');
            div4.append(i.name);

            let div5 = document.createElement('div');
            div5.append(i.from);

            let div = document.createElement('div');
            div.className = "row";
            div.append(div1, div2, div3, div4, div5);
            div.addEventListener("click",formUpdate);
            
            mainRow.append(div);
        }
    }
    userContact[1].innerText = skype;
}

function formUpdate() {
  e = event;
  // console.log(event.target);
  let parentRow = e.target;
  if(e.target.className != "row")
      parentRow = e.target.parentNode;

  console.log(parentRow.children[1].innerText);
  let serial = document.querySelector(".popup-header-left>span");
  let typeSerial = parentRow.children[1].innerText +" "+ parentRow.children[2].innerText;
  serial.innerText = typeSerial;

  serial = document.querySelector(".popup-header-left-form>span")
  serial.innerText = typeSerial;

  formRow = parentRow;   // making global to access in editusersubmit();
}

function editUserSubmit(){

    let serial = document.getElementById('txtSerial');
    let userName = document.getElementById('txtName');
    let dateFrom = document.getElementById('txtFrom');

    formRow.children[2].innerText = serial.value;
    formRow.children[3].innerText = userName.value;
    formRow.children[4].innerText = dateFrom.value;

  frm = document.getElementById('editForm');
  event.preventDefault();
  frm.reset();  
  // return false; 
    
}

/* function icons(type){
  switch(type){
    case 'Monitor': 
      return  "<i class='fas fa-desktop'></i>} ";
    case 'Cable': 
      return  '<i class="fas fa-vector-square"></i>';
    case 'Chasis': 
      return  '<i class="fas fa-microchip"></i>';
    case 'Monitor': 
      return  '<i class="fas fa-memory"></i>';
    default:
      return '';
  }
} */