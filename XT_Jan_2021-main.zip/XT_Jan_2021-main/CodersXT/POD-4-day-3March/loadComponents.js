import {
    navHandler,
    navToDashboard,
    navToUsers,
    navToReports,
    // navToSettings
    toggleDropdown

} from "../navHandler.js"
import {
    getUserName
} from "../utility.js";
import{
    logOut
} from "../logOut.js";
export function loadComponents(){
    $('header').load('../header.html', function () {
        const navButton = document.querySelector('.nav-button');
        navButton.addEventListener('click', navHandler);
        getUserName();
    });
    
    $('.menu').load('../nav.html', function () {
        const navDashboard = document.querySelector('.nav-dashboard');
        navDashboard.addEventListener('click', navToDashboard);

        const navUsers = document.querySelector('.nav-users');
        navUsers.addEventListener('click', navToUsers);

        const navReports = document.querySelector('.nav-reports');
        navReports.addEventListener('click', navToReports);
       
        const settingsDropdown = document.querySelector('.chevron-button');
        settingsDropdown.addEventListener('click', toggleDropdown);

        const currentTab = document.querySelector('.settings-tab');
        currentTab.classList.add('selected');

        const currentSubTab = document.querySelector('.unit-types-tab');
        currentSubTab.classList.add('selected');

        const logOutButton = document.querySelector('.log-out');
        logOutButton.addEventListener('click',logOut);
        
    });

}