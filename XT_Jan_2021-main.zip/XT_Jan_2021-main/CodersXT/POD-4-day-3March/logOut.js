export function logOut(){
    
        Cookies.remove('LoggedIn');
        // alert('logged out successfully');
        document.querySelector('body').append('logged out');
        window.location.href ='../SignIn/signIn.html';
        
}