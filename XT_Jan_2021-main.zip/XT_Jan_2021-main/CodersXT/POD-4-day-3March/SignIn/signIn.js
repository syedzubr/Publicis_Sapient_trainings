import {
  fetchData
} from "../utility.js";

if(Cookies.get('LoggedIn')!=null) { 
  window.location.href = '../inventoryDashboard/inventoryDashboard.html';
}
let userFound = false;
// add event on signin
validateUser();
var regularExpression = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;

function validateUser() {
  
  document.getElementById("validateUser").addEventListener('click', e => {

    e.preventDefault();

    let username = document.getElementById('username').value.toLowerCase();
    let password = document.getElementById('password').value;

    if (!regularExpression.test(password)) {

      document.getElementById('error').innerHTML = 'Password Must contain One uppercase,lowercase,symbol,number and minimum 8 characters';
      
      // return;
    }

    fetchData('https://inventorydb-0ecc.restdb.io/rest/administrator').then(res => {
    
      // var names

      for (let i of res) {
        if (i.name.toLowerCase() === username && i.password === password) {
          setCookie(i.name);
          userFound = true;
          break;
        }

      }
      if (userFound && regularExpression.test(password)) {
        window.location.href = '../inventoryDashboard/inventoryDashboard.html'
      } else if (!userFound && regularExpression.test(password)) {
        document.getElementById('error').innerHTML = 'Invalid user, Please try again!';
      }
      
      document.getElementById('username').addEventListener('input',deleteErrorMsg);
      userFound = false;
      
    })
  });
}
function deleteErrorMsg(){
  debugger
  document.getElementById('error').remove();
}
// not reqrd
function setCookie(username) {
  Cookies.set("LoggedIn", username, {
    expires: 1
  });
}

