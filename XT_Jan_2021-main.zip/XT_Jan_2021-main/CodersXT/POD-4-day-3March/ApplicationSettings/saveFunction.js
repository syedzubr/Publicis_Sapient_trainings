import memory from "../memory.js";
export function onSave() {
    parent = this;
    let typeName = parent.children[0].innerText;
  
    for (let i of memory.settings) {
      if (i.unitname === typeName) {

        let name2 = document.querySelector('#name-box');
        name2.value = i.unitname;
        let shortname = document.querySelector('#shortName-box');
        shortname.value = i.shortname;
        item.properties.forEach(createPropRow);
      }
    }
  }