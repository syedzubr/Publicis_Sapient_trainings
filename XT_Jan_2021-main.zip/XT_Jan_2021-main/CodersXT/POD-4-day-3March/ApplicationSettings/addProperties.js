//adding the properties
export function createProperties(property){
    const contentDiv = document.querySelector(".property-container");
    let rowDiv = document.createElement('div');
    rowDiv.classList.add('row');
    
    assignEvents(rowDiv, 'click', deleteProperty);

    let spanBox1 = document.createElement('span');
    spanBox1.classList.add('type');
    let inputB1 = document.createElement('input');

    inputB1.type = 'text';
    inputB1.classList.add('prop-box');
    inputB1.setAttribute('value',property);
    spanBox1.appendChild(inputB1);
    rowDiv.appendChild(spanBox1);

    let spanBox2 = document.createElement('span');
    spanBox2.classList.add('serial');
    let inputB2 = document.createElement('input');
    inputB2.type = 'text';
    inputB2.classList.add('prop-box');
    spanBox2.appendChild(inputB2);
    rowDiv.appendChild(spanBox2);

    let spanBox3 = document.createElement('span');
    spanBox3.classList.add('asset-name');
    let inputB3 = document.createElement('input');
    inputB3.type = 'checkbox';
    spanBox3.appendChild(inputB3);
    rowDiv.appendChild(spanBox3);

    let spanBox4 = document.createElement('span');
    spanBox4.classList.add('from-date');
    let inputB4 = document.createElement('input');
    inputB4.type = 'checkbox';
    spanBox4.appendChild(inputB4);
    rowDiv.appendChild(spanBox4);


    let btndiv = document.createElement('div');
    btndiv.classList.add('delete-btn');
    let buttonB = document.createElement('button');
    buttonB.type = 'button';
    buttonB.innerHTML = '<i class="fas fa-trash"></i>';
    btndiv.appendChild(buttonB);
    rowDiv.appendChild(btndiv);

    contentDiv.appendChild(rowDiv)
    return [inputB1, inputB2];
}