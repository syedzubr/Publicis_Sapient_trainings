// let formRow = ""; // making global to access in editusersubmit();
export function formUpdate() {
    let parentRow = this;
    let serial = document.querySelector(".popup-header-left>span");
    let typeSerial = parentRow.children[1].innerText + " " + parentRow.children[2].innerText;
    serial.innerText = typeSerial;
  
    serial = document.querySelector(".popup-header-left-form>span")
    serial.innerText = typeSerial;
  
    let formRow = parentRow;
    // editUserSubmit.bind(null,"",formRow);
    let btnSave = document.querySelector('.formSubmit');
    btnSave.addEventListener('click', editUserSubmit.bind(null,formRow));
  }
  
  
  function editUserSubmit(formRow,event) {
  
    event.preventDefault();
  
    let serial = document.getElementById('txtSerial');
    let userName = document.getElementById('txtName');
    let dateFrom = document.getElementById('txtFrom');
  
    if(serial.value==="" || userName.value==="" || dateFrom.value===""){
        alert("Fill the details");
    }
    else{

      formRow.children[2].innerText = serial.value;
      formRow.children[3].innerText = userName.value;
      formRow.children[4].innerText = dateFrom.value;

      // let sendData = new Object();
      // let sendData = {
      //   0 : {
      //     serial : serial,
      //     name : userName,
      //     from : dateFrom
      //   }
      // };
      // sendData = JSON.stringify(sendData);

      // $.ajax({
      //   url: 'https://inventorydb-0ecc.restdb.io/rest/userunits',
      //   type: 'PUT',
      //   headers: {
      //     "x-apikey" : "6038d03110f29b640ed97b20",
      //     // "Access-Control-Allow-Origin": '*',
      //     "dataType": "json",
      //     // "cors": true ,
      //     "contentType":"application/json",
      //     // "content-type": "application/json",
      //   },
      //   data: sendData,
      //     // 0 : {
      //     //       serial : serial,
      //     //       name : userName,
      //     //       from : dateFrom
      //     //     }
        
      //   success: function(data) {
      //     alert('Load was performed.');
      //   }
      // });
  
      let frm = document.getElementById('editForm');
      frm.reset();
    }
  }