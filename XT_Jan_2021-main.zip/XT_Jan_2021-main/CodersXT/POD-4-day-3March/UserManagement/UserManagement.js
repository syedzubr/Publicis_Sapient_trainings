import {
    fetchData,
    getUserName
} from "../utility.js";

import {
    showData
} from "./showData.js"

import {
    showLogs
} from "./hover_Logs.js"

import {navHandler, navToDashboard, navToSettings, navToUsers, navToReports} from "../navHandler.js";

import {rightPopClose} from "./PopUpsAndClose.js"

import {formClose, formPopUp} from "./PopUpsAndClose.js"

import {search,sync} from "./search.js"

import memory from "../memory.js";

import {logOut} from "../logOut.js"
import { getResources } from "./getResources.js";

window.addEventListener("DOMContentLoaded",init);

if(Cookies.get('LoggedIn')==null) { 
    alert("User Not Logged in yet");
    window.location.href = '../SignIn/signIn.html';
}

export function init() {
    fetchData('https://inventorydb-0ecc.restdb.io/rest/userunits').then((responseData) => {

    let mainImage = document.querySelector(".main-image");
    mainImage.classList.add("display-none");
    if(responseData.length===0){
        const msgElement = document.querySelector('.error-display');
        msgElement.append("Something Went Wrong!");
    }
    else{
        const msgElement = document.querySelector('.error-display');
        msgElement.classList.add("display-none");
    }
    memory.users = responseData;
    showData(responseData);
    getResources();

});
        
$('header').load('../header.html',function(){
    const navButton = document.querySelector('.nav-button');
    navButton.addEventListener('click',navHandler);
    getUserName();
});
$('.menu').load('../nav.html',function(){
    const navDashboard = document.querySelector('.nav-dashboard');
    navDashboard.addEventListener('click',navToDashboard);
    
    const navUsers = document.querySelector('.nav-users');
    navUsers.addEventListener('click',navToUsers);

    const navReports = document.querySelector('.nav-reports');
    navReports.addEventListener('click',navToReports);

    const navSettings = document.querySelector('.nav-settings');
    navSettings.addEventListener('click',navToSettings);

    const menuBar = document.querySelector(".menu-bar");
    menuBar.className = "menu-bar-mobile";

    const logOutButton = document.querySelector('.log-out');
    logOutButton.addEventListener('click',logOut);

    
});

let showLog = document.querySelector('.showLogs');
showLog.addEventListener("click", showLogs);

let closeBtn = document.querySelector('.close-icon-right-popup');
closeBtn.addEventListener('click', rightPopClose);

let closeBtns = document.querySelectorAll('.close-form');
for (let closeBtn of closeBtns)
    closeBtn.addEventListener('click', formClose);

let editBtn = document.querySelector('.fa-pen');
editBtn.addEventListener('click', formPopUp);

let searchBtn = document.querySelector(".search-btn");
searchBtn.addEventListener("click", search);

let syncBtn = document.querySelector(".sync-btn");
syncBtn.addEventListener("click", sync);
}

