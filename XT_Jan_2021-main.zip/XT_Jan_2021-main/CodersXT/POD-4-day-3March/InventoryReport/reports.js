 import {
     fetchData,
     getUserName
 } from "../utility.js";
 import memory from "../memory.js"

 import {
     dataFilter
 } from "./dataFilter.js"
 import {
     createTable
 } from "./createtable.js"

 import {
     loadTable
 } from "./createTable.js"
 import {
     getDate
 } from "./getDate.js"

 import {
     navHandler,
     navToDashboard,
     navToUsers,
     navToReports,
     toggleDropdown

 } from "../navHandler.js"

 import {
     logOut
 } from "../logOut.js"

 const fetchUrl = "https://inventorydb-0ecc.restdb.io/rest/reports";

 window.addEventListener('DOMContentLoaded', init);


 function init() {

     // null -> undfnd
     if (Cookies.get('LoggedIn') == null) {
         alert("User Not Logged in yet");
         window.location.href = '../SignIn/signIn.html';
     }

     $('header').load('../header.html', function () {
         const navButton = document.querySelector('.nav-button');
         navButton.addEventListener('click', navHandler);
         getUserName();
     });

     $('.menu').load('../nav.html', function () {
         const navDashboard = document.querySelector('.nav-dashboard');
         navDashboard.addEventListener('click', navToDashboard);

         const navUsers = document.querySelector('.nav-users');
         navUsers.addEventListener('click', navToUsers);

         const navReports = document.querySelector('.nav-reports');
         navReports.addEventListener('click', navToReports);


         const settingsDropdown = document.querySelector('.chevron-button');
         settingsDropdown.addEventListener('click', toggleDropdown);


         const currentTab = document.querySelector('.settings-tab');
         currentTab.classList.add('selected');

         const currentSubTab = document.querySelector('.unit-types-tab');
         currentSubTab.classList.add('selected');

         const logOutButton = document.querySelector('.log-out');
         logOutButton.addEventListener('click', logOut);


     });





     fetchData(fetchUrl).then((data) => {
         let element = document.querySelector('.load-gif');
         element.classList.add('hide');
         if (!data.length) {

             const msg = document.querySelector('.error-msg');
             msg.classList.add('invalid-fetch-data');
             msg.append("Something went wrong");

         }
         memory.reports = data;
         createTable();
         dataFilter();

     })
     document.querySelector('.statusSelect').addEventListener("change", loadTable);
     document.querySelector('.resourceType').addEventListener("change", loadTable);


     const fromDate = document.getElementById("from-date", getDate);
     fromDate.addEventListener("change", getDate);
     const toDate = document.getElementById("to-date", getDate);
     toDate.addEventListener("change", getDate);

 }