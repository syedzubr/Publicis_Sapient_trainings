 import {createTable} from "./createTable.js";
import memory from "../memory.js";
 
 export function getDate(){
    let tbody = document.querySelector(".entryForTable");
    let unitCount = 0;

   
    document.querySelector(".unitCounter").innerText = `All units:  ${unitCount}`;
    while (tbody.firstChild) {
      tbody.removeChild(tbody.firstChild);
    }
    for(let unit of memory.reports){

      // t?

      let t=new Date(unit.from);
  
      // checkDate

      if(CheckDate(t)){
        unitCount++;
        createTable(unit);
      }
  
    }
    document.querySelector(".unitCounter").append(unitCount)
  
  }
  function CheckDate(start){
    let fromDate=document.getElementById("from-date").value;
    let toDate=document.getElementById("to-date").value;

    // var names?
    // let const

    let searchedFromDate=new Date(fromDate);
    let searchedToDate=new Date(toDate);
    
    return(((start>searchedFromDate)||(start===searchedFromDate))&&((start<searchedToDate)||(start===searchedToDate)));
  
  }
  