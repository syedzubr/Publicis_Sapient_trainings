 
import memory from "../memory.js";
 
export function dataFilter() {

    // let const

    let resourceOptions = document.getElementById('resource-type-id');
    let filterData = new Set();
    for (let item of memory.reports) filterData.add(item.type);
    for (let units of filterData) {
        let options = document.createElement('option');
        options.innerText = units;
       
        resourceOptions.appendChild(options);
    }
}

