window.addEventListener('DOMContentLoaded', init);

import {
  navHandler,
  navToDashboard,
  navToUsers,
  navToReports,
  toggleDropdown
} from "../utils/navHandler.js"

import {
  fetchData,
  getUserName
  } from "../utils/utility.js";
import memory from "../memory/memory.js";

import {logOut} from "../utils/logOut.js";

import {onSave} from "./saveFunction.js";
import {createParts} from "./addParts.js";
import {createProperties} from "./addProperties.js";
function init() {

//checking if user logged in

   if(Cookies.get('LoggedIn')==null) { 
    window.location.href = '../SignIn/signIn.html';
}

// loading the components
 
  $('header').load('../header.html', function () {
    const navButton = document.querySelector('.nav-button');
    navButton.addEventListener('click', navHandler);
    getUserName();
  });
  
   $('.menu').load('../nav.html', function () {
     const navDashboard = document.querySelector('.nav-dashboard');
     navDashboard.addEventListener('click', navToDashboard);

    const navUsers = document.querySelector('.nav-users');
     navUsers.addEventListener('click', navToUsers);

     const navReports = document.querySelector('.nav-reports');
     navReports.addEventListener('click', navToReports);

     //  loading the drop down settings
    const settingsDropdown = document.querySelector('.chevron-button');
    settingsDropdown.addEventListener('click', toggleDropdown);

    const currentTab = document.querySelector('.settings-tab');
    currentTab.classList.add('selected');

    const currentSubTab = document.querySelector('.unit-types-tab');
    currentSubTab.classList.add('selected');

    const logOutButton = document.querySelector('.log-out');
    logOutButton.addEventListener('click',logOut);

   });
 
  }
  //fetching the data from restdb
  let parent = "";
  fetchData('https://inventorydb-0ecc.restdb.io/rest/unittypes').then(res => {


    if(res.length===0){
      const details = document.querySelector('.details');
      details.classList.add('hide');
      document.querySelector('.user').classList.add('hide');
     const msgElement = document.querySelector('.error-msg');
     msgElement.classList.add('invalid-fetch-data');
    msgElement.append("Something Went Wrong!");
      
  }

    memory.settings = res;
    displayData(res);
  });

  function displayData(res) {
    let userList = document.querySelector('.user-list');
    let count = 0;
    for (let i of res) {
      let span = document.createElement('span');
      span.className = 'type';

      span.innerText = i.unitname;
     
      let div = document.createElement('div');
      div.className = 'each-person';
      if (count === 0) {
        count++;
        div.classList.add('first-person');

      }

      div.append(span);
      div.addEventListener('click', onSave);
     
      userList.append(div);
    }

  }
  
  let saveBtn = document.querySelector('.assign-unit');
  saveBtn.addEventListener('click', onSubmit);
  function onSubmit() {
    let newName = document.querySelector('#name-box').value;
    parent.children[0].innerText = newName;

  }


//event listeners for add button  
let addPropertyBtn=document.querySelector('#property-btn');
addPropertyBtn.addEventListener('click',createProperties);
let addPartsBtn=document.querySelector('#part-btn');
addPartsBtn.addEventListener('click',createParts);


