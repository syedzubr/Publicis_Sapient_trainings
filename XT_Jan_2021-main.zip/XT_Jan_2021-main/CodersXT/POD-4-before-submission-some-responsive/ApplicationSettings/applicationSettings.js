window.addEventListener('DOMContentLoaded', init);

import {
  navHandler,
  navToDashboard,
  navToUsers,
  navToReports,
  //navToSettings,
  toggleDropdown
} from "../navHandler.js"

function init() {

  // loading the components

  $('header').load('../header.html', function () {
    const navButton = document.querySelector('.nav-button');
    navButton.addEventListener('click', navHandler);
  });
   $('.menu').load('../nav.html', function () {
     const navDashboard = document.querySelector('.nav-dashboard');
     navDashboard.addEventListener('click', navToDashboard);

    const navUsers = document.querySelector('.nav-users');
     navUsers.addEventListener('click', navToUsers);

     const navReports = document.querySelector('.nav-reports');
     navReports.addEventListener('click', navToReports);

     //  loading the drop down settings
    const settingsDropdown = document.querySelector('.chevron-button');
    settingsDropdown.addEventListener('click', toggleDropdown);

    const currentTab = document.querySelector('.settings-tab');
    currentTab.classList.add('selected');

    const currentSubTab = document.querySelector('.unit-types-tab');
    currentSubTab.classList.add('selected');

   });
 
  }






  // var acookie = ReadCookie("cookiename");
  // if(acookie.length == 0)
  //  { 
  //   window.location.href = '../signIn/signIn.html'
  //  }

  import {
    fetchData,
    } from "../utility.js";
  import memory from "../memory.js";

  let parent = "";
  fetchData('https://inventorydb-0ecc.restdb.io/rest/unittypes').then(res => {
    // console.log(res);

    memory.settings = res;
    displayData(res);
  });

  function displayData(res) {
    let userList = document.querySelector('.user-list');
    let count = 0;
    for (let i of res) {
      let span = document.createElement('span');
      span.className = 'type';

      span.innerText = i.unitname;
      // console.log(i.unitname);
      let div = document.createElement('div');
      div.className = 'each-person';
      if (count === 0) {
        count++;
        div.classList.add('first-person');

      }

      div.append(span);
      div.addEventListener('click', display2Data);

      userList.append(div);
    }

  }
  function display2Data() {
    // console.log(this);
    parent = this;
    let typeName = parent.children[0].innerText;
    //console.log(parent.children[0].innerText);
    for (let i of memory.settings) {
      if (i.unitname === typeName) {

        let name2 = document.querySelector('#name-box');
        //console.log(name2);
        name2.value = i.unitname;
        let shortname = document.querySelector('#shortName-box');
        shortname.value = i.shortname;


      }
    }


  }
  let saveBtn = document.querySelector('.assign-unit');
  saveBtn.addEventListener('click', onSubmit);
  function onSubmit() {
    let newName = document.querySelector('#name-box').value;
    parent.children[0].innerText = newName;

    // let newShortName=document.querySelector('#shortName-box').value;
  }
