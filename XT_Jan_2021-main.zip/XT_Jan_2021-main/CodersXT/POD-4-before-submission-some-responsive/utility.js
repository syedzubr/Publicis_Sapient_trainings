export async function fetchData(url) {
    try {
        let responseData = await fetch(url, {
            headers: {
                "x-apikey": "6038d03110f29b640ed97b20",
                "content-type": "application/json",
            },
        });
        
        return responseData.json();
    } catch (error) {
        console.log(error);
    }
}
export function statusStyling(elementName, deviceStatus) {
    elementName.classList.add('status-bar');
    switch (deviceStatus) {
        case "Allotted":
            elementName.classList.add('alloted-status-border');
            break;
        case "Deprecated":
            elementName.classList.add('deprecated-status-border');
            break;
        case "Out of order":
            elementName.classList.add('outoforder-status-border');
            break;
        case "Broken":
            elementName.classList.add('broken-status-border');
            break;

        case "Available":
            elementName.classList.add('available-status-border');
            break;
        default:
            break;
    }
}


