import {
    fetchData
} from "../utility.js";
import {
    navHandler,
    navToDashboard,
    navToUsers,
    navToReports,
    // navToSettings
    toggleDropdown

} from "../navHandler.js"

import {
    addUnit,
    saveHandler,
    closePopUp
} from "./newRecord.js"

import {
    searchbarshow,
    searchtext,
    backButtonHandler
} from "./search.js"

import {
    showData
} from "./showData.js";

import memory from "../memory.js";

import { refresh } from "./refresh.js";

window.addEventListener('DOMContentLoaded', init);

function init() {

    // loading the components

    $('header').load('../header.html', function () {
        const navButton = document.querySelector('.nav-button');
        navButton.addEventListener('click', navHandler);
    });
    $('.menu').load('../nav.html', function () {
        const navDashboard = document.querySelector('.nav-dashboard');
        navDashboard.addEventListener('click', navToDashboard);

        const navUsers = document.querySelector('.nav-users');
        navUsers.addEventListener('click', navToUsers);

        const navReports = document.querySelector('.nav-reports');
        navReports.addEventListener('click', navToReports);
        //old settings that needs to be removed hence commented
        // const navSettings = document.querySelector('.nav-settings');
        // navSettings.addEventListener('click', navToSettings);

        //  loading the drop down settings
        const settingsDropdown = document.querySelector('.chevron-button');
        settingsDropdown.addEventListener('click', toggleDropdown);

        const currentTab = document.querySelector('.settings-tab');
        currentTab.classList.add('selected');

        const currentSubTab = document.querySelector('.unit-types-tab');
        currentSubTab.classList.add('selected');


    });


    fetchData('https://inventorydb-0ecc.restdb.io/rest/units').then((responseData) => {
        let element = document.querySelector('.main img');
        element.classList.add('hide');
        showData(responseData);
        memory.units = responseData;
    });

    const addButton = document.querySelector('.add-button');
    addButton.addEventListener('click', addUnit);

    const saveButton = document.querySelector('.save-button');
    saveButton.addEventListener("click", saveHandler);

    const closeButton = document.querySelector('.close-button');
    closeButton.addEventListener("click", closePopUp);

    const cancelButton = document.querySelector('.cancel-button');
    cancelButton.addEventListener("click", closePopUp);

    const backButton = document.querySelector('.back-button');
    backButton.addEventListener("click", backButtonHandler);

    const searchButton = document.querySelector('.search-button');
    searchButton.addEventListener('click', searchbarshow);

    const refreshButton = document.querySelector('.refresh-button');
    refreshButton.addEventListener('click', refresh);

    const searchText = document.querySelector('.search-bar');
    searchText.addEventListener('input', searchtext);

}