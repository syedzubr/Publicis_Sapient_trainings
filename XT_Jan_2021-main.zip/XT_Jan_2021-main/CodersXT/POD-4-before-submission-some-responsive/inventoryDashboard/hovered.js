export function hovered(event) {

    const status=this.children[1].innerText;
    
    const model=this.children[4].innerText;
   
    const assignedTo=this.children[5].innerText;
  
    
}