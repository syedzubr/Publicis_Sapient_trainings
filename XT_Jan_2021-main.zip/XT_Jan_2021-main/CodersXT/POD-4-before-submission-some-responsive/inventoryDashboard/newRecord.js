import {
    addRow
} from "./addRow.js"

export function addUnit() {
    const rightPopUp = document.querySelector('.right-popup');
    rightPopUp.classList.add('right-popup-shown');
    const mainele = document.querySelector('.main');
    mainele.classList.add('disable-color');
    mainele.classList.add('disable-events');
    const navEle = document.querySelector('nav');
    navEle.classList.add('disable-events');
    const buttons = document.querySelectorAll('.content-header button');
    for (const button of buttons) {
        button.classList.add('change-btn-color');
    }
}

export function saveHandler(event) {

    event.preventDefault();

    const deviceType = document.querySelector('.form-add-device-list').value;
    const deviceName = document.querySelector('.form-device-name').value;
    const deviceSerial = document.querySelector('.form-device-serial').value;
    const deviceStatus = document.querySelector('.form-device-status').value;
    const deviceAssigned = document.querySelector('.form-add-assigned').value;
    const deviceFrom = document.querySelector('.form-device-from').value;


    let fromDate;
    if(deviceFrom){
        fromDate=new Date(deviceFrom);
        fromDate=`${fromDate.getDate()} ${fromDate.toLocaleString('en-us',{month:'long'})} ${fromDate.getFullYear()}`;
    }

    const columnHeaders = ["status", "serial", "type", "name", "assignedto", "from"];

    let device = new Object();

    device = {
        status: deviceStatus,
        serial: deviceSerial,
        type: deviceType,
        name: deviceName,
        assignedto: deviceAssigned,
        from: fromDate
    };
    
    validateForm(deviceName, deviceSerial);
    if (deviceName && deviceSerial) {
        addRow(columnHeaders, device);
        $.ajax({
            type: 'POST',
            url: 'https://inventorydb-0ecc.restdb.io/rest/units',
            headers: {
                "x-apikey": "6038d03110f29b640ed97b20"
            },
            data: {
                status: deviceStatus,
                serial: deviceSerial,
                type: deviceType,
                name: deviceName,
                assignedto: deviceAssigned,
                from: fromDate
            }
        });
        const addForm = document.querySelector('.add-form');
        addForm.reset();
    }
}


function validateForm(deviceName, deviceSerial) {
    const name = document.querySelector('.form-device-name');
    const serial = document.querySelector('.form-device-serial');
    const classesName = name.className.split(' ');
    const classesSerial = serial.className.split(' ');

    if (classesName.includes('required-field')) {
        name.classList.remove('required-field');
    }

    if (classesSerial.includes('required-field')) {
        serial.classList.remove('required-field');
    }
    if ((deviceName == "") || (deviceSerial == "")) {
        if (deviceSerial == "") {
            serial.classList.add('required-field')
        }
        if (deviceName == "") {
            name.classList.add('required-field');
        }
    }
}

export function closePopUp(event) {
    event.preventDefault();
    const rightPopUp = document.querySelector('.right-popup');
    rightPopUp.classList.remove('right-popup-shown');
    const mainEle = document.querySelector('.main');
    mainEle.classList.remove('disable-events');
    mainEle.classList.remove('disable-color');
    const navEle = document.querySelector('nav');
    navEle.classList.remove('disable-events');
    const buttons = document.querySelectorAll('.content-header button');
    for (const button of buttons) {
        button.classList.remove('change-btn-color');
    }
}