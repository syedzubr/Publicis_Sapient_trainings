import { showData } from "./showData.js";

import memory from "../memory.js";

let allUsers;
export function search() {

    allUsers = [];
    for (let i of memory.users) {
        let found = allUsers.find(user => user.username === i.username)
        if (!found)
            allUsers.push(i)
    }   

    let userHeader = document.querySelector(".users-header");
    userHeader.classList.add("display-none");

    let closeBtn = document.querySelector(".close-search");
    closeBtn.addEventListener("click", searchShowData);

    let userDetails = document.querySelector(".users-header-bar");
    userDetails.classList.remove("display-none");


    let search = document.querySelector("#searchName");
    search.addEventListener('input', filterData);
}

function filterData() {
    let newUsers = [];
    let search = document.querySelector("#searchName");
    console.log(search.value, " value here ");
    for(let user of allUsers){
        if(user.username.includes(search.value)){
            newUsers.push(user);
        }
    }
    showData(newUsers);
}

function searchShowData(){
    let userBar = document.querySelector(".users-header-bar");
    userBar.classList.add("display-none");

    let userHeader = document.querySelector(".users-header");
    userHeader.classList.remove("display-none");

    showData(memory.users);
}