export function rightPopUp() {
    let right = document.querySelector(".right-section");
    right.classList.add("display-none");

    let formpop = document.querySelector(".right-popup");
    formpop.classList.remove("display-none");
}

export function rightPopClose(e) {
    if (e)
        e.preventDefault();

    let right = document.querySelector(".right-popup");
    right.classList.add("display-none");

    let formpop = document.querySelector(".right-section");
    formpop.classList.remove("display-none");

    let hover = document.querySelector(".row-hovered");
    if (hover)
        hover.classList.remove("row-hovered");
}

export function formClose(e) {
    e.preventDefault();
    let right = document.querySelector(".form-popup");
    right.classList.add("display-none");

    let formpop = document.querySelector(".right-popup");
    formpop.classList.remove("display-none");
}

export function formPopUp(e) {

    e.preventDefault();
    let right = document.querySelector(".right-popup");
    right.classList.add("display-none");

    let formpop = document.querySelector(".form-popup");
    formpop.classList.remove("display-none");
}
