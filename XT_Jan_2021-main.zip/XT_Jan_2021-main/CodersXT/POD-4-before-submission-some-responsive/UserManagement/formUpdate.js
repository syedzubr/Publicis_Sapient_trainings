// let formRow = ""; // making global to access in editusersubmit();
export function formUpdate() {
    let parentRow = this;
  
    console.log(parentRow.children[1].innerText);
    let serial = document.querySelector(".popup-header-left>span");
    let typeSerial = parentRow.children[1].innerText + " " + parentRow.children[2].innerText;
    serial.innerText = typeSerial;
  
    serial = document.querySelector(".popup-header-left-form>span")
    serial.innerText = typeSerial;
  
    let formRow = parentRow;
    // editUserSubmit.bind(null,"",formRow);
    let btnSave = document.querySelector('.formSubmit');
    btnSave.addEventListener('click', editUserSubmit.bind(null,formRow));
  }
  
  
  function editUserSubmit(formRow,event) {
  
    event.preventDefault();
  
    let serial = document.getElementById('txtSerial');
    // console.log(serial.value,"value of serial here");
    let userName = document.getElementById('txtName');
    let dateFrom = document.getElementById('txtFrom');
  
    if(serial.value==="" || userName.value==="" || dateFrom.value===""){
        alert("Fill the details");
    }
    else{
      formRow.children[2].innerText = serial.value;
      formRow.children[3].innerText = userName.value;
      formRow.children[4].innerText = dateFrom.value;
  
      let frm = document.getElementById('editForm');
      frm.reset();
    }
  }