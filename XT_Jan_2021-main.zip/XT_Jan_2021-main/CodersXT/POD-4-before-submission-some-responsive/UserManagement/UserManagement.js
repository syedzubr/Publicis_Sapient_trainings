import {
    fetchData
} from "../utility.js";

import {
    showData
} from "./showData.js"

import {
    showLogs
} from "./hover_Logs.js"

import {navHandler, navToDashboard, navToSettings, navToUsers, navToReports} from "../navHandler.js";

import {rightPopClose} from "./PopUpsAndClose.js"

import {formClose, formPopUp} from "./PopUpsAndClose.js"

import {search} from "./search.js"

import memory from "../memory.js";

window.addEventListener("DOMContentLoaded",init);

function init() {
    fetchData('https://inventorydb-0ecc.restdb.io/rest/userunits').then((responseData) => {

    let mainImage = document.querySelector(".main-image>img");
    mainImage.classList.add("display-none");
    memory.users = responseData;
    showData(responseData);

});

$('header').load('../header.html',function(){
    const navButton = document.querySelector('.nav-button');
    navButton.addEventListener('click',navHandler);
});
$('.menu').load('../nav.html',function(){
    const navDashboard = document.querySelector('.nav-dashboard');
    navDashboard.addEventListener('click',navToDashboard);
    
    const navUsers = document.querySelector('.nav-users');
    navUsers.addEventListener('click',navToUsers);

    const navReports = document.querySelector('.nav-reports');
    navReports.addEventListener('click',navToReports);

    const navSettings = document.querySelector('.nav-settings');
    navSettings.addEventListener('click',navToSettings);
    
});

let showLog = document.querySelector('.showLogs');
showLog.addEventListener("click", showLogs);

let closeBtn = document.querySelector('.close-icon-right-popup');
closeBtn.addEventListener('click', rightPopClose);

let closeBtns = document.querySelectorAll('.close-form');
for (let closeBtn of closeBtns)
    closeBtn.addEventListener('click', formClose);

let editButton = document.querySelector('.fa-pen');
editButton.addEventListener('click', formPopUp);

let searchBtn = document.querySelector(".search-btn");
searchBtn.addEventListener("click", search);

}
