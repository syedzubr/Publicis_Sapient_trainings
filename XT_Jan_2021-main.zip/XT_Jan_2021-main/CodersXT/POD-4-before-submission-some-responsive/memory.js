class memory{
    units=[];
    reports=[];
    users = [];
    settings=[];
} 
export default memory;
