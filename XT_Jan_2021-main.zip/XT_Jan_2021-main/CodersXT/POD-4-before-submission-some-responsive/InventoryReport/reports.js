 import {
   fetchData
 } from "../utility.js";
 import memory from "../memory.js"
 
 import {dataFilter} from "./dataFilter.js"
import {createTable} from "./createtable.js"
 
 import {loadTable} from "./createTable.js"
//  import {navHandler} from "../navHandler.js"
 import {
    navHandler,
    navToDashboard,
    navToUsers,
    navToReports,
    // navToSettings
    toggleDropdown

} from "../navHandler.js"


const fetchUrl = "https://inventorydb-0ecc.restdb.io/rest/reports";

window.addEventListener('DOMContentLoaded', init);


function init() {

    // loading the components

    $('header').load('../header.html',function(){
        const navButton = document.querySelector('.nav-button');
        navButton.addEventListener('click',navHandler);
    });
    $('.menu').load('../nav.html',function(){
        const navDashboard = document.querySelector('.nav-dashboard');
        navDashboard.addEventListener('click',navToDashboard);
        
        const navUsers = document.querySelector('.nav-users');
        navUsers.addEventListener('click',navToUsers);
    
        const navReports = document.querySelector('.nav-reports');
        navReports.addEventListener('click',navToReports);
    
        // const navSettings = document.querySelector('.nav-settings');
        // navSettings.addEventListener('click',navToSettings);

        const settingsDropdown = document.querySelector('.chevron-button');
        settingsDropdown.addEventListener('click', toggleDropdown);


        const currentTab = document.querySelector('.settings-tab');
        currentTab.classList.add('selected');

        const currentSubTab = document.querySelector('.unit-types-tab');
        currentSubTab.classList.add('selected');


        
    });





    fetchData(fetchUrl).then((data) => {
        let element = document.querySelector('.load-gif');
        element.classList.add('hide');

        memory.reports = data;
        createTable();
        dataFilter();
     

       

        
    })
    document.querySelector('.availability').addEventListener("change", loadTable);
    document.querySelector('.hardware-type').addEventListener("change", loadTable);





}
