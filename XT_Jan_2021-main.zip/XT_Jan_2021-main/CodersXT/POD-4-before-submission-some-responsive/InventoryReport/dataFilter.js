 import {
     statusStyling
  } from "../utility.js";
 
 
 
 
 
  import memory from "../memory.js";
 
 
 
 
 

export function dataFilter() {
    let hardwareOptions = document.getElementById('hardware-type-id');
    let filterData = new Set();
    for (let item of memory.reports) filterData.add(item.type);
    for (let units of filterData) {
        let options = document.createElement('option');
        options.innerText = units;
       
        hardwareOptions.appendChild(options);
    }
}

