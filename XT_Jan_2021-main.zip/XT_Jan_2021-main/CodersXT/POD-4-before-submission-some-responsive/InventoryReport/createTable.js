
 import {
    statusStyling
 } from "../utility.js";





 import memory from "../memory.js";





export function loadTable() {
    let listOfItems = document.querySelector(".table-values");
    listOfItems.innerHTML = "";
    createTable();
}

function checkCondition(status, availableStatus, itemType, hardwareType) {
    let flag1 = false;
    let flag2 = false;
    if (status === availableStatus || availableStatus === "Added") flag1 = true;
    if (itemType === hardwareType || hardwareType === "All Units") flag2 = true;
    if (flag1 && flag2) return true;
    return false;
}

export function createTable() {
    let unitCount = 0;
    let availableStatus = document.querySelector(".availability").value;
    let hardwareType = document.querySelector(".hardware-type").value;
    for (let item of memory.reports) {
        if (checkCondition(item.status, availableStatus, item.type, hardwareType)) {
            let tableUsed = document.createElement('div');
            tableUsed.setAttribute("class", "table-row")
            let statusUsed = document.createElement('div');
            let statusBody = document.createElement('span');
            let temp = item.status.toLowerCase();
            statusBody.setAttribute("class", temp);
            statusBody.append(item.status);
            statusUsed.appendChild(statusBody);
            let serielUsed = document.createElement('div');
            serielUsed.append(item.serial);
            let typeUsed = document.createElement('div');
            typeUsed.append(item.type);
            let nameUsed = document.createElement('div');
            nameUsed.append(item.name);
            let assignedUsed = document.createElement('div');
            assignedUsed.append(item.assignedto);
            let fromUsed = document.createElement('div');
            fromUsed.append(item.from);
            tableUsed.append(statusUsed, serielUsed, typeUsed, nameUsed, assignedUsed, fromUsed);
            document.querySelector('.table-values').appendChild(tableUsed);
            unitCount++;
        }
    }
    let divCounter = document.querySelector(".add-units-counter");
    divCounter.innerHTML = `All Units : ${unitCount}`;
}

