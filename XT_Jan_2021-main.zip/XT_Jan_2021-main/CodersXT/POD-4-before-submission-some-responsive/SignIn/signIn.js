import { fetchData } from "../utility.js";
let userFound = false;
validateUser();
var regularExpression = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
     
function validateUser() {
  document.getElementById("validateUser").addEventListener('click', e => {
    let username = document.getElementById('username').value;
    e.preventDefault();
    let password = document.getElementById('password').value;
    if (!regularExpression.test(password)) 
    {
      document.getElementById('error').innerHTML = 'Password Must contain One uppercase,lowercase,symbol,number and minimum 8 characters';
      username.focus;
      return;
    }
    fetchData('https://inventorydb-0ecc.restdb.io/rest/administrator').then(res => {
      
        for (let i of res) {
          if (i.name === username && i.password === password) {
            userFound = true;
            break;
          }
        }
      
      // if(!regularExpression.test(password)){
      //   document.getElementById('error').innerHTML = 'Password Must contain One uppercase,lowercase,symbol,number and minimum 8 characters';
      // }
      if (userFound && regularExpression.test(password)) {

        window.location.href = '../inventoryDashboard/inventoryDashboard.html'
      } else if(!userFound && regularExpression.test(password)){
        document.getElementById('error').innerHTML = 'Invalid Username/password';
    }

      userFound = false;
    })
  });
}




