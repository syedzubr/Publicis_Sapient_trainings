
import memory from "../memory.js";


function notSubmit(e) {
  e.preventDefault();
}


let editButton = document.querySelector('.fa-pen');
editButton.addEventListener('click', formPopUp);

function formPopUp(e) {

  e.preventDefault();
  let right = document.querySelector(".right-popup");
  right.classList.add("display-none");

  let formpop = document.querySelector(".form-popup");
  formpop.classList.remove("display-none");
}

let closeBtns = document.querySelectorAll('.close-form');
for (let closeBtn of closeBtns)
  closeBtn.addEventListener('click', formClose);


function formClose(e) {
  e.preventDefault();
  let right = document.querySelector(".form-popup");
  right.classList.add("display-none");

  let formpop = document.querySelector(".right-popup");
  formpop.classList.remove("display-none");
}



let closeBtn = document.querySelector('.close-icon-right-popup');
closeBtn.addEventListener('click', rightPopClose);

export function rightPopClose(e) {
  if (e)
    e.preventDefault();

  let right = document.querySelector(".right-popup");
  right.classList.add("display-none");

  let formpop = document.querySelector(".right-section");
  formpop.classList.remove("display-none");

  let hover = document.querySelector(".row-hovered");
  if (hover)
    hover.classList.remove("row-hovered");
}


export function closeLogs() {
  let logs = document.querySelector('.showLogs');
  logs.classList.remove("visibility-hidden");

  let detLog = document.querySelector(".detailedLogs");
  detLog.classList.add("display-none");
}



export function showHovered() {
  let hover = document.querySelector(".row-hovered");
  if (hover) {

    hover.classList.remove("row-hovered");
    this.classList.add("row-hovered");
  } else {
    this.classList.add("row-hovered");

  }
}



 export function rightPopUp() {
  let right = document.querySelector(".right-section");
  right.classList.add("display-none");

  let formpop = document.querySelector(".right-popup");
  formpop.classList.remove("display-none");
}



let formRow = ""; // making global to access in editusersubmit();
export function formUpdate() {
  let parentRow = this;

  console.log(parentRow.children[1].innerText);
  let serial = document.querySelector(".popup-header-left>span");
  let typeSerial = parentRow.children[1].innerText + " " + parentRow.children[2].innerText;
  serial.innerText = typeSerial;

  serial = document.querySelector(".popup-header-left-form>span")
  serial.innerText = typeSerial;

  formRow = parentRow;
}


let btnSave = document.querySelector('.formSubmit');
btnSave.addEventListener('click', editUserSubmit);



function editUserSubmit(e) {

  e.preventDefault();

  let serial = document.getElementById('txtSerial');
  let userName = document.getElementById('txtName');
  let dateFrom = document.getElementById('txtFrom');

  formRow.children[2].innerText = serial.value;
  formRow.children[3].innerText = userName.value;
  formRow.children[4].innerText = dateFrom.value;

  let frm = document.getElementById('editForm');
  frm.reset();
  // return false; 
}


let showLog = document.querySelector('.showLogs');
showLog.addEventListener("click", showLogs);


function showLogs(event) {

  event.preventDefault();
  showLog.classList.add("visibility-hidden");

  let detLog = document.querySelector(".detailedLogs");
  detLog.classList.remove("display-none");
}