// import {
//   fetchData
// } from "../global.js";

import memory from "../memory.js";

// let gb = "";
// // window.addEventListener("DOMContentLoaded",fetchData);

// fetchData('https://inventorydb-3f0f.restdb.io/rest/userunits').then((responseData) => {

//   let mainImage = document.querySelector(".main-image>img");
//   mainImage.classList.add("display-none");
//   memory.users = responseData;
//   showData(responseData);

// });

// export function showData(res) {

//   console.log(res); // the data fetched form the url gets printed here
//   memory.users = res;

//   const allUsers = [];
//   for (let i of res) {
//     let found = allUsers.find(user => user.username === i.username)
//     if (!found)
//       allUsers.push(i)
//   }
//   console.log('------');
//   console.log(allUsers);

//   let count = 0;
//   for (let users of allUsers) {

//     let usrName = document.createElement('div');
//     usrName.className = "name";
//     usrName.append(users.username);

//     let usrMail = document.createElement('div');
//     usrMail.className = "gmail-id";
//     usrMail.append(users.email);

//     let usr = document.createElement('div');
//     usr.className = "users-gmail";
//     if (count === 0) {
//       usr.classList.add("users-gmail-hovered");
//       count++;
//     }
//     usr.append(usrName, usrMail);
//     usr.addEventListener('click', getResources);

//     let mainDiv = document.querySelector('.users-contacts');
//     mainDiv.appendChild(usr);
//   }
// }


function notSubmit(e) {
  e.preventDefault();
}


let editButton = document.querySelector('.fa-pen');
editButton.addEventListener('click', formPopUp);

function formPopUp(e) {

  e.preventDefault();
  let right = document.querySelector(".right-popup");
  right.classList.add("display-none");

  let formpop = document.querySelector(".form-popup");
  formpop.classList.remove("display-none");
}

let closeBtns = document.querySelectorAll('.close-form');
for (let closeBtn of closeBtns)
  closeBtn.addEventListener('click', formClose);


function formClose(e) {
  e.preventDefault();
  let right = document.querySelector(".form-popup");
  right.classList.add("display-none");

  let formpop = document.querySelector(".right-popup");
  formpop.classList.remove("display-none");
}



let closeBtn = document.querySelector('.close-icon-right-popup');
closeBtn.addEventListener('click', rightPopClose);

function rightPopClose(e) {
  if (e)
    e.preventDefault();

  let right = document.querySelector(".right-popup");
  right.classList.add("display-none");

  let formpop = document.querySelector(".right-section");
  formpop.classList.remove("display-none");

  let hover = document.querySelector(".row-hovered");
  if (hover)
    hover.classList.remove("row-hovered");
}



export function getResources(e) {
  let parentUsers = this;
  let myTarget = this;
  // console.log(this);


  let hovered = document.querySelector(".users-gmail-hovered");
  hovered.classList.remove("users-gmail-hovered");
  myTarget.classList.add("users-gmail-hovered");


  let userName = parentUsers.children[0].innerText;
  let userContact = document.querySelectorAll('.user-contact-id');
  userContact[0].innerText = parentUsers.children[1].innerText;
  let mail = parentUsers.children[1].innerText;
  let mainHeader = document.querySelector(".main-header>h3");
  mainHeader.innerText = userName;

  let option = document.querySelector('.option-assignedto');
  option.innerText = userName;

  let statusName = document.querySelector('.logs-status-name');
  statusName.innerText = "by " + userName;
  let skype;


  let mainRow = document.querySelector('.main-data-after-header');
  mainRow.innerHTML = "";
  for (let i of memory.users) {
    if (i.email === mail) {
      skype = i.skype;
      let divEmpty = document.createElement('div');

      let divType = document.createElement('div');
      divType.append(i.type);
      // document.write(icon);

      let divSerial = document.createElement('div');
      divSerial.append(i.serial);

      let divName = document.createElement('div');
      divName.append(i.name);

      let divFrom = document.createElement('div');
      divFrom.append(i.from);

      let divMain = document.createElement('div');
      divMain.className = "row";
      divMain.append(divEmpty, divType, divSerial, divName, divFrom);
      divMain.addEventListener("click", formUpdate);
      divMain.addEventListener("click", rightPopUp);
      divMain.addEventListener("click", showHovered);
      divMain.addEventListener("click", closeLogs);

      mainRow.append(divMain);
    }
  }
  userContact[1].innerText = skype;
  rightPopClose();
}


function closeLogs() {
  let logs = document.querySelector('.showLogs');
  logs.classList.remove("visibility-hidden");

  let detLog = document.querySelector(".detailedLogs");
  detLog.classList.add("display-none");
}



function showHovered() {
  let hover = document.querySelector(".row-hovered");
  if (hover) {

    hover.classList.remove("row-hovered");
    this.classList.add("row-hovered");
  } else {
    this.classList.add("row-hovered");

  }
}



function rightPopUp() {
  let right = document.querySelector(".right-section");
  right.classList.add("display-none");

  let formpop = document.querySelector(".right-popup");
  formpop.classList.remove("display-none");
}



let formRow = ""; // making global to access in editusersubmit();
function formUpdate() {
  let parentRow = this;

  console.log(parentRow.children[1].innerText);
  let serial = document.querySelector(".popup-header-left>span");
  let typeSerial = parentRow.children[1].innerText + " " + parentRow.children[2].innerText;
  serial.innerText = typeSerial;

  serial = document.querySelector(".popup-header-left-form>span")
  serial.innerText = typeSerial;

  formRow = parentRow;
}


let btnSave = document.querySelector('.formSubmit');
btnSave.addEventListener('click', editUserSubmit);



function editUserSubmit(e) {

  e.preventDefault();

  let serial = document.getElementById('txtSerial');
  let userName = document.getElementById('txtName');
  let dateFrom = document.getElementById('txtFrom');

  formRow.children[2].innerText = serial.value;
  formRow.children[3].innerText = userName.value;
  formRow.children[4].innerText = dateFrom.value;

  let frm = document.getElementById('editForm');
  frm.reset();
  // return false; 
}


let showLog = document.querySelector('.showLogs');
showLog.addEventListener("click", showLogs);


function showLogs(event) {

  event.preventDefault();
  showLog.classList.add("visibility-hidden");

  let detLog = document.querySelector(".detailedLogs");
  detLog.classList.remove("display-none");
}