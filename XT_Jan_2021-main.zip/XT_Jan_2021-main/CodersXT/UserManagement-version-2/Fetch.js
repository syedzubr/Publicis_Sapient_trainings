import {
    fetchData
  } from "../global.js";

   
import {showData} from "./showData.js"  

import memory from "../memory.js";
//   let gb = "";
  // window.addEventListener("DOMContentLoaded",fetchData);
  
  fetchData('https://inventorydb-3f0f.restdb.io/rest/userunits').then((responseData) => {
  
    let mainImage = document.querySelector(".main-image>img");
    mainImage.classList.add("display-none");
    memory.users = responseData;
    showData(responseData);
  
  });
  