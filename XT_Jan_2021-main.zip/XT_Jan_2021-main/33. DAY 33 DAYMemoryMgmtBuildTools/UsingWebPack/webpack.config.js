const path = require("path");
module.exports = {
  mode: "production",
  entry: "./src/index.js", // calculator.js
  output: {
    filename: "output.js", // bundle.js
    path: path.resolve(__dirname, "build"),
  },
};
