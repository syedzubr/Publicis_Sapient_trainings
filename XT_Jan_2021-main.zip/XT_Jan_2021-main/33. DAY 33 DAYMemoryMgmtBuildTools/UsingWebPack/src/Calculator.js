import Addition, { Product } from "./Math";

export function ScientificAdd() {
  console.log(Addition(20, 30));
}

export function ScientificProduct() {
  console.log(Product(20, 30));
}
