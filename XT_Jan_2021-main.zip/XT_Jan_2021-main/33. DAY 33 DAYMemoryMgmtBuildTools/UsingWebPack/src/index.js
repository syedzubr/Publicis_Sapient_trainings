import { ScientificAdd, ScientificProduct } from "./Calculator";

ScientificAdd();
ScientificProduct();
