let x;
let y;
let z;
// This is an addition function
function Add(veryLargeXvariable, veryLargeYvariable) {
    return veryLargeXvariable + veryLargeYvariable;
}
