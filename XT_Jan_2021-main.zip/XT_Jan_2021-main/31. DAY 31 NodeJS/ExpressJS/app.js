const express = require("express");
var cors = require("cors");
var app = express(); // one application
var router = express.Router(); // server side router

app.use(cors()); // sets the header instead !
router.get("/products/:id?", function (req, res) {
  var products = [
    { id: 1, name: "LED TV", price: 30000 },
    { id: 2, name: "LED TV", price: 30000 },
    { id: 3, name: "LED TV", price: 30000 },
    { id: 4, name: "LED TV", price: 30000 },
  ];

  if (req.params.id) {
    var theProductId = req.params.id;
    let theProduct = products.find((p) => p.id === parseInt(req.params.id));
    res.json(theProduct);
  } else {
    res.json(products); //converts js object to JSON
  }
});

router.get("/", function (req, res) {
  res.sendFile("Index.html", { root: __dirname });
});

app.use(router);
app.listen(4000, () => console.log("Server running @ 4000 !"));
