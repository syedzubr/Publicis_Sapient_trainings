// Error & Exception Handling

//try -catch -finally
// window.onerror -> Not available in Node !
// promise -> reject
// throw Error, TypeError, RangeError

// Specific to Node !

process.on("uncaughtException", function (para) {
  console.log("Handle exception here.. " + para);
  process.exit(1);
});

throw new Error("Just for Fun !");
