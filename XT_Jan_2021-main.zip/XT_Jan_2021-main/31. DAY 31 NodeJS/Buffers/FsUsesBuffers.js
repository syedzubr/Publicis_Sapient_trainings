var fs = require("fs");

let allFileData = "";
var readStream = fs.createReadStream("Data.txt");

// Non-Blocking
readStream.on("data", function (dataChunck) {
  console.log(dataChunck);
  //   allFileData +=
  //     ">>>>>>>>>>>>>>>>>>>> READING CHUNK>>>>>>>>>>>>>>>>>>>>>>" + dataChunck;
});
