function FetchDataFromEndpoint(url) {
  return fetch(url, {
    headers: {
      "x-apikey": "6025d7df5ad3610fb5bb5f06",
      "content-type": "application/json",
    },
  }).then((response) => response.json());
}
