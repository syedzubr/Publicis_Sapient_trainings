function GetData(url, callbackFunction) {
  // IE 5 & 6
  if (window.ActiveXObject) {
    var xmlhttpReq = new ActiveXObject("Microsoft.XMLHTTP");
  } else if (window.XMLHttpRequest) {
    let xmlhttpreq = new XMLHttpRequest();
    xmlhttpreq.onreadystatechange = function () {
      if (xmlhttpreq.status == 200 && xmlhttpreq.readyState == 4) {
        // responseText
        var posts = JSON.parse(xmlhttpreq.responseText);
        //console.log("Calling Callback function From Get Data !");
        callbackFunction(posts, null); // send data to Show Data
      } else if (xmlhttpreq.status != 200 && xmlhttpreq.readyState == 4) {
        callbackFunction(null, "Resource Not Found : " + xmlhttpreq.status);
      }
    };
    xmlhttpreq.open("GET", url); // REST api

    xmlhttpreq.send(); // make a async call !
  }
  // console.log("Get Data Returned !");
}
