function GetData(url) {
  return new Promise((resolve, reject) => {
    if (window.ActiveXObject) {
      var xmlhttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    } else if (window.XMLHttpRequest) {
      let xmlhttpreq = new XMLHttpRequest();
      xmlhttpreq.onreadystatechange = function () {
        if (xmlhttpreq.status == 200 && xmlhttpreq.readyState == 4) {
          var posts = JSON.parse(xmlhttpreq.responseText);
          resolve(posts);
        } else if (xmlhttpreq.status != 200 && xmlhttpreq.readyState == 4) {
          reject("Resource Not Found : " + xmlhttpreq.status);
        }
      };
      xmlhttpreq.open("GET", url); // REST api

      xmlhttpreq.send(); // make a async call !
    }
  });
}
