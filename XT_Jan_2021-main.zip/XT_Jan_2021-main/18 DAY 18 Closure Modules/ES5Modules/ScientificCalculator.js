(function (obj) {
  obj.tan = function (x, y) {
    // augment
    console.log("tan used");
  };
  obj.cot = function (x, y) {
    console.log("cot used");
  };

  //   return obj;
})(MyMathObj || window || {});
