(function (obj) {
  var Pie = 3.14; // private
  obj.Add = function (x, y) {
    // augment
    return x + y;
  };
  obj.Product = function (x, y) {
    return x * y;
  };

  //   return obj;
})(MyMathObj || window || {});
