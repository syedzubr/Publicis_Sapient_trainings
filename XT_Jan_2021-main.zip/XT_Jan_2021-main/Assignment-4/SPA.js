let Data = [
    { title: 'HTML', description: "Hypertext Markup Language (HTML) is the standard markup language for documents designed to be displayed in a web browser. It can be assisted by technologies such as Cascading Style Sheets (CSS) and scripting languages such as JavaScript.Web browsers receive HTML documents from a web server or from local storage and render the documents into multimedia web pages. HTML describes the structure of a web page semantically and originally included cues for the appearance of the document.HTML elements are the building blocks of HTML pages. With HTML constructs, images and other objects such as interactive forms may be embedded into the rendered page. HTML provides a means to create structured documents by denoting structural semantics for text such as headings, paragraphs, lists, links, quotes and other items." },
    { title: 'CSS', description: "Cascading Style Sheets (CSS) is a style sheet language used for describing the presentation of a document written in a markup language such as HTML.[1] CSS is a cornerstone technology of the World Wide Web, alongside HTML and JavaScript.[2]. CSS is designed to enable the separation of presentation and content, including layout, colors, and fonts.[3] This separation can improve content accessibility, provide more flexibility and control in the specification of presentation characteristics, enable multiple web pages to share formatting by specifying the relevant CSS in a separate .css file which reduces complexity and repetition in the structural content as well as enabling the .css file to be cached to improve the page load speed between the pages that share the file and its formatting.Separation of formatting and content also makes it feasible to present the same markup page in different styles for different rendering methods, such as on-screen, in print, by voice (via speech-based browser or screen reader), and on Braille-based tactile devices. CSS also has rules for alternate formatting if the content is accessed on a mobile device" },
    { title: 'javascript', description: "Javascript often abbreviated as JS, is a programming language that conforms to the ECMAScript specification.[9] JavaScript is high-level, often just-in-time compiled, and multi-paradigm. It has curly-bracket syntax, dynamic typing, prototype-based object-orientation, and first-class functions.Alongside HTML and CSS, JavaScript is one of the core technologies of the World Wide Web.[10] JavaScript enables interactive web pages and is an essential part of web applications." },

];


let Images = document.querySelectorAll('.Image');
for (let i = 0; i < Images.length; i++) {
    Images[i].addEventListener('click', historyState.bind(null, Data[i]));
}


function historyState(obj) {
    window.history.pushState(obj, obj.title, obj.title);
    let description = document.querySelector('.info');
    description.innerHTML = '<b>'+ obj.description +'</b>';
}


window.addEventListener('popstate', function (e) {
    let description = document.querySelector('.info');
    if(e.state)
        description.innerHTML = '<b>'+ e.state.description +'</b>';
    else{
        let firstInfo = document.createElement("div");
        let data = document.createElement("p");
        data.innerText = "Click the technology to learn more...";
        
        firstInfo.className = "first-info";
        firstInfo.append(data);

        description.innerHTML = "";
        description.append(firstInfo);
    }
})