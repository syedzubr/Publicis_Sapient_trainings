let submitBtn = document.querySelector(".submitBtn");
submitBtn.addEventListener('click',loginCheck);

function loginCheck(e){
    e.preventDefault();

    let fullName = document.querySelector('.Name').value;
    let Name = fullName.split(/ /ig);

    let gender = document.querySelector('.select-gender').value;
    let date = document.querySelector('.Date').value;
   
    if(fullName === "" || gender==="select" || date===""){
        alert("fill all the details");
        return;
    }
   
    dateform = date.split(/-/ig);

    let header = document.createElement("h2");
    let d = new Date();
    let Time = d.getHours();


    let welcomeMssg = "";
    if(Time >= 4 && Time < 12)
        welcomeMssg = "Good Morning ";
    else if(Time >= 12 && Time < 20)
        welcomeMssg = "Good Day ";
    else
        welcomeMssg = "Good Night ";



    if(gender === "Male")
        header.innerText = welcomeMssg +"Mr. "+Name[0]+",";
    else
        header.innerText = welcomeMssg +"Miss "+Name[0]+",";
    

    let mssg = document.createElement("div");
    let age = 2021-parseInt(dateform[0]);
    if(age>=18)
        mssg.innerText = "Congratulations, you are above 18 years old and eligible for event";
    else
        mssg.innerText = "Sorry, you are less than 18 years old and not eligible for event";

    let rightDiv = document.createElement("div");
    rightDiv.className = "rightDiv";
    rightDiv.append(header,mssg);

    let rightSection = document.querySelector('.right-section');
    rightSection.innerHTML = "";
    rightSection.append(rightDiv);
}