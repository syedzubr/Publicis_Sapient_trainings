function getName(){
    let cName = event.target.innerText;
    console.log(cName,"func above")
    for(let Name of data ){
        // console.log(Name.username,"another");
        if(Name.username == cName){
            // console.log(Name.name);

            console.log("syed broh");
            console.log(Name.username,"jaz");
            var nameDetails = document.querySelector('.name-details');
            nameDetails.innerHTML = "";
            // nameDetails.remove();

            var  div_name = document.createElement("div");
            div_name.className = "name-details";
            var main = document.querySelector('.main');
            main.appendChild(div_name);

            var h2 = document.createElement("h2");
            h2.innerText = "User Detail";
            // div_name.append(h2);
            nameDetails.appendChild(h2);

            /* var main = document.querySelector('.main');
            main.appendChild(div_name); */

            var div = document.createElement("div");

            var p = document.createElement("p");
            p.append("Full Name : "+Name.name);
            div.appendChild(p);

            
            var p = document.createElement("p");
            var a = document.createElement("a");
            a.href = Name.email;
            p.append(a);
            p.append("Email : "+Name.email);
            div.appendChild(p);


            var p = document.createElement("p");
            var a = document.createElement("a");
            a.href = Name.website;
            p.append(a);
            p.append("Website : "+ Name.website);
            div.appendChild(p);

            var p = document.createElement("p");
            p.append("Company Name : "+Name.company.name);
            div.appendChild(p);
            
            var p = document.createElement("p");
            p.append("City : "+Name.address.city);
            div.appendChild(p);


            var nameDetails = document.querySelector('.name-details');
            nameDetails.appendChild(div);
            nameDetails.setAttribute("style","display:block;");
            break;
        }
    }
}


fg = 0;
function GetData() {
    event.preventDefault();
    // alert("hey");
    var xmlHttpR = new XMLHttpRequest();
    xmlHttpR.open('Get','https://jsonplaceholder.typicode.com/users');
    xmlHttpR.send();  // make a async call
    xmlHttpR.onreadystatechange = function () {
        if (xmlHttpR.status == 200 && xmlHttpR.readyState == 4) {
            // responseText 
            data = xmlHttpR.responseText;
            data = JSON.parse(data);
            // console.log(data);

            var userName = document.querySelector('#userName');
            // console.log(userName.value,"here");
            for(let Name of data ){
                // console.log(Name.username);
                if(Name.username == userName.value){
                    fg = 1;
                    break;
                }
            }
            if(fg!=1){
                alert("User Name not Correct");
            }
            else{

                var container = document.querySelector('.name-container');
                container.setAttribute("style","display:block;");
                var btn = document.createElement("button");
                // console.log(userName.value,"inside");
                btn.innerText = userName.value;
                btn.addEventListener('click', getName);
                container.appendChild(btn);
            }
            fg=0;
        }
    }
}
