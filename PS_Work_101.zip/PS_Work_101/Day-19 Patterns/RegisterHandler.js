export function RegisterEventHandler(element, eventName, Handler) {
    if (window.addEventListener) element.addEventListener(eventName, Handler);
    else if (window.attachEvent) {
      element.attachEvent(eventName, Handler);
    } else {
      element["on" + eventName] = Handler;
    }
  }
  