// to compile tsc filename.ts
// to run node filename.js
// to have a watch tsc filename.ts --watch
// To convert in to ES6 run 
// tsc filename.ts -t "ES6"
// var company: Icompany = {name:'Sapient', location: 'Bangalore', xyz: 123};
var company = { name: 'Sapient', location: 'Bangalore' };
let arrayOfCompanies = [
    { name: 'IBM', location: 'Pune' },
    { name: 'SAP', location: 'Delhi' },
    { name: 'LG', location: 'Chitradurga' },
    { name: 'HP', location: 'Banglore' },
];
var Designation;
(function (Designation) {
    Designation[Designation["Developer"] = 0] = "Developer";
    Designation[Designation["Tester"] = 1] = "Tester";
    Designation[Designation["TeamLead"] = 2] = "TeamLead";
    Designation[Designation["architect"] = 3] = "architect";
})(Designation || (Designation = {}));
let designation;
designation = Designation.Tester;
console.log(designation); //number value
console.log(Designation[designation]);
class Car {
    // constructor();
    // constructor(name:string){
    //     this.name = name;
    // }  
    constuctor(name = "i20", speed = 100) {
        this.id = 10;
        this.name = name;
        this.speed = speed;
    }
    accelerate() {
        console.log(`The Id : ${this.id}`);
    }
}
let carObj = new Car();
carObj.name = "Mustang GT";
carObj.speed = 340;
// console.log(carObj.name, carObj.speed, carObj.id);
// id will throw an error, as it is private . So
console.log(carObj.name, carObj.speed);
class CPerson {
}
let emp = new CPerson();
// New in functions
// functions as a parameter
function BinaryOp(theOperation) {
    let theResult = theOperation(10, 20);
    console.log(theResult);
}
// Acts as function pointers in C++;
// the below functions signatures shld be same as operation signature
BinaryOp(function (x, y) {
    return x + y;
});
// BinaryOp(function (x:number,y:number):void{
//     return x + y;
// });  // error
let Add = (x, y) => x + y;
BinaryOp(Add);
// OR
BinaryOp((x, y) => x + y);
BinaryOp((x, y) => x - y);
BinaryOp((x, y) => x * y);
BinaryOp((x, y) => x / y);
// Genrics   =>  allows to get type as argument
// let cars = new Array();
// To assign a type :string can be used
// Another method is shown here
// let cars:string[] = new Array();  // First Way !!!!!!!
// OR
let cars = new Array(); // Second Way !!!!!!!
cars[0] = 'BMW';
console.log(cars[0]);
// cars[1] = 123;
// Enhanced Class Syntax
class EnhancedProduct {
    constructor(title, price, rating, likes, imageUrl) {
        this.title = title;
        this.price = price;
        this.rating = rating;
        this.likes = likes;
        this.imageUrl = imageUrl;
    }
}
let productInstance = new EnhancedProduct();
console.log(productInstance.title);
