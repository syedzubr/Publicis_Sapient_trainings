interface Icompany{
    name: string;
    location: string;
}

// to compile tsc filename.ts
// to run node filename.js
// to have a watch tsc filename.ts --watch

// To convert in to ES6 run 
// tsc filename.ts -t "ES6"



// var company: Icompany = {name:'Sapient', location: 'Bangalore', xyz: 123};
var company: Icompany = {name:'Sapient', location: 'Bangalore'};

// having xyz is error, even removing location is error.

interface Icompany2{
    name: string;
    location?: string;
    printDetails?(): void;
}  // here location is optional paremeter

let arrayOfCompanies: Icompany[] = [
    {name: 'IBM', location: 'Pune'},
    {name: 'SAP', location: 'Delhi'},
    {name: 'LG', location: 'Chitradurga'},
    {name: 'HP', location: 'Banglore'},
]


enum Designation{
    Developer,
    Tester,
    TeamLead,
    architect
}

let designation: Designation;
designation = Designation.Tester;
console.log(designation); //number value
console.log(Designation[designation]);


class Car{
    name: string;
    speed: number;
    private id : number;
    // constructor();
    // constructor(name:string){
    //     this.name = name;
    // }  
    constuctor(name:string="i20", speed:number=100){
        this.id = 10;
        this.name = name;
        this.speed = speed;
    }
    accelerate(){
        console.log(`The Id : ${this.id}`)
    }
}

let carObj:Car = new Car();
carObj.name = "Mustang GT";
carObj.speed = 340;
// console.log(carObj.name, carObj.speed, carObj.id);
// id will throw an error, as it is private . So
console.log(carObj.name, carObj.speed);


interface IPerson{
    name: string;
    age: number;
}

interface IEmployee{
    id: number;
    salary: number;
}

class CPerson implements  IPerson, IEmployee{
    name: string;
    age: number;
    id: number;
    salary: number;
}

let emp:CPerson = new CPerson();

// New in functions
// functions as a parameter


function BinaryOp(theOperation:(x:number,y:number)=>number){
    let theResult = theOperation(10,20);
    console.log(theResult);
}
// Acts as function pointers in C++;
// the below functions signatures shld be same as operation signature


BinaryOp(function (x:number,y:number):number{
    return x + y;
});

// BinaryOp(function (x:number,y:number):void{
//     return x + y;
// });  // error

let Add = (x:number, y:number):number => x+y;
BinaryOp(Add);

// OR
BinaryOp((x:number, y:number):number => x+y);
BinaryOp((x:number, y:number):number => x-y);
BinaryOp((x:number, y:number):number => x*y);
BinaryOp((x:number, y:number):number => x/y);


// Genrics   =>  allows to get type as argument

// let cars = new Array();
// To assign a type :string can be used
// Another method is shown here

// let cars:string[] = new Array();  // First Way !!!!!!!
// OR
let cars:Array<string> = new Array<string>();    // Second Way !!!!!!!
cars[0] = 'BMW';
console.log(cars[0]);
// cars[1] = 123;



// Enhanced Class Syntax
class EnhancedProduct {
    constructor(
        public title?: string,
        public price?: number,
        public rating?: number,
        public likes?: number,
        public imageUrl?: string
    ) {

    }
}

let productInstance: EnhancedProduct = new EnhancedProduct();
console.log(productInstance.title)


// Tuples

let tupleVar: [string, number, number];
tupleVar = ["Tuple", 10, 10];
console.log(tupleVar[0]);

let TwoDArray: Array<[number, number]> = [[10, 20], [30, 40]];

