// let x = 100;  // Type Inference
// x = "Hello";

let x:number;  // Type annotation
let str: string;
let bool: boolean;
let i:any;
i = "string";
i = 123;
i = {name: "sea"};
console.log(typeof i);  
// To run node filename.js after compiling with .ts
// to compile tsc filename.ts
// To run chk 12 line
console.log(x);

// functions
// function Add(x, y){
//     return x+y;
// }

// // Add('12','12'); // In JS x and y would have been strings.
// let result = Add(10, 20);

// function Add(x:number, y:number):number {  //return type of func 
//     return x+y;
// }


function Add(x:number, y:number):number | string {  //return type of func 
    if(x>0)
        return x + y;
    else
        return "X shld be greater than 0";
}

let result: number | string = Add(10,60);
console.log("The result is: " + result); 


function printBooks(author?: string, title?: string){
    // ? means optional parametres
    // In JS all parametres are optional
    console.log("hey syed");
}
printBooks();


function printBooks2(author: string="Unknown", title: string="Unknown"){
    // ? means optional parametres
    // In JS all parametres are optional
    console.log("hey syed 2");
}
printBooks2();

function printBooks3(author: string="Unknown", ...title){
    // if u need title to remain only string then
    // ...title:string[] would be string typing
    console.log(author,title);
}
printBooks3("Ranjit Desai","Mrutunjay", "chava", "Radhey",123);

// Generics
let strArrayGen: Array<string> = new Array<string>();