export default function Add(x,y){
    return x+y;
}

export function Product(x,y){
    return x*y;
}