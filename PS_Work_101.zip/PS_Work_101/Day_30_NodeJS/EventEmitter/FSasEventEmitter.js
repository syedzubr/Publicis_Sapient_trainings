var fs = require("fs");

let allFileData = "";
var readStream = fs.createReadStream("Data.txt");
var writeStream = fs.createWriteStream("Output.txt");

readStream.on("data", function (dataChunck) {
  allFileData +=
    ">>>>>>>>>>>>>>>>>>>> READING CHUNK>>>>>>>>>>>>>>>>>>>>>>" + dataChunck;
});

readStream.on("end", function () {
  writeStream.write(allFileData);
  writeStream.end(); // end of writing !
});
