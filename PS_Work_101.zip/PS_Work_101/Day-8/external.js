var x,
y=
101;
function testX(){
    var x = 10;
    console.log(x);
}