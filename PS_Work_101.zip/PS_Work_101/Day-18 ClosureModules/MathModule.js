/* 
This is an example of ES5.
it is called as revealing pattern.
*/

var MathModule = (function(){

    var Pie = 3.14;
    function Add(x,y){
        return x+y;
    }
    
    function Product(x,y){
        return x*y;
    }
    
    return{
        Addition: Add,
        Multiplication : Product
    };

})();
   
