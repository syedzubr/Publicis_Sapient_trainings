export const environment = {
  enableDebug: false,
  production: true,

  BARCODE_DATA: 'assets/api-data/barcode-data.json',
  PRODUCT_DATA: 'assets/api-data/product.json',
  COUPON_DATA: 'assets/api-data/coupons.json',
  HARDWARE_DATA: 'assets/api-data/hardware-check.json',
  MOBILE_REWARDS_DATA: 'assets/api-data/mobile-rewards.json',
  LOGIN_CREDENTIALS: 'assets/api-data/credential.json',
};
