import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';

import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { TranslateModule } from '@ngx-translate/core';
import { MockComponent } from 'ng2-mock-component';
import { Router, NavigationStart, RouterEvent } from '@angular/router';
import { ReplaySubject } from 'rxjs';
@Component({ selector: 'app-payment', template: '<div></div>' })
class MockPaymentComponent {}

const routerEventRelaySubject = new ReplaySubject<RouterEvent>(1);
const routerMock = {
  events: routerEventRelaySubject.asObservable(),
  navigate: () => {}
};

describe('AppComponent test', () => {
  let app: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
      ],
      declarations: [
        AppComponent,
        MockComponent({ selector: 'app-container' }),
      ],
      providers: [
        {
          provide: Router,
          useValue: routerMock,
        },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    app = fixture.componentInstance;
    fixture.detectChanges();
    router = TestBed.inject(Router);
    spyOn(router, 'navigate');
  });

  it('should create the app', () => {
    expect(app).toBeTruthy();
  });

  it('should return false when url is initialization', () => {
    routerEventRelaySubject.next(new NavigationStart(1, '/initialization', 'imperative', null));
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('should return false when url is initialization', () => {
    routerEventRelaySubject.next(new NavigationStart(1, '/', 'imperative', null));
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('should return false when url is initialization', () => {
    routerEventRelaySubject.next(new NavigationStart(1, '', 'imperative', null));
    expect(router.navigate).toHaveBeenCalled();
  });
});
