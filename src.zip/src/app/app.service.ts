import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

const hardwareToken = 'isHardwareWorking';
@Injectable({
  providedIn: 'root',
})
export class AppService {
  private statusSubject = new BehaviorSubject<boolean>(false);
  statusSubject$ = this.statusSubject.asObservable();

  constructor() {
    const currentHardwareState = window.sessionStorage.getItem(hardwareToken);
    if (!currentHardwareState) {
      window.sessionStorage.setItem(hardwareToken, 'false');
    }
  }

  setStatus(state: boolean): void {
    this.statusSubject.next(state);
  }

  get hardwareStatus(): boolean {
    return window.sessionStorage.getItem(hardwareToken) === 'true';
  }

  set hardwareStatus(state: boolean) {
    window.sessionStorage.setItem(hardwareToken, String(state));
  }
}
