import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from 'app/services/cart-table/product.interface';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root',
})
export class BarcodeDataService {
  constructor(private httpClient: HttpClient) {}

  fetchAllProducts(): Observable<Product[]> {
    return this.httpClient.get<Product[]>(environment.BARCODE_DATA);
  }
}
