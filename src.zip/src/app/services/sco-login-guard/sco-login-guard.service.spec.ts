import { TestBed } from '@angular/core/testing';

import { ScoLoginGuardService } from './sco-login-guard.service';

describe('ScoLoginGuardService', () => {
  let service: ScoLoginGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ScoLoginGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set the variable', () => {
    service.goToSelfCheckOut = true;

    expect(service['forwardToCheckOut']).toEqual(true);

    expect(service.goToSelfCheckOut).toEqual(true);
  });
});
