import { HttpErrorResponse } from '@angular/common/http';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from 'environments/environment';
import { throwError } from 'rxjs';
import { CredentialsService } from './credentials.service';

describe('CredentialsService', () => {
  let service: CredentialsService;
  let httpMock: HttpTestingController;
  let serviceSpy: jasmine.SpyObj<CredentialsService>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CredentialsService],
    });
    service = TestBed.inject(CredentialsService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  it('Observable - Data is being fetched', () => {
    const mockCreds = [
      {
        username: 12345,
        password: 543,
      },
      {
        username: 23456,
        password: 654,
      },
    ];

    service.fetchAllCredentials().subscribe((data) => {
      expect(data.length).toBe(2);
    });

    const mockRequest = httpMock.expectOne(environment.LOGIN_CREDENTIALS);
    expect(mockRequest.request.method).toBe('GET');
    mockRequest.flush(mockCreds);
    httpMock.verify();
  });

  it('Observable - Invalid or No data', () => {
    const mockError = {
      message: '404 NOT FOUND',
      status: 404,
      statusText: 'NOT FOUND',
    };

    serviceSpy = jasmine.createSpyObj(CredentialsService, [
      'fetchAllCredentials',
    ]);

    serviceSpy.fetchAllCredentials.and.returnValue(throwError(mockError));

    service.fetchAllCredentials().subscribe(
      () => {},
      (error: HttpErrorResponse) => {
        expect(error).toBeTruthy();
        expect(error.message).toBe('404 NOT FOUND');
      }
    );
  });
});
