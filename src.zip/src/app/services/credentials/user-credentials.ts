export interface UserCredentials {
  username: number;
  password: number;
}
