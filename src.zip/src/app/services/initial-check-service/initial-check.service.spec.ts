import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { InitialCheckService } from './initial-check.service';
import { environment } from 'environments/environment';
import { HardwareCheck } from 'app/services/initial-check-service/hardware-check.interface';

describe('InitialCheckService', () => {
  let service: InitialCheckService;
  let httpMock: HttpTestingController;
  let serviceSpy: jasmine.SpyObj<InitialCheckService>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [InitialCheckService],
    });
    service = TestBed.inject(InitialCheckService);
    httpMock = TestBed.inject(HttpTestingController);
    serviceSpy = jasmine.createSpyObj(InitialCheckService, ['getHardwareData']);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Data is being fetched', () => {
    const data = [
      {
        printer: true,
        scanner: true,
        barCodeReader: true,
      },
    ];

    service.getHardwareData().subscribe((response) => {
      expect(response).toBeTruthy();
    });

    const mockRequest = httpMock.expectOne(environment.HARDWARE_DATA);
    expect(mockRequest.request.method).toBe('GET');
    mockRequest.flush(data);
    httpMock.verify();
  });

  it('Http Get gives Invalid or no data', () => {
    const mockError = {
      message: '404 NOT FOUND',
      status: 404,
      statusText: 'NOT FOUND',
    };
    serviceSpy.getHardwareData.and.returnValue(throwError(mockError));
    serviceSpy.getHardwareData().subscribe(
      (data: HardwareCheck) => {},
      (error: HttpErrorResponse) => {
        expect(error).toBeTruthy();
        expect(error.message).toBe('404 NOT FOUND');
      }
    );
  });
  describe('initCheck', () => {
    it('should return working status as true when all components are working', () => {
      const sampleData: HardwareCheck = {
        printer: true,
        scanner: true,
        barCodeReader: true,
      };
      service.setHardwareData(sampleData);
      expect(service.initCheck()).toBe(true);
    });
    it('should return working status as false when any one component is not working', () => {
      const sampleData: HardwareCheck = {
        printer: true,
        scanner: false,
        barCodeReader: true,
      };
      service.setHardwareData(sampleData);
      expect(service.initCheck()).toBe(false);
    });
  });
});
