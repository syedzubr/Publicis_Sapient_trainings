export interface HardwareCheck {
  printer: boolean;
  scanner: boolean;
  barCodeReader: boolean;
}
