import { TestBed } from '@angular/core/testing';

import { LandingGuardService } from './landing-guard.service';

describe('GaurdService', () => {
  let service: LandingGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LandingGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set the payment variable', () => {
    service.goToPayment = true;

    expect(service['forwardToPayment']).toEqual(true);

    expect(service.goToPayment).toEqual(true);
  });

  it('should set the selfCheckout variable', () => {
    service.goToSelfCheckout = true;

    expect(service['forwardToSelfCheckout']).toEqual(true);

    expect(service.goToSelfCheckout).toEqual(true);
  });
});
