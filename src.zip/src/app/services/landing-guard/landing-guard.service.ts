import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class LandingGuardService {
  private forwardToPayment: boolean;
  private forwardToSelfCheckout: boolean;

  set goToPayment(goToPayment: boolean) {
    this.forwardToPayment = goToPayment;
  }

  get goToPayment(): boolean {
    return this.forwardToPayment;
  }

  set goToSelfCheckout(goToSelfCheckout: boolean) {
    this.forwardToSelfCheckout = goToSelfCheckout;
  }

  get goToSelfCheckout(): boolean {
    return this.forwardToSelfCheckout;
  }
}
