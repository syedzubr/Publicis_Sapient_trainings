import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CardTableBridgeService } from '../card-table-bridge-service/card-table-bridge.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { Product } from './product.interface';
import { tap } from 'rxjs/operators';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CartProductService {
  constructor(
    private httpClient: HttpClient,
    private cartbridge: CardTableBridgeService
  ) {}
  products: Product[] = [];

  start: Product = this.products[0];

  selectedItem = new BehaviorSubject<Product>(this.start);
  selectedSource = this.selectedItem.asObservable();

  intiallength = new BehaviorSubject<number>(this.products.length);
  length = this.intiallength.asObservable();

  initialPrice: number = this.getTotalPrice();
  price = new BehaviorSubject<number>(this.initialPrice);

  totalPrice = this.price.asObservable();

  fetchAllProduct(): Observable<Product[]> {
    return this.httpClient.get<Product[]>(environment.PRODUCT_DATA).pipe(
      tap((data) => {
        this.products = data;
        this.selectProduct();
        this.nextTotalPrice();
        this.nextTotalLength();
      })
    );
  }

  incrementQuantity(barcode: number): void {
    const product: Product | undefined = this.products.find(
      (data: Product) => data.barcode === barcode
    );
    if (product) {
      product.qty++;
    }
    this.nextTotalPrice();
  }

  decrementQuantity(barcode: number): void {
    const product: Product | undefined = this.products.find(
      (data: Product) => data.barcode === barcode
    );
    if (product) {
      if (product.qty > 1) {
        product.qty--;
      } else {
        this.deleteProduct(product.barcode);
      }
    }
    this.nextTotalPrice();
  }

  deleteProduct(barcode: number): void {
    const product: Product | undefined = this.products.find(
      (data: Product) => data.barcode === barcode
    );
    if (product) {
      const productIndex = this.products.indexOf(product);
      this.products.splice(productIndex, 1);
      this.cartbridge.showProduct(this.products[0]);
      this.selectProduct();
    }
    this.nextTotalPrice();
  }

  addProduct(data: Product): void {
    const product: Product | undefined = this.products.find(
      (productData: Product) => productData.barcode === data.barcode
    );
    if (!product) {
      this.products.push(data);
    } else {
      product.qty++;
    }
    this.nextTotalLength();
    this.nextTotalPrice();
  }

  getTotalPrice(): number {
    let totalPrice = 0;
    this.products.forEach((data) => (totalPrice += data.qty * data.price));
    return totalPrice;
  }

  selectProduct(): void {
    this.selectedItem.next(this.products[0]);
  }

  nextTotalPrice(): void {
    this.price.next(this.getTotalPrice());
  }

  totalProductInCart(): number {
    return this.products.length;
  }

  nextTotalLength(): void {
    this.intiallength.next(this.products.length);
  }
}
