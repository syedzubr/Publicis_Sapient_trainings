import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Product } from '../cart-table/product.interface';

@Injectable({
  providedIn: 'root',
})
export class CardTableBridgeService {
  private productIdSource = new BehaviorSubject<Product>({
    productId: 0,
    productName: '',
    price: 0,
    productUrl: '',
    qty: 0,
    barcode: 0,
    sku: 0,
  });

  productIdSource$ = this.productIdSource.asObservable();

  showProduct(product: Product): void {
    this.productIdSource.next(product);
  }
}
