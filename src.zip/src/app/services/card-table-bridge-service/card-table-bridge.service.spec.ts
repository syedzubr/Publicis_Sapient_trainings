import { TestBed } from '@angular/core/testing';
import { skip } from 'rxjs/operators';
import { Product } from '../cart-table/product.interface';
import { CardTableBridgeService } from './card-table-bridge.service';

describe('CardTableBridgeService', () => {
  let bridgeService: CardTableBridgeService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CardTableBridgeService],
    });
    bridgeService = TestBed.inject(CardTableBridgeService);
  });

  it('should be created', () => {
    expect(bridgeService).toBeTruthy();
  });

  it('should receive default object on subscription', () => {
    const defaultData: Product = {
      productId: 0,
      productName: '',
      price: 0,
      productUrl: '',
      qty: 0,
      barcode: 0,
      sku: 0,
    };

    bridgeService.productIdSource$.subscribe((payload: Product) => {
      // payload check for undefined or null
      expect(payload).toBeTruthy();

      // payload check to see if default object received on subscription
      expect(payload).toEqual(defaultData);
    });
  });

  it('showProduct should push correct object', () => {
    const testData: Product = {
      productId: 123,
      productName: 'Brown Bread',
      price: 0.75,
      productUrl: '',
      qty: 1,
      barcode: 1234567,
      sku: 98765432,
    };

    // Call to check if testData was passed, after skipping default data
    bridgeService.productIdSource$
      .pipe(skip(1))
      .subscribe((payload: Product) => {
        // payload check for undefined or null
        expect(payload).toBeTruthy();

        // payload check to see if correct object was received
        expect(payload).toEqual(testData);
      });

    bridgeService.showProduct(testData);
  });
});
