import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class PaymentGuardService {
  private paymentSuccessful: boolean;

  set paymentSuccess(paymentStatus: boolean) {
    this.paymentSuccessful = paymentStatus;
  }

  get paymentSuccess(): boolean {
    return this.paymentSuccessful;
  }
}
