import { ProductDetailComponent } from 'app/molecules/product-detail/product-detail.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TranslateModule } from '@ngx-translate/core';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { Product } from 'app/services/cart-table/product.interface';
import { CardTableBridgeService } from 'app/services/card-table-bridge-service/card-table-bridge.service';
import { skip } from 'rxjs/operators';

describe('ProductDetailComponent', () => {
  let component: ProductDetailComponent;
  let fixture: ComponentFixture<ProductDetailComponent>;

  let product: Product[];
  let cartService: CartProductService;
  let bridgeService: CardTableBridgeService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, TranslateModule.forRoot()],
      declarations: [ProductDetailComponent],
      providers: [CartProductService, CardTableBridgeService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductDetailComponent);
    component = fixture.componentInstance;
    cartService = TestBed.inject(CartProductService);
    bridgeService = TestBed.inject(CardTableBridgeService);
    fixture.detectChanges();

    product = [
      {
        productId: 4,
        productName: 'Alphonso Mango, 1kg',
        price: 4.0,
        productUrl: 'assets/products/mango.jpg',
        qty: 1,
        barcode: 123456789042,
        sku: 154398,
      },
      {
        productId: 5,
        productName: 'Kiwi, 500gm',
        price: 2.0,
        productUrl: 'assets/products/kiwi.jpg',
        qty: 1,
        barcode: 123456789872,
        sku: 154399,
      },
      {
        productId: 2,
        productName: 'Fresh Avocado, 1pc',
        price: 0.75,
        productUrl: 'assets/products/avacado.jpg',
        qty: 3,
        barcode: 123456789022,
        sku: 154390,
      },
    ];
  });

  it('Fetching the Data from Service', () => {
    const testData: Product = {
      productId: 123,
      productName: 'Brown Bread',
      price: 0.75,
      productUrl: '',
      qty: 1,
      barcode: 1234567,
      sku: 98765432,
    };

    spyOn(bridgeService, 'showProduct');
    bridgeService.showProduct(testData);
    component.ngOnInit();
    bridgeService.productIdSource$.pipe(skip(1)).subscribe((response) => {
      expect(response).toEqual(testData);
      expect(response.barcode).toBe(testData.barcode);
    });
  });

  describe('incrementProduct', () => {
    it('should set disable quantity to false', () => {
      component.incrementProduct(product[0].barcode);
      expect(component.disableQuantitybtn).toBe(false);
    });

    it('should call incrementQuantity', () => {
      spyOn(cartService, 'incrementQuantity');
      component.incrementProduct(product[0].barcode);
      expect(cartService.incrementQuantity).toHaveBeenCalledWith(
        product[0].barcode
      );
    });
  });

  describe('deleteItem', () => {
    it('should call deleteProduct of cartService if number of products are greater than 1', () => {
      cartService.products = product;
      component.deleteItem(product[0].barcode);
      expect(cartService.products.length).toBe(2);
    });

    it('should set disabledeletebtn to false if number of products is less than 1', () => {
      const data = [];
      cartService.products = data;
      component.deleteItem(123456789042);
      expect(component.disableDeleteBtn).toBe(true);
    });
  });

  describe('decrementProduct', () => {
    it('should call decrementQuantity of service if number of products are greater than 1 and quantity is greater than equal to 1', () => {
      component.product = product[2];
      cartService.products = product;
      component.decrementProduct(product[2].barcode);
      expect(component.product.qty).toBe(2);
    });

    it('should not decrease quantity if number of products and quantity is equal to 1', () => {
      const data: Product[] = [
        {
          productId: 6,
          productName: 'Orange, 1kg',
          price: 4.0,
          productUrl: 'assets/products/orange.jpg',
          qty: 1,
          barcode: 123476589042,
          sku: 154400,
        },
      ];
      component.product = data[0];
      cartService.products = data;
      spyOn(cartService, 'decrementQuantity');
      component.decrementProduct(data[0].barcode);
      expect(component.disableQuantitybtn).toBe(true);
    });

    it('should not decrease quantity if number of products is 1 and quantity is greater than 1', () => {
      const data: Product[] = [
        {
          productId: 6,
          productName: 'Orange, 1kg',
          price: 4.0,
          productUrl: 'assets/products/orange.jpg',
          qty: 2,
          barcode: 123476589042,
          sku: 154400,
        },
      ];
      cartService.products = data;
      component.decrementProduct(data[0].barcode);
      spyOn(cartService, 'decrementQuantity');
      expect(component.disableQuantitybtn).toBe(false);
      expect(cartService.products[0].qty).toBe(1);
    });
  });

  it('Testing for Unsubscription', () => {
    spyOn(component.cartbridgeSubscription, 'unsubscribe');
    component.ngOnDestroy();
    expect(component.cartbridgeSubscription.unsubscribe).toHaveBeenCalledTimes(1);
  });
});
