import { CartRowComponent } from './cart-row.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('CartRowComponent', () => {
  let component: CartRowComponent;
  let fixture: ComponentFixture<CartRowComponent>;

  const products = {
    productId: 1,
    productName: 'test',
    price: 120,
    productUrl: 'test',
    qty: 3,
    barcode: 1234,
    sku: 123,
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), HttpClientTestingModule],

      declarations: [CartRowComponent],
    });

    fixture = TestBed.createComponent(CartRowComponent);

    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check if sendProductDetails function is emitting correctly', () => {
    spyOn(component.productDetails, 'emit');

    component.sendProductDetails(products);

    expect(component.productDetails.emit).toHaveBeenCalledWith(products);
  });

  it('should check if sendProductDetails function is emitting incorrectly', () => {
    spyOn(component.productDetails, 'emit');

    component.sendProductDetails(products);

    expect(component.productDetails.emit).not.toHaveBeenCalledWith('products');
  });
});
