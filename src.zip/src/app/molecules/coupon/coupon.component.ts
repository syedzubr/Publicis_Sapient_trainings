import {
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { CouponCode } from 'app/services/apply-coupon/coupon-code.interface';
import { ApplyCouponService } from 'app/services/apply-coupon/apply-coupon.service';
import { Subscription, timer } from 'rxjs';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-coupon',
  templateUrl: './coupon.component.html',
  styleUrls: ['./coupon.component.scss'],
})
export class CouponComponent implements OnInit, OnDestroy {
  @ViewChild('enteredNumber') enteredNumber: ElementRef;

  dataSubscribe: Subscription;
  inputString = '';
  valueAdded = false;
  couponCodes: CouponCode[] = [];
  searchedData: CouponCode | undefined;
  setError = false;
  noError = false;

  constructor(
    private couponService: ApplyCouponService,
    public dialogRef: MatDialogRef<CouponComponent>,
    private cartService: CartProductService
  ) {}

  ngOnInit(): void {
    this.dataSubscribe = this.couponService
      .fetchAllCoupon()
      .subscribe((details: CouponCode[]) => {
        this.couponCodes = details;
      });
  }

  handleClick(id: string): void {
    if (id === 'backspace') {
      this.inputString = this.inputString.slice(0, -1);
    } else if (id && id !== 'done') {
      this.inputString = this.inputString + id;
    }
    this.enteredNumber.nativeElement.value = this.inputString;
    this.valueAdded = true;
    if (id === 'done') {
      this.applyDiscount();
    }
  }

  applyDiscount(): void {
    if (this.inputString) {
      const temp: number = parseInt(this.inputString, 10);
      this.searchedData = this.couponCodes.find(
        (item) => item.couponCode === temp
      );

      if (this.searchedData) {
        this.noError = true;
        this.couponService.updateDiscount(this.searchedData.discountPercent);
        this.cartService.nextTotalPrice();
        this.setError = false;
        timer(1000).subscribe(() => {
          this.dialogRef.close();
        });
      } else {
        this.setError = true;
        this.noError = false;
      }
    }
  }

  ngOnDestroy(): void {
    this.dataSubscribe.unsubscribe();
  }
}
