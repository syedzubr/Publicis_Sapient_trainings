import { Component, ViewEncapsulation } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { ButtonType } from 'app/atoms/models/common.model';
import { LandingGuardService } from 'app/services/landing-guard/landing-guard.service';

@Component({
  selector: 'app-void-transaction',
  templateUrl: './void-transaction.component.html',
  styleUrls: ['./void-transaction.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class VoidTransactionComponent {
  public btnType = ButtonType;

  constructor(
    private dialogRef: MatDialogRef<VoidTransactionComponent>,
    private landingGuardService: LandingGuardService
  ) {}

  public redirectToSelfCheckout(): void {
    this.landingGuardService.goToSelfCheckout = true;
    this.dialogRef.close();
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }
}
