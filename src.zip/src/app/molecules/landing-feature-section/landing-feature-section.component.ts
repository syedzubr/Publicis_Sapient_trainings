import { ButtonType } from 'app/atoms/models/common.model';
import {
  Component,
  ElementRef,
  EventEmitter,
  OnInit,
  Output,
  ViewChild,
  ViewEncapsulation,
  OnDestroy,
} from '@angular/core';

import { LandingGuardService } from 'app/services/landing-guard/landing-guard.service';
import { MobileRewardsService } from 'app/services/mobile-rewards/mobile-rewards.service';
import { takeUntil, filter } from 'rxjs/operators';
import { Subject } from 'rxjs/internal/Subject';

@Component({
  selector: 'app-landing-feature-section',
  templateUrl: './landing-feature-section.component.html',
  styleUrls: ['./landing-feature-section.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LandingFeatureSectionComponent implements OnInit, OnDestroy {
  @Output() outputEmitter: EventEmitter<string> = new EventEmitter();
  @Output() action: EventEmitter<void> = new EventEmitter();
  @ViewChild('changeName') changeName: ElementRef;
  primaryButton = ButtonType.PRIMARY_BUTTON;
  secondaryButton = ButtonType.SECONDARY_BUTTON;
  anyData: string;
  userValid = false;
  userName = 'John Doe';
  pointsEarned;

  private unsusbcribe = new Subject<void>();

  constructor(
    private landingGaurdService: LandingGuardService,
    private mobileRewardService: MobileRewardsService
  ) {}

  ngOnInit(): void {
    this.mobileRewardService.rewardPoints$
      .pipe(
        takeUntil(this.unsusbcribe),
        filter((data) => !!data)
      )
      .subscribe((data: any) => {
        this.pointsEarned = data.points;
        this.userName = data.name;
        this.userValid = true;
      });
  }

  setActionType(): void {
    this.landingGaurdService.goToPayment = true;
  }

  emitOpeningEvent($event: any): void {
    if ($event !== null) {
      this.anyData = $event;
      this.outputEmitter.emit(this.anyData);
    }
  }

  editName(): void {
    this.changeName.nativeElement.disabled = !this.changeName.nativeElement
      .disabled;
    this.changeName.nativeElement.size = this.changeName.nativeElement.value.length;
  }

  public ngOnDestroy(): void {
    this.unsusbcribe.next();
    this.unsusbcribe.complete();
  }
}
