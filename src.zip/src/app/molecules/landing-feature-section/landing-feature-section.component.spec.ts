import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MaterialModule } from 'app/modules/shared/material/material.module';
import { LandingGuardService } from 'app/services/landing-guard/landing-guard.service';
import { MobileRewardsService } from 'app/services/mobile-rewards/mobile-rewards.service';
import { MockComponent } from 'ng2-mock-component';
import { of, Subscription } from 'rxjs';
import { CouponComponent } from '../coupon/coupon.component';
import { UnlockRewardsComponent } from '../unlock-rewards/unlock-rewards.component';
import { LandingFeatureSectionComponent } from './landing-feature-section.component';

describe('Landing Feature Section Component', () => {
  class MockLandingGuardService {
    private forwardToPayment: boolean;

    constructor() {}

    set goToPayment(goToPayment: boolean) {
      this.forwardToPayment = goToPayment;
    }

    get goToPayment(): boolean {
      return this.forwardToPayment;
    }
  }
  let component: LandingFeatureSectionComponent;
  let fixture: ComponentFixture<LandingFeatureSectionComponent>;
  let changeNameChild;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        MaterialModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule,
      ],
      declarations: [
        LandingFeatureSectionComponent,
        CouponComponent,
        UnlockRewardsComponent,
        MockComponent({
          selector: 'app-button',
          inputs: ['type', 'label', 'routerLink'],
        }),
        MockComponent({
          selector: 'app-payment-summary',
        }),
        MockComponent({
          selector: 'app-on-screen-keypad',
        }),
        MockComponent({
          selector: 'app-popover',
        }),
      ],
      providers: [
        {
          provide: LandingGuardService,
          useClass: MockLandingGuardService,
        },
        {
          provide: MobileRewardsService,
          useValue: {
            rewardPoints$: of({
              points: '22',
              name: 'John'
            })
          }
        }
      ],
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [UnlockRewardsComponent],
      },
    });

    fixture = TestBed.createComponent(LandingFeatureSectionComponent);
    component = fixture.componentInstance;

    // The next line needs to be there so that the input component for ViewChild is rendered.
    component.userValid = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check if emitRewards function is emitting correctly', () => {
    spyOn(component.outputEmitter, 'emit');

    component.emitOpeningEvent('UNLOCK REWARDS');

    expect(component.outputEmitter.emit).toHaveBeenCalledWith('UNLOCK REWARDS');
  });

  it('should check if emitRewards function is emitting incorrectly', () => {
    spyOn(component.outputEmitter, 'emit');

    component.emitOpeningEvent('UNLOCK REWARDS');

    expect(component.outputEmitter.emit).not.toHaveBeenCalledWith('UNLOCK');
  });

  it('should check if emitRewards function is emitting null data or not', () => {
    spyOn(component.outputEmitter, 'emit');

    component.emitOpeningEvent(null);

    expect(component.outputEmitter.emit).not.toHaveBeenCalled();
  });

  it('should check if goToPayment is set', () => {
    const landingGuardService = TestBed.inject(LandingGuardService);

    component.setActionType();

    expect(landingGuardService.goToPayment).toBeTrue();
  });

  describe('View Child Testing', () => {
    beforeEach(() => {
      changeNameChild = component.changeName.nativeElement;
      changeNameChild.disabled = false;
    });

    it('should create changeName using ViewChild', () => {
      expect(changeNameChild).toBeTruthy();
    });

    it('should check if editName function is making child disabled.', () => {
      component.editName();

      expect(changeNameChild.disabled).toBe(true);
    });

    it('should check if editName function is making child enabled.', () => {
      changeNameChild.disabled = true;

      component.editName();

      expect(changeNameChild.disabled).toBe(false);
    });
  });

  describe('ngOnInit', () => {
    it('should subcribe to rewardPoints$ and set the values', () => {
      component.ngOnInit();

      expect(component.userName).toEqual('John');
      expect(component.pointsEarned).toEqual('22');

    });
  });
});
