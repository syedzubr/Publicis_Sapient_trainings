import { BarcodeSearchPopupComponent } from './barcode-search-popup.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule } from '@angular/forms';
import { MockComponent } from 'ng2-mock-component';
import { of } from 'rxjs';
import { BarcodeDataService } from 'app/services/barcode-data/barcode-data.service';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { Product } from 'app/services/cart-table/product.interface';
import { ElementRef } from '@angular/core';

describe('BarcodeSearchPopupComponent', () => {
  let mockDataService;
  let mockCartService;

  let component: BarcodeSearchPopupComponent;
  let fixture: ComponentFixture<BarcodeSearchPopupComponent>;
  beforeEach(async () => {
    mockCartService = jasmine.createSpyObj(['addProduct']);

    mockDataService = jasmine.createSpyObj(['fetchAllProducts']);
    mockDataService.fetchAllProducts.and.returnValue(
      of([
        {
          productId: 1,
          productName: 'Country fresh tomatoes, 500gms',
          price: 2.5,
          productUrl: 'assets/products/tomatoes.jpg',
          qty: 1,
          barcode: 123456789012,
          sku: 154397,
        },
        {
          productId: 2,
          productName: 'Fresh Avocado, 1pc',
          price: 0.75,
          productUrl: 'assets/products/avacado.jpg',
          qty: 3,
          barcode: 123456789022,
          sku: 154390,
        },
        {
          productId: 3,
          productName: 'Organic Grapes, 500gms',
          price: 1.5,
          productUrl: 'assets/products/grapes.jpg',
          qty: 1,
          barcode: 123456789032,
          sku: 154397,
        },
      ])
    );
    await TestBed.configureTestingModule({
      declarations: [
        BarcodeSearchPopupComponent,
        MockComponent({
          selector: 'app-button',
          inputs: ['label', 'width', 'type', 'height'],
        }),

        MockComponent({
          selector: 'app-on-screen-keypad',
        }),

        MockComponent({
          selector: 'app-popover',
        }),

        MockComponent({
          selector: 'app-cart-navigation',
        }),
      ],
      imports: [
        MatDialogModule,
        MatButtonModule,
        MatIconModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
        FormsModule,
      ],
      providers: [
        { provide: BarcodeDataService, useValue: mockDataService },
        { provide: CartProductService, useValue: mockCartService },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BarcodeSearchPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should change search type to sku from barcode', () => {
    component.changeSearchType('sku');
    expect(component.searchType).toEqual('sku');
  });

  it('should return the particular string on pressing number on number keypad', () => {
    component.handleClick('1');
    component.handleClick('2');
    component.handleClick('3');
    // Now our string our textfield will be 123, its just like pressing buttons 1, 2, and 3
    expect(component.inputString).toEqual('123');
  });

  it('should return the particular string on pressing backspace on number keypad', () => {
    component.handleClick('1');
    component.handleClick('2');
    component.handleClick('3');
    component.handleClick('backspace');
    // Now our string our textfield will be 123, its just like pressing buttons 1, 2, and 3
    // Now we press delete button,
    expect(component.inputString).toEqual('12');
  });

  it('should call search on pressing done', () => {
    spyOn(component, 'search');
    component.handleClick('1');
    component.handleClick('2');
    component.handleClick('3');
    component.handleClick('done');
    // Now our string our textfield will be 123, its just like pressing buttons 1, 2, and 3
    // Now we press done button,
    expect(component.search).toHaveBeenCalled();
  });

  it('should fetch data from the service', () => {
    component.ngOnInit();
    expect(component.products.length).toEqual(3);
  });

  it('should check if searched data is present for barcode searchType', () => {
    component.ngOnInit();
    component.searchType = 'barcode';
    component.inputString = '123';
    component.search();
    expect(component.searchedData.length).toEqual(3);
  });

  it('should check if searched data is present for sku searchType', () => {
    component.ngOnInit();
    component.searchType = 'sku';
    component.inputString = '123';
    component.search();
    expect(component.searchedData).toBeTruthy();
  });

  it('should check if searched data return correct result string', () => {
    component.ngOnInit();
    component.inputString = '123';
    component.search();
    expect(component.resultString).toEqual('3 results found for "123"');
  });

  it('should navigate up on pressing up button', () => {
    component.ngOnInit();
    component.inputString = '123';
    component.search();
    component.selectedIndex = 1;
    component.selectedId = 123456789022;
    component.eachRow = fixture.nativeElement;
    fixture.detectChanges();
    spyOnProperty(
      component.panel.nativeElement,
      'clientHeight'
    ).and.returnValue(1000);

    spyOnProperty(
      component.eachRow.nativeElement,
      'clientHeight'
    ).and.returnValue(100);
    component.navigate('up');
    expect(component.selectedIndex).toEqual(0);
  });

  it('should navigate down on pressing down button', () => {
    component.ngOnInit();
    component.inputString = '123';
    component.search();
    component.selectedIndex = 1;
    component.selectedId = 123456789022;
    component.eachRow = fixture.nativeElement;
    fixture.detectChanges();
    spyOnProperty(
      component.panel.nativeElement,
      'clientHeight'
    ).and.returnValue(1000);
    spyOnProperty(
      component.eachRow.nativeElement,
      'clientHeight'
    ).and.returnValue(100);
    component.navigate('down');
    expect(component.selectedIndex).toEqual(2);
  });

  it('should add product on click of Add', () => {
    component.addProduct(123456789022);
    expect(mockCartService.addProduct).toHaveBeenCalled();
  });

  it('should not set search type when it is empty', () => {
    component.changeSearchType('');

    expect(component.searchType).toEqual('barcode');
  });

  it('should not do anything when productBarcode is null', () => {
    component.addProduct(null);

    expect(mockCartService.addProduct).not.toHaveBeenCalled();
  });

  it('should not do anything when productBarcode is not valid', () => {
    component.addProduct(343413434);

    expect(mockCartService.addProduct).not.toHaveBeenCalled();
  });

  it('should not return anything when the input is empty', () => {
    component.handleClick('');
    expect(component.inputString).toEqual('');
  });
});
