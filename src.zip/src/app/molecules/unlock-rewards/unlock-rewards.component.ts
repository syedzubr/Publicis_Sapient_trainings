import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MobileRewardsService } from 'app/services/mobile-rewards/mobile-rewards.service';
import { Rewards } from 'app/services/mobile-rewards/mobile-rewards.interface';

@Component({
  selector: 'app-unlock-rewards',
  templateUrl: './unlock-rewards.component.html',
  styleUrls: ['./unlock-rewards.component.scss'],
})
export class UnlockRewardsComponent implements OnInit {
  @ViewChild('enteredNumber') enteredNumber: ElementRef;

  inputString: string;
  valueAdded: boolean;
  rewards: Rewards[] = [];
  searchedData: Rewards | undefined;
  setError = false;
  noError = false;

  constructor(
    private mobilerewardservice: MobileRewardsService,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.mobilerewardservice
      .fetchCustomerData()
      .subscribe((details: Rewards[]) => {
        this.rewards = details;
      });
    this.inputString = '';
  }

  numberPassed(no: any): void {
    if (no === 'backspace') {
      this.inputString = this.inputString.slice(0, -1);
    } else if (no && no !== 'done') {
      this.inputString = this.inputString + no;
    }
    this.enteredNumber.nativeElement.value = this.inputString;
    this.valueAdded = true;
    if (no === 'done') {
      this.setError = false;
      this.noError = false;
      this.reward();
    }
  }
  reward(): void {
    if (this.inputString) {
      const temp: number = parseInt(this.inputString, 10);
      this.searchedData = this.rewards.find((item) => item.mobile === temp);
      if (this.searchedData && this.searchedData.id) {
        this.mobilerewardservice.updateRewardPoints(this.searchedData);
        this.noError = true;
        this.dialog.closeAll();
      } else {
        this.setError = true;
      }
    }
  }
}
