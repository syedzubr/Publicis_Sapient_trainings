import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { MobileRewardsService } from 'app/services/mobile-rewards/mobile-rewards.service';
import { MockComponent } from 'ng2-mock-component';
import { of } from 'rxjs';
import { UnlockRewardsComponent } from './unlock-rewards.component';

describe('UnlockRewardsComponent', () => {
  let mockDataService;
  let component: UnlockRewardsComponent;
  let fixture: ComponentFixture<UnlockRewardsComponent>;

  beforeEach(async () => {
    mockDataService = jasmine.createSpyObj([
      'fetchCustomerData',
      'updateRewardPoints',
    ]);
    mockDataService.fetchCustomerData.and.returnValue(
      of([
        {
          id: 1,
          mobile: 1234567890,
          points: 25,
          name: 'John Doe',
        },
        {
          id: 2,
          mobile: 8160052926,
          points: 30,
          name: 'Parth Vaghela',
        },
        {
          id: 3,
          mobile: 9466980495,
          points: 20,
          name: 'Bhanu',
        },
      ])
    );
    await TestBed.configureTestingModule({
      declarations: [
        UnlockRewardsComponent,
        MockComponent({
          selector: 'app-on-screen-keypad',
        }),

        MockComponent({
          selector: 'app-popover',
        }),
      ],
      imports: [
        MatDialogModule,
        MatIconModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
        FormsModule,
      ],
      providers: [{ provide: MobileRewardsService, useValue: mockDataService }],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnlockRewardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return the particular number on pressing number on number keypad', () => {
    component.numberPassed('1');
    component.numberPassed('2');
    component.numberPassed('3');
    // Now our string our textfield will be 123, its just like pressing buttons 1, 2, and 3
    expect(component.inputString).toEqual('123');
  });

  it('should return the particular number on pressing backspace on number keypad', () => {
    component.numberPassed('1');
    component.numberPassed('2');
    component.numberPassed('3');
    component.numberPassed('backspace');
    // Now our string our textfield will be 123, its just like pressing buttons 1, 2, and 3
    // Now we press delete button,
    expect(component.inputString).toEqual('12');
  });

  it('should call search on pressing done', () => {
    const spy = spyOn(component, 'reward');
    component.numberPassed('1');
    component.numberPassed('2');
    component.numberPassed('3');
    component.numberPassed('done');
    // Now our string our textfield will be 123, its just like pressing buttons 1, 2, and 3
    // Now we press done button,
    expect(spy).toHaveBeenCalled();
  });

  it('should check if searched data is present for mobile-reward service', () => {
    component.ngOnInit();
    component.inputString = '1234567890';
    component.reward();
    expect(component.searchedData).toEqual({
      id: 1,
      mobile: 1234567890,
      points: 25,
      name: 'John Doe',
    });
  });

  it('should call updateReward service function', () => {
    component.ngOnInit();
    component.inputString = '1234567890';
    component.reward();
    expect(mockDataService.updateRewardPoints).toHaveBeenCalled();
  });

  it('should not find any result from rewards array', () => {
    component.ngOnInit();
    component.inputString = '9090909090';
    component.reward();
    expect(component.setError).toEqual(true);
  });
});
