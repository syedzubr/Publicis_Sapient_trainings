import { PopoverComponent } from './popover.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { MaterialModule } from 'app/modules/shared/material/material.module';
import { RouterTestingModule } from '@angular/router/testing';

describe('PopoverComponent', () => {
  let component: PopoverComponent;
  let fixture: ComponentFixture<PopoverComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PopoverComponent],
      imports: [MaterialModule, RouterTestingModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check if it navigates to self-checkout if on payment page', () => {
    const router = TestBed.inject(Router);
    const spy = spyOn(router, 'navigate');
    spyOnProperty(router, 'url', 'get').and.returnValue('/payment');
    component.navigateToSelfCheckout();
    expect(spy).toHaveBeenCalledWith(['/selfCheckout']);
  });
  it('should check if its on landing page and not navigating anywhere', () => {
    const router = TestBed.inject(Router);
    const spy = spyOn(router, 'navigate');
    spyOnProperty(router, 'url', 'get').and.returnValue('/landing');
    component.navigateToSelfCheckout();
    expect(spy).not.toHaveBeenCalled();
  });
});
