import { OnScreenKeypadComponent } from 'app/atoms/components/on-screen-keypad/on-screen-keypad.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatIconModule } from '@angular/material/icon';

describe('OnScreenKeypadComponent', () => {
  let component: OnScreenKeypadComponent;
  let fixture: ComponentFixture<OnScreenKeypadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MatIconModule],
      declarations: [OnScreenKeypadComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OnScreenKeypadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit done when clicked done', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="done"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('done');
  });

  it('should emit backspace when clicked backspace', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="backspace"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('backspace');
  });

  it('should emit 1 when clicked 1', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="1"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('1');
  });

  it('should emit 2 when clicked 2', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="2"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('2');
  });

  it('should emit 3 when clicked 3', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="3"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('3');
  });

  it('should emit 4 when clicked 4', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="4"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('4');
  });

  it('should emit 5 when clicked 5', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="5"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('5');
  });

  it('should emit 6 when clicked 6', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="6"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('6');
  });

  it('should emit 7 when clicked 7', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="7"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('7');
  });

  it('should emit 8 when clicked 8', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="8"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('8');
  });

  it('should emit 9 when clicked 9', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="9"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('9');
  });

  it('should emit 0 when clicked 0', () => {
    spyOn(component.numberClicked, 'emit');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="0"]'
    );
    button.click();
    expect(component.numberClicked.emit).toHaveBeenCalledWith('0');
  });

  it('should not emit when data is empty', () => {
    spyOn(component.numberClicked, 'emit');
    component.ngOnInit();
    expect(component.numberClicked.emit).not.toHaveBeenCalled();
  });

});
