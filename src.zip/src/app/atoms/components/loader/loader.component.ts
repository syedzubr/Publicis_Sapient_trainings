import { ButtonType } from 'app/atoms/models/common.model';
import {
  Component,
  OnInit,
  Output,
  ViewEncapsulation,
  EventEmitter,
} from '@angular/core';
import { InitialCheckService } from 'app/services/initial-check-service/initial-check.service';
import { Router } from '@angular/router';
import { interval, Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LoaderComponent implements OnInit {
  @Output() sendHardwareStatus = new EventEmitter();

  showSpinner = true;
  crossCircle = false;
  checkCircle = false;
  isHardwareWorking = false;
  progress = 0;
  setInterval$: Observable<number>;
  intervalSubscription: Subscription;
  btnType = ButtonType;

  constructor(
    private initService: InitialCheckService,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.setInterval$ = interval(100);
    this.intervalSubscription = this.setInterval$.subscribe((_: any) => {
      this.checkProgressStatus();
    });

    this.initService.getHardwareData().subscribe();
  }

  checkProgressStatus = () => {
    if (this.progress === 75) {
      this.getDownloadProgress();
    } else if (this.progress === 100) {
      this.changeSpinnerState(false, false);
      this.sendHardwareStatus.emit(true);
    }
    this.progress++;
  }

  getDownloadProgress = () => {
    this.isHardwareWorking = this.initService.initCheck();
    if (!this.isHardwareWorking) {
      this.changeSpinnerState(false, true);
      this.sendHardwareStatus.emit(false);
    }
  }

  changeSpinnerState(isLoading: boolean, isError: boolean): void {
    this.showSpinner = isLoading;
    this.checkCircle = !isError && !isLoading;
    this.crossCircle = isError;

    if (!isLoading) {
      this.intervalSubscription.unsubscribe();
    }
  }

  retryLoader(): void {
    this.progress = 0;
    this.changeSpinnerState(true, false);
    this.intervalSubscription = this.setInterval$.subscribe((_: any) => {
      this.checkProgressStatus();
    });
  }
}
