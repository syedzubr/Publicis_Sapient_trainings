import { LoaderComponent } from 'app/atoms/components/loader/loader.component';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import {
  MatProgressSpinner,
  MatSpinner,
} from '@angular/material/progress-spinner';
import { RouterTestingModule } from '@angular/router/testing';
import { MockComponent } from 'ng2-mock-component';
import { InitialCheckService } from 'app/services/initial-check-service/initial-check.service';
import { interval, Observable, of } from 'rxjs';

describe('LoaderComponent', () => {
  let component: LoaderComponent;
  let fixture: ComponentFixture<LoaderComponent>;
  let httpMock: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        LoaderComponent,
        MatProgressSpinner,
        MatSpinner,

        MockComponent({
          selector: 'app-button',
          inputs: ['label', 'width', 'type', 'height'],
        }),
      ],
      imports: [HttpClientTestingModule, RouterTestingModule],
    }).compileComponents();
  });

  beforeEach(() => {
    httpMock = TestBed.inject(HttpTestingController);
    fixture = TestBed.createComponent(LoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('checkProgressStatus', () => {
    it('should emit true status when hardware is working and progress is 100% and unsubscribe from setInterval$', () => {
      const initServiceSpy = TestBed.inject(InitialCheckService);
      spyOn(initServiceSpy, 'initCheck').and.returnValue(true);
      spyOn(component.sendHardwareStatus, 'emit');
      spyOn(component.intervalSubscription, 'unsubscribe');
      component.progress = 100;

      component.checkProgressStatus();

      expect(component.showSpinner).toBe(false);
      expect(component.checkCircle).toBe(true);
      expect(component.crossCircle).toBe(false);
      expect(component.sendHardwareStatus.emit).toHaveBeenCalledWith(true);
      expect(component.intervalSubscription.unsubscribe).toHaveBeenCalled();
    });

    it('should increase progress when progress <99', () => {
      component.progress = 60;
      component.checkProgressStatus();
      expect(component.progress).toBe(61);
    });

    it('should call init hardware check when progress is 75%', () => {
      const spyService = TestBed.inject(InitialCheckService);
      spyOn(spyService, 'initCheck');
      component.progress = 75;

      component.checkProgressStatus();

      expect(spyService.initCheck).toHaveBeenCalled();
    });

    it('should not call changeSpinnerState or emit status if hardware is working', () => {
      const spyService = TestBed.inject(InitialCheckService);
      spyOn(spyService, 'initCheck').and.returnValue(true);
      spyOn(component, 'changeSpinnerState');
      spyOn(component.sendHardwareStatus, 'emit');
      component.progress = 75;

      component.checkProgressStatus();

      expect(component.changeSpinnerState).not.toHaveBeenCalledWith(
        false,
        false
      );
      expect(component.sendHardwareStatus.emit).not.toHaveBeenCalledWith(false);
    });

    it('should reset parameters if hardware is not working and unsubscribe from setInterval$', () => {
      const initServiceSpy = TestBed.inject(InitialCheckService);
      spyOn(initServiceSpy, 'initCheck').and.returnValue(false);
      spyOn(component.intervalSubscription, 'unsubscribe');
      component.progress = 75;

      component.checkProgressStatus();

      expect(component.showSpinner).toBe(false);
      expect(component.checkCircle).toBe(false);
      expect(component.crossCircle).toBe(true);
      expect(component.intervalSubscription.unsubscribe).toHaveBeenCalled();
    });
  });

  describe('retryLoader', () => {
    it('should reset values when retryLoader is called and on subscription checkProgressStatus is called', () => {
      spyOn(component, 'checkProgressStatus');
      component.setInterval$ = of(1);
      component.progress = 43;

      component.retryLoader();

      expect(component.progress).toBe(0);
      expect(component.showSpinner).toBe(true);
      expect(component.checkCircle).toBe(false);
      expect(component.crossCircle).toBe(false);
      expect(component.intervalSubscription).toBeTruthy();
      expect(component.checkProgressStatus).toHaveBeenCalled();
    });
  });
});
