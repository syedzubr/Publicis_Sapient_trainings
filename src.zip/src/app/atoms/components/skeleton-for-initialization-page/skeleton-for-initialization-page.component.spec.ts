import { SkeletonForInitializationPageComponent } from './skeleton-for-initialization-page.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';

describe('SkeletonForInitializationPageComponent', () => {
  let component: SkeletonForInitializationPageComponent;
  let fixture: ComponentFixture<SkeletonForInitializationPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SkeletonForInitializationPageComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SkeletonForInitializationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
