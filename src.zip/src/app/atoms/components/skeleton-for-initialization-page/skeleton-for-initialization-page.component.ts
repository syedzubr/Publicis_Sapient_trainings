import { Component } from '@angular/core';

@Component({
  selector: 'app-skeleton-for-initialization-page',
  templateUrl: './skeleton-for-initialization-page.component.html',
  styleUrls: ['./skeleton-for-initialization-page.component.scss'],
})
export class SkeletonForInitializationPageComponent {}
