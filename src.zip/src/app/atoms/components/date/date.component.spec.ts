import { TimerService } from 'app/services/timer/timer.service';
import { DateComponent } from 'app/atoms/components/date/date.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';

describe('DateComponent', () => {
  let component: DateComponent;
  let timeTickerService: TimerService;
  let fixture: ComponentFixture<DateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DateComponent],
    });
    fixture = TestBed.createComponent(DateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    timeTickerService = new TimerService();
  });

  it('should create the date component', () => {
    expect(component).toBeTruthy();
  });

  it('retrieves the date and time', (done: DoneFn) => {
    return timeTickerService.getTimer().subscribe((result: string) => {
      expect(result.length).toBeGreaterThan(0);
      done();
    });
  });
});
