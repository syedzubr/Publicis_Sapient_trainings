export enum ButtonType {
  PRIMARY_BUTTON = 'primary-button',
  SECONDARY_BUTTON = 'secondary-button',
}

export enum arrowType {
  UP = 'up',
  DOWN = 'down',
}
