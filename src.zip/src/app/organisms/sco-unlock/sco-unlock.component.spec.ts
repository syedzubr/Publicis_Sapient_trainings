import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from 'app/modules/shared/shared.module';

import { ScoUnlockComponent } from './sco-unlock.component';

describe('ScoUnlockComponent', () => {
  let component: ScoUnlockComponent;
  let fixture: ComponentFixture<ScoUnlockComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule, TranslateModule.forRoot(), RouterTestingModule],
      declarations: [ScoUnlockComponent],
    });
    fixture = TestBed.createComponent(ScoUnlockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
