import { Component, ViewEncapsulation } from '@angular/core';
import { ButtonType } from 'app/atoms/models/common.model';

@Component({
  selector: 'app-sco-unlock',
  templateUrl: './sco-unlock.component.html',
  styleUrls: ['./sco-unlock.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ScoUnlockComponent {
  btnType = ButtonType;
}
