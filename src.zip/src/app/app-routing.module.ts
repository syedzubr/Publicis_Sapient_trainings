import { PageNotFoundComponent } from 'app/atoms/components/page-not-found/page-not-found.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingGuard } from './pages/landing/landing-guard/landing.guard';
import { LoginGuard } from './pages/sco-login/login-guard/login.guard';
import { PaymentGuard } from './pages/payment/payment-guard/payment.guard';
import { InitializationGuard } from './pages/initialization/initialization-guard/initialization.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'initialization',
    pathMatch: 'full',
  },
  {
    path: 'initialization',
    canDeactivate: [InitializationGuard],
    loadChildren: () =>
      import('./pages/initialization/initialization.module').then(
        (m) => m.InitializationModule
      ),
  },
  {
    path: 'login',
    canDeactivate: [LoginGuard],
    loadChildren: () =>
      import('./pages/sco-login/sco-login.module').then(
        (m) => m.ScoLoginModule
      ),
  },
  {
    path: 'selfCheckout',
    loadChildren: () =>
      import('./pages/self-checkout/self-checkout.module').then(
        (m) => m.SelfCheckoutModule
      ),
  },
  {
    path: 'landing',
    canDeactivate: [LandingGuard],
    loadChildren: () =>
      import('./pages/landing/landing.module').then((m) => m.LandingModule),
  },
  {
    path: 'payment',
    canDeactivate: [PaymentGuard],
    loadChildren: () =>
      import('./pages/payment/payment.module').then((m) => m.PaymentModule),
  },
  {
    path: '**',
    component: PageNotFoundComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
