import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonComponent } from '../../atoms/components/button/button.component';
import { CartContainerComponent } from 'app/molecules/cart-container/cart-container.component';
import { CartRowComponent } from 'app/molecules/cart-container/cart-row/cart-row.component';
import { CartNavigationComponent } from 'app/molecules/cart-container/cart-navigation/cart-navigation.component';
import { ContainerComponent } from 'app/molecules/container/container.component';
import { OnScreenKeypadComponent } from 'app/atoms/components/on-screen-keypad/on-screen-keypad.component';
import { DateComponent } from 'app/atoms/components/date/date.component';
import { HeaderComponent } from 'app/molecules/header/header.component';
import { TranslateModule } from '@ngx-translate/core';
import { PageNotFoundComponent } from 'app/atoms/components/page-not-found/page-not-found.component';
import { ProductDetailComponent } from 'app/molecules/product-detail/product-detail.component';
import { RouterModule } from '@angular/router';
import { PopoverComponent } from 'app/atoms/components/popover/popover.component';
import { MaterialModule } from './material/material.module';
import { PaymentSummaryComponent } from 'app/atoms/components/payment-summary/payment-summary.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    ButtonComponent,
    ContainerComponent,
    OnScreenKeypadComponent,
    DateComponent,
    HeaderComponent,
    CartContainerComponent,
    CartRowComponent,
    CartNavigationComponent,
    PageNotFoundComponent,
    ProductDetailComponent,
    PopoverComponent,
    PaymentSummaryComponent,
  ],
  imports: [
    CommonModule,
    TranslateModule,
    RouterModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  exports: [
    ButtonComponent,
    ContainerComponent,
    OnScreenKeypadComponent,
    DateComponent,
    HeaderComponent,
    CartContainerComponent,
    CartRowComponent,
    CartNavigationComponent,
    TranslateModule,
    ProductDetailComponent,
    CommonModule,
    RouterModule,
    PopoverComponent,
    PaymentSummaryComponent,
    MaterialModule,
  ],
})
export class SharedModule {}
