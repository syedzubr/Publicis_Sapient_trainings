import { InitializationRoutingModule } from './initialization-routing.module';
import { SkeletonForInitializationPageComponent } from 'app/atoms/components/skeleton-for-initialization-page/skeleton-for-initialization-page.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from 'app/atoms/components/loader/loader.component';
import { InitializationComponent } from './initialization.component';
import { SharedModule } from 'app/modules/shared/shared.module';

@NgModule({
  declarations: [
    InitializationComponent,
    SkeletonForInitializationPageComponent,
    LoaderComponent,
  ],
  imports: [
    CommonModule,
    InitializationRoutingModule,
    SharedModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatDialogModule,
  ],
})
export class InitializationModule {}
