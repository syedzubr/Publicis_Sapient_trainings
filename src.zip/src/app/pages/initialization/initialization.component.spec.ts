import { RouterTestingModule } from '@angular/router/testing';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import {
  MatProgressSpinner,
  MatSpinner,
} from '@angular/material/progress-spinner';
import { MockComponent } from 'ng2-mock-component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { InitializationComponent } from './initialization.component';
import { AppService } from 'app/app.service';
import { Router } from '@angular/router';

describe('InitializationComponent', () => {
  let component: InitializationComponent;
  let fixture: ComponentFixture<InitializationComponent>;
  let appService: AppService;
  let router: Router;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        InitializationComponent,
        MatSpinner,
        MatProgressSpinner,
        MockComponent({ selector: 'app-loader' }),
        MockComponent({ selector: 'app-skeleton-for-initialization-page' }),
        MockComponent({
          selector: 'app-button',
          inputs: ['label', 'width', 'type', 'height'],
        }),
      ],
      imports: [HttpClientTestingModule, RouterTestingModule],
    });

    fixture = TestBed.createComponent(InitializationComponent);
    appService = TestBed.inject(AppService);
    router = TestBed.inject(Router);
    component = fixture.componentInstance;
    spyOn(router, 'navigate');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call setStatus method with params "true"', () => {
    spyOn(appService, 'setStatus');
    TestBed.createComponent(InitializationComponent);
    expect(appService.setStatus).toHaveBeenCalledWith(true);
  });

  it('should re-route to sco-login page if hardware token exists', () => {
    spyOnProperty(appService, 'hardwareStatus').and.returnValue(true);
    component.ngOnInit();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });

  it('should re-route to sco-login if loader sends "true" state', fakeAsync(() => {
    component.hardwareCheck(true);
    expect(appService.hardwareStatus).toBeTrue();
    tick(5000);
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  }));

  it('should not re-route to sco-login if loader sends "false" state', () => {
    component.hardwareCheck(false);
    expect(appService.hardwareStatus).toBeFalse();
  });
});
