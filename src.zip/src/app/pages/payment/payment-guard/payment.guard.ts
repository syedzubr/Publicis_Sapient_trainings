import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanDeactivate,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { PaymentGuardService } from 'app/services/payment-guard/payment-guard.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class PaymentGuard implements CanDeactivate<unknown> {
  constructor(private paymentGuardService: PaymentGuardService) {}
  canDeactivate(
    component?: unknown,
    currentRoute?: ActivatedRouteSnapshot,
    currentState?: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (
      nextState?.url === '/selfCheckout' &&
      this.paymentGuardService.paymentSuccess
    ) {
      this.paymentGuardService.paymentSuccess = false;
      return true;
    } else if (nextState?.url === '/landing') {
      return true;
    }
    return false;
  }
}
