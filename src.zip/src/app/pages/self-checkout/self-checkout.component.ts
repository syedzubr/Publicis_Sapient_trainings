import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplyCouponService } from 'app/services/apply-coupon/apply-coupon.service';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { timer } from 'rxjs';

@Component({
  selector: 'app-self-checkout',
  templateUrl: './self-checkout.component.html',
  styleUrls: ['./self-checkout.component.scss'],
})
export class SelfCheckoutComponent implements OnInit {
  constructor(
    private router: Router,
    private cart: CartProductService,
    private coupon: ApplyCouponService
  ) {}

  ngOnInit(): void {
    this.coupon.updateDiscount(0);
    this.cart.products = [];
    timer(3000).subscribe(() => {
      this.router.navigate(['/landing']);
    });
  }
}
