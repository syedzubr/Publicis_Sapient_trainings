import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SelfCheckoutComponent } from './self-checkout.component';

const routes: Routes = [{ path: '', component: SelfCheckoutComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SelfCheckoutRoutingModule {}
