import { HttpClientTestingModule } from '@angular/common/http/testing';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { ApplyCouponService } from 'app/services/apply-coupon/apply-coupon.service';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { SelfCheckoutComponent } from './self-checkout.component';
class MockRouter {
  navigate(): void {}
}
describe('SelfCheckoutComponent', () => {
  let component: SelfCheckoutComponent;
  let fixture: ComponentFixture<SelfCheckoutComponent>;
  let cartProduct: CartProductService;
  let coupon: ApplyCouponService;

  let router: Router;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SelfCheckoutComponent],

      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        TranslateModule.forRoot(),
      ],
      providers: [{ provide: Router, useClass: MockRouter }],
    });

    fixture = TestBed.createComponent(SelfCheckoutComponent);
    component = fixture.componentInstance;
    cartProduct = TestBed.inject(CartProductService);
    coupon = TestBed.inject(ApplyCouponService);
    router = TestBed.inject(Router);
    spyOn(router, 'navigate');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should call update discount', () => {
      spyOn(coupon, 'updateDiscount');
      component.ngOnInit();
      expect(coupon.updateDiscount).toHaveBeenCalledWith(0);
    });

    it('should empty products array of cart product service', () => {
      expect(cartProduct.products).toEqual([]);
    });

    it('should navigate to landing page', fakeAsync(() => {
      component.ngOnInit();
      tick(3000);
      expect(router.navigate).toHaveBeenCalledWith(['/landing']);
    }));
  });
});
