import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { ScoLoginGuardService } from 'app/services/sco-login-guard/sco-login-guard.service';

@Injectable({
  providedIn: 'root',
})
export class LoginGuard implements CanDeactivate<unknown> {
  constructor(private scoLoginGuardService: ScoLoginGuardService) {}
  canDeactivate(): boolean {
    if (this.scoLoginGuardService.goToSelfCheckOut) {
      this.scoLoginGuardService.goToSelfCheckOut = false;
      return true;
    } else {
      return false;
    }
  }
}
