import { TestBed } from '@angular/core/testing';
import { ScoLoginGuardService } from 'app/services/sco-login-guard/sco-login-guard.service';
import { LoginGuard } from './login.guard';

describe('LoginGuardGuard', () => {
  let guard: LoginGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [],
      providers: [
        {
          provide: ScoLoginGuardService,

          useValue: { goToSelfCheckOut: true },
        },
      ],
    });
    guard = TestBed.inject(LoginGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });

  it('should be returning true on true value of service', () => {
    const mockLoginGaurdService = TestBed.inject(ScoLoginGuardService);

    mockLoginGaurdService.goToSelfCheckOut = true;

    expect(guard.canDeactivate()).toEqual(true);
  });

  it('should be returning false on false value of service', () => {
    const mockLoginGaurdService = TestBed.inject(ScoLoginGuardService);

    mockLoginGaurdService.goToSelfCheckOut = false;

    expect(guard.canDeactivate()).toEqual(false);
  });
});
