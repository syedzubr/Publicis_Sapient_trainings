import { ScoUnlockComponent } from 'app/organisms/sco-unlock/sco-unlock.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ScoLoginComponent } from './sco-login.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'unlock',
    pathMatch: 'full',
  },
  {
    path: 'detail',
    component: ScoLoginComponent,
  },
  {
    path: 'unlock',
    component: ScoUnlockComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ScoLoginRoutingModule {}
