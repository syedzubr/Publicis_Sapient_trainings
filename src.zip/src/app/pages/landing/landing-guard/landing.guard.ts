import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { LandingGuardService } from 'app/services/landing-guard/landing-guard.service';
@Injectable({
  providedIn: 'root',
})
export class LandingGuard implements CanDeactivate<unknown> {
  constructor(private landingGuardService: LandingGuardService) {}
  canDeactivate(): boolean {
    if (this.landingGuardService.goToPayment) {
      this.landingGuardService.goToPayment = false;
      return true;
    } else if (this.landingGuardService.goToSelfCheckout) {
      this.landingGuardService.goToSelfCheckout = false;
      return true;
    } else
    { return false;
    }
  }
}
