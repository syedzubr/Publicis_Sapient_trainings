import { TestBed } from '@angular/core/testing';
import { LandingGuardService } from 'app/services/landing-guard/landing-guard.service';
import { LandingGuard } from './landing.guard';

describe('LandingGuard', () => {
  let guard: LandingGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [],
      providers: [
        {
          provide: LandingGuardService,

          useValue: { goToPayment: true },
        },
      ],
    });

    guard = TestBed.inject(LandingGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });

  it('should be returning true on true value of service for payment page', () => {
    const mockLandingGaurdService = TestBed.inject(LandingGuardService);

    mockLandingGaurdService.goToPayment = true;

    expect(guard.canDeactivate()).toEqual(true);
  });

  it('should be returning true on true value of service for selfcheckout page', () => {
    const mockLandingGaurdService = TestBed.inject(LandingGuardService);

    mockLandingGaurdService.goToSelfCheckout = true;
    mockLandingGaurdService.goToPayment = false;

    expect(guard.canDeactivate()).toEqual(true);
  });

  it('should be returning false', () => {
    const mockLandingGaurdService = TestBed.inject(LandingGuardService);

    mockLandingGaurdService.goToPayment = false;
    mockLandingGaurdService.goToSelfCheckout = false;
    expect(guard.canDeactivate()).toEqual(false);
  });
});
