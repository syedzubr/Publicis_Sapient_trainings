import { RouterTestingModule } from '@angular/router/testing';
import { LandingComponent } from './landing.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MockComponent } from 'ng2-mock-component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MaterialModule } from 'app/modules/shared/material/material.module';
import { UnlockRewardsComponent } from 'app/molecules/unlock-rewards/unlock-rewards.component';
import { BarcodeSearchPopupComponent } from 'app/molecules/barcode-search-popup/barcode-search-popup.component';
import { CouponComponent } from 'app/molecules/coupon/coupon.component';
import { VoidTransactionComponent } from 'app/molecules/void-transaction/void-transaction.component';

describe('LandingComponent', () => {
  let component: LandingComponent;
  let fixture: ComponentFixture<LandingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        LandingComponent,
        MockComponent({ selector: 'app-product-detail' }),
        MockComponent({
          selector: 'app-cart-container',
          inputs: ['state', 'height'],
        }),
        MockComponent({
          selector: 'app-landing-feature-section',
          outputs: ['outputEmitter', 'action'],
        }),
      ],
      imports: [
        MaterialModule,
        HttpClientTestingModule,
        TranslateModule.forRoot(),
        RouterTestingModule,
      ],
    });
    fixture = TestBed.createComponent(LandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    spyOn(component.dialog, 'open');
  });

  beforeEach(() => {});

  it('should create Landing component', () => {
    expect(component).toBeTruthy();
  });

  describe('Mobile Rewards', () => {
    it('should check if handleClick opens Mobile rewards dialog on "UNLOCK REWARDS" event', () => {
      component.handleClick('UNLOCK REWARDS');

      expect(component.dialog.open).toHaveBeenCalledWith(
        UnlockRewardsComponent
      );
    });

    it('should check if handleClick opens Mobile rewards dialog on "BARCODE SEARCH" event', () => {
      component.handleClick('BARCODE SEARCH');

      expect(component.dialog.open).toHaveBeenCalledWith(
        BarcodeSearchPopupComponent
      );
    });

    it('should check if handleClick opens Mobile rewards dialog on "APPLY COUPON" event', () => {
      component.handleClick('APPLY COUPON');

      expect(component.dialog.open).toHaveBeenCalledWith(
        CouponComponent
      );
    });

    it('should check if handleClick opens Mobile rewards dialog on "VOID TRANSACTION" event', () => {
      component.handleClick('VOID TRANSACTION');

      expect(component.dialog.open).toHaveBeenCalledWith(
        VoidTransactionComponent
      );
    });

    it('should not do anything if clickedBtn is empty', () => {
      component.handleClick('');

      expect(component.dialog.open).not.toHaveBeenCalled(
      );
    });
  });
});
