import { NgModule } from '@angular/core';
import { LandingRoutingModule } from './landing-routing.module';
import { LandingComponent } from './landing.component';
import { LandingFeatureSectionComponent } from 'app/molecules/landing-feature-section/landing-feature-section.component';
import { BarcodeSearchPopupComponent } from 'app/molecules/barcode-search-popup/barcode-search-popup.component';
import { SharedModule } from 'app/modules/shared/shared.module';
import { CouponComponent } from 'app/molecules/coupon/coupon.component';
import { VoidTransactionComponent } from 'app/molecules/void-transaction/void-transaction.component';
import { UnlockRewardsComponent } from 'app/molecules/unlock-rewards/unlock-rewards.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    LandingComponent,
    LandingFeatureSectionComponent,
    CouponComponent,
    UnlockRewardsComponent,
    BarcodeSearchPopupComponent,
    VoidTransactionComponent,
  ],
  imports: [LandingRoutingModule, SharedModule, FormsModule],
  entryComponents: [
    CouponComponent,
    UnlockRewardsComponent,
    BarcodeSearchPopupComponent,
    VoidTransactionComponent,
  ],
})
export class LandingModule {}
