import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[phoneformat]'
})
export class PhoneFormatDirective {

  @Input("phoneformat") countryCode: any;
  
  @HostListener('blur')
  onComplete(){
    console.log("completed entering the phone number")
    console.log(this.elementRef.nativeElement.value)
     let val = this.elementRef.nativeElement.value;
     if (this.countryCode === 'IN'){
        this.elementRef.nativeElement.value = '+91 - '+val;
     }else if (this.countryCode === 'US'){
        this.elementRef.nativeElement.value = '+1 - '+val;
     }
  }

  @HostListener('focus')
  onFocus(){
    this.elementRef.nativeElement.value='Enter the phone number'
  }

  constructor(private elementRef: ElementRef) {
      console.log('Element ref inside the custom directive')
      
  }

}
