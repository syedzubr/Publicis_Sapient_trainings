import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'usersSort'
})
export class UsersSortPipe implements PipeTransform {

  transform(users: any[], ...args: string[]): any[] {

    if (args[0] === 'age'){
      if (args[1] === 'asc') {
        return users.sort((u1, u2) => u1.age - u2.age);
      } else {
        return users.sort((u1, u2) => u2.age - u1.age);
      }
    } else {
      if (args[1] === 'asc') {
        return users.sort((u1, u2) => u1.name.localeCompare(u2.name));
      } else {
        return users.sort((u1, u2) => u2.name.localeCompare(u1.name));
      }

    }
  }
}
