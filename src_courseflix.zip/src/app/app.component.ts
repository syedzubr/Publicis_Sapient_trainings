import { Component, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { Course } from './Course';
import { CourseService } from './course.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy , OnChanges{


  //dependency injection
  courses: Course[] = []
  constructor(private courseService:CourseService){}

  ngOnInit(): void {
    this.courseService.fetchAllCourses();
  }

  ngOnChanges(){
    console.log('There is an update ')
  }

  ngOnDestroy(){
    console.log('The will be called once this component is destroyed')
  }

  
}
