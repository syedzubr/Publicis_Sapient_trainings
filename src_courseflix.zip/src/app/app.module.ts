import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { CourseComponent } from './course/course.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CoursesContainerComponent } from './courses-container/courses-container.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { RatingComponent } from './rating/rating.component';
import { TemplateFormComponent } from './template-form/template-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { PhoneFormatDirective } from './phone-format.directive';
import { UsersSortPipe } from './users-sort.pipe';
import { UsersComponent } from './users/users.component';
import { CaseConvertPipe } from './case-convert.pipe';
import { FormsComponent } from './forms/forms.component';
import { RouterModule } from '@angular/router';
import { CourseDetailsComponent } from './course-details/course-details.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { routes } from './routes';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { AsyncPipeComponent } from './async-pipe/async-pipe.component';
import { TimeTickerComponent } from './time-ticker/time-ticker.component';
import { BuyComponent } from './buy/buy.component';
import { SellComponent } from './sell/sell.component';
import { CompCommunicationComponent } from './comp-communication/comp-communication.component';
import { InventoryCountComponent } from './inventory-count/inventory-count.component';
import { HttpErrorInterceptor } from './HttpErrorInterceptor';
import { AuthInterceptor } from './AuthInterceptor';
import { LoginComponent } from './login/login.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ProductsModule } from './products/products.module';
import { FrameComponent } from './frame/frame.component';
import { UserComponent } from './user/user.component';
import { MovieComponent } from './movie/movie.component';
import { ObservableDemoComponent } from './observable-demo/observable-demo.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    HeaderComponent,
    FooterComponent,
    CoursesContainerComponent,
    SidebarComponent,
    RatingComponent,
    TemplateFormComponent,
    ReactiveFormComponent,
    ParentComponent,
    ChildComponent,
    PhoneFormatDirective,
    UsersSortPipe,
    UsersComponent,
    CaseConvertPipe,
    FormsComponent,
    CourseDetailsComponent,
    ViewChildComponent,
    AsyncPipeComponent,
    TimeTickerComponent,
    BuyComponent,
    SellComponent,
    CompCommunicationComponent,
    InventoryCountComponent,
    LoginComponent,
    NotFoundComponent,
    FrameComponent,
    UserComponent,
    MovieComponent,
    ObservableDemoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    ProductsModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
