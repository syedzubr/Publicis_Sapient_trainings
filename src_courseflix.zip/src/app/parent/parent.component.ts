import { Component, DoCheck, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit, DoCheck {

   data:string = "Intial Data";

  constructor() { console.log("Inside the constructor of Parent")}

  countryCode: any
  
  ngOnInit(): void {
    console.log("Inside the init of Parent")
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("Inside the onchanges method of the Parent")    
  }

  ngAfterContentChecked(): void {
    //Called after every check of the component's or directive's content.
    //Add 'implements AfterContentChecked' to the class.
    console.log("Inside the ng after content checked inside the parent component");
  }

  ngAfterViewChecked(): void {
    //Called after every check of the component's view. Applies to components only.
    //Add 'implements AfterViewChecked' to the class.
    console.log("Inside the ng after view checked inside the parent component");
  }

  ngDoCheck(){
    console.log('Do check called when Angular detects changes')
  }

  testing(){
    console.log("Inside the test method")
  }

}
