const { Subject } = require("rxjs");

const subject = new Subject();

//create three observers 

const user1 = subject.subscribe( (data) => console.log(`Observer A : ${data}`), 
                                  ()=> console.log('There is an error'),
                                  () => console.log("A => No more data"))
const user2 = subject.subscribe( (data) => console.log(`Observer B : ${data}`), 
                                  ()=> console.log('There is an error'),
                                  () => console.log("B => No more data"))
const user3 = subject.subscribe( (data) => console.log(`Observer C : ${data}`), 
                                  ()=> console.log('There is an error'),
                                  () => console.log("C => No more data"))


subject.next(1);
subject.next(2);

//user3.unsubscribe();
//user2.unsubscribe();
subject.next(3);
subject.next(4);

subject.complete();
subject.next(5);

