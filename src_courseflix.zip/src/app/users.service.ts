import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  users=[
    {
      "name":'Kishore',
      "age": 22
    },
    {
      "name":'Harish',
      "age": 23
    },
    {
      "name":'Vinay',
      "age": 32
    },
    {
      "name":'Akash',
      "age": 42
    },
    {
      "name":'Ramya',
      "age": 28
    }
  ]

  fetchAllUsers():any[]{
    return this.users
  }
}
