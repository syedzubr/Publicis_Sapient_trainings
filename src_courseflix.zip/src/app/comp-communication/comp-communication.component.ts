import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-communication',
  templateUrl: './comp-communication.component.html',
  styleUrls: ['./comp-communication.component.css']
})
export class CompCommunicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
