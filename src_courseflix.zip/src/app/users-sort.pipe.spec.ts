import { UsersSortPipe } from './users-sort.pipe';

describe('UsersSortPipe', () => {
  it('create an instance', () => {
    const pipe = new UsersSortPipe();
    expect(pipe).toBeTruthy();
  });
});
