const { ReplaySubject } = require("rxjs");

const subject = new ReplaySubject(3);

//create three observers 

const user1 = subject.subscribe( (data) => console.log(`Observer A : ${data}`), 
                                  ()=> console.log('There is an error'),
                                  () => console.log("A => No more data"))
const user2 = subject.subscribe( (data) => console.log(`Observer B : ${data}`), 
                                  ()=> console.log('There is an error'),
                                  () => console.log("B => No more data"))
                                  
                                  
subject.next(1);
subject.next(2);
subject.next(3);
subject.next(4);

const user3 = subject.subscribe( (data) => console.log(`Observer C : ${data}`), 
                                ()=> console.log('There is an error'),
                                () => console.log("C => No more data"))


