export interface CourseDesc {
    id: number;
    desc: string
}