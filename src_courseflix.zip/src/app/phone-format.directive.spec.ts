import { PhoneFormatDirective } from './phone-format.directive';

describe('PhoneFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new PhoneFormatDirective();
    expect(directive).toBeTruthy();
  });
});
