const { BehaviorSubject } = require("rxjs");

const subject = new BehaviorSubject("Initial data");

//create three observers 

const user1 = subject.subscribe( (data) => console.log(`Observer A : ${data}`), 
                                  ()=> console.log('There is an error'),
                                  () => console.log("A => No more data"))
const user2 = subject.subscribe( (data) => console.log(`Observer B : ${data}`), 
                                  ()=> console.log('There is an error'),
                                  () => console.log("B => No more data"))
                                  
                                  
subject.next(1);
subject.next(2);

const user3 = subject.subscribe( (data) => console.log(`Observer C : ${data}`), 
                                ()=> console.log('There is an error'),
                                () => console.log("C => No more data"))

subject.next(3);
