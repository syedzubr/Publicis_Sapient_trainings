import { Component, OnInit } from '@angular/core';
import { forkJoin, interval, Observable, of, timer } from 'rxjs';
import { concatMap, delay, map, mergeMap, skipUntil, skipWhile, take, takeLast, tap } from 'rxjs/operators';
import { CourseService } from '../course.service';
import { ObservableService } from '../observable.service';

@Component({
  selector: 'app-observable-demo',
  templateUrl: './observable-demo.component.html',
  styleUrls: ['./observable-demo.component.css']
})
export class ObservableDemoComponent implements OnInit {

  message:any | undefined;
  
  constructor(private observable: ObservableService, private courseService: CourseService) { }
  ngOnInit(): void {
    //this.observable.dataStr().subscribe(data => console.log(data));
    //this.observable.message().subscribe(message => console.log(message));;
   /* this.observable.dataStr()
        .pipe(//mergeMap(data => of(`Total value after exchange rate is  ${data * 2.4}`))
          mergeMap(data => interval(1000).pipe(map(i => `The exchange value as of now is :: ${i}`)))
        ).subscribe(message => this.message = message);
  */
 //setting the upper bound
 /*
  interval(1000)
    .pipe(take(8))
    .subscribe(data => console.log(data))
  }
  */
/*
    this.observable
        .dataStr()
        .pipe(mergeMap(data => interval(2000).pipe(take(8), map(i => `${data}`)))
    ).subscribe(message => console.log(message));
*/
//fork join
/*
    const result = forkJoin(
      of('Ordered Pizza').pipe(delay(200)),
      of('fetched Coke').pipe(delay(5000)),
      interval(1000).pipe(take(2))
      )

    result.subscribe(message => console.log(message))

    */

    //skilUntil
   /* interval(1000).pipe(
      take(8),
      skipUntil(timer(3000))
    )
    .subscribe(data => console.log(data));
    */
/*
   interval(1000).pipe(
    take(9),
    skipWhile(num => num <= 3)
  )
  .subscribe(data => console.log(data));
  } 
  */
  
  /*interval(1000).pipe(
    take(9),
    takeLast(2)
  )
  .subscribe(data => console.log(data));
  }
  */


  //concatMap - sequential 
  this.courseService.fetchAllCourses()
            .pipe(
              delay(10000),
              concatMap(res => this.courseService.fetchCourseById(res[0].id))
            ) 
            .subscribe(res => console.log(res));
  }
}
