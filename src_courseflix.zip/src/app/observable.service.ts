import { Injectable } from '@angular/core';
import { Observable, of} from 'rxjs';
import { delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ObservableService {

  dataStr():Observable<number>{
    return of(200, 300, 500, 150)
              
  }

  message ():Observable<string>{
    return of('lets start the dinner ');
  }
}
