import { CaseConvertPipe } from './case-convert.pipe';

describe('CaseConvertPipe', () => {
  it('create an instance', () => {
    const pipe = new CaseConvertPipe();
    expect(pipe).toBeTruthy();
  });
});
