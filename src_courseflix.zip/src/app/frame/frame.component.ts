import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-frame',
  template: `
  <div class="card">
    <div class="card-header bg-success">
      <ng-content select="#header"></ng-content>
    </div>
    <div class="card-body">
      <h5 class="card-title">Special title treatment</h5>
      <ng-content select="#body"></ng-content>
    </div>
    <div class="card-footer bg-warning">
      <ng-content select="#footer"></ng-content>
    </div>
  </div>
  `,
  styleUrls: ['./frame.component.css']
})
export class FrameComponent {

  @Input('data')value: string | undefined
}
