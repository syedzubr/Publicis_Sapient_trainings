import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../Course';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent {
  constructor(private courseService: CourseService, private myrouter: Router){}
  submitCourse(c:Course){
    /*
    {
      id:5,
      name : "Spring-Boot",
      coursePrice : 22000,
      numberOfStudents : 20,
      duration : 3,
      startDate: '03-15-2021',
      rating: 3.4242
    }
    */
    let course:Course = {id:0, name:'', price:0, start_date:'', students:0,duration:0, rating:0, imgPath:''};
    course.id= Math.floor(Math.random() * 1000);
    course.name = c.name;
    course.price = c.price;
    course.start_date = c.start_date;
    course.students = 0;
    course.duration = 3;
    course.rating = 5;
    course.imgPath=c.imgPath;
    this.
        courseService
        .addCourse(course)
        .subscribe(course => console.log("course is added "+ course));
    this.myrouter.navigate(["/list"]);
  }
}
