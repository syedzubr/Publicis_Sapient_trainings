import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements AfterViewInit{

  @ViewChild("dataText") elemRef: any ;

  ngOnInit(): void {
    console.log(`The value of data text is ${this.elemRef}`)
  }

  ngAfterViewInit(){
    console.log(`Inside the ngAfterViewInit value is `)
    console.log(this.elemRef.nativeElement.innerText)
    this.elemRef.nativeElement.innerText = "THe content is redefined !!"
  }
}
