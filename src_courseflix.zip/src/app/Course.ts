export interface Course {
    id:number,
    name : string,
    price : number,
    students : number,
    duration : number,
    start_date: string,
    imgPath: string
    rating: number
}
