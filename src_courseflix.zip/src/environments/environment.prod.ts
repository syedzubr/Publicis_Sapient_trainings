export const environment = {
  production: true,
  API_URL: 'https://my-json-server.typicode.com/prashdeep/courseflix/courses/',
  DB_USERNAME: 'prod',
  DB_PASSWORD: 'sdfsdfsdf#$@#'
};
