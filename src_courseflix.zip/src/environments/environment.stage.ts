export const environment = {
  production: false,
  API_URL: 'https://my-json-server.typicode.com/prashdeep/courseflix/courses/',
  DB_USERNAME: 'stage',
  DB_PASSWORD: 'sdfsdfsdf#$@#'
};
