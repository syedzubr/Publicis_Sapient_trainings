import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HotelContainerComponent } from './hotel-container/hotel-container.component';
import { HotelComponent } from './hotel/hotel.component';
import { HotelDetailsComponent } from './hotel-details/hotel-details.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HotelContainerComponent,
    HotelComponent,
    HotelDetailsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
      {
        path:'home',
        component: HotelContainerComponent
      },
      {
        path:'hotel/:myname',
        component: HotelDetailsComponent
      }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
