import { Component, OnInit } from '@angular/core';
import { HotelsService } from '../hotels.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-hotel-details',
  templateUrl: './hotel-details.component.html',
  styleUrls: ['./hotel-details.component.css']
})
export class HotelDetailsComponent implements OnInit {

  hotels: any[] = [];
  hotel = {
      id:1,
      name : "Ibis",
      DayPrice : 5000,
      location : "Hebbal",
      tags : ["free-wifi", "Play-Area"]
  }
  constructor(private activatedRoute: ActivatedRoute,private hotelSer: HotelsService) { }

  ngOnInit(): void {
     this.hotels = this.hotelSer.fetchHotels();

     let hotelName = this.activatedRoute.snapshot.params["myname"];
     console.log(hotelName);
     this.hotel = this.hotelSer.fetchHotelByName(hotelName);
     console.log(this.hotel);
  }
}
