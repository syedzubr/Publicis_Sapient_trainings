import { Component, OnInit } from '@angular/core';
import { HotelsService } from '../hotels.service';

@Component({
  selector: 'app-hotel-container',
  templateUrl: './hotel-container.component.html',
  styleUrls: ['./hotel-container.component.css']
})
export class HotelContainerComponent implements OnInit {

  hotels: any[] = [];
  constructor(private hotelSer: HotelsService) { }

  ngOnInit(): void {
     this.hotels = this.hotelSer.fetchHotels();
  }

}
