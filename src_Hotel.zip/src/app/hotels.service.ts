import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HotelsService {

  hotels = [
    {
      id:1,
      name : "Ibis",
      DayPrice : 5000,
      location : "Hebbal",
      tags : ["free-wifi", "Play-Area"]
    },
    {
      id:2,
      name : "Sheraton",
      DayPrice : 4000,
      location : "whitefield",
      tags : ["free-wifi", "Gym"]
    },
    {
      id:3,
      name : "MarcoPolo",
      DayPrice : 6000,
      location : "Dubai",
      tags : ["free-wifi", "Gym", "Services"]
    }
  ]

  fetchHotels(){
    return this.hotels;
  }

  fetchHotelByName(Name){
    for(let item of this.hotels){
        if(item.name === Name)
          return item;
    }
}
}
