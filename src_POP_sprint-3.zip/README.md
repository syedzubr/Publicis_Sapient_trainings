# POPStore

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.2.4.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.

# GIT codes

```
git stash ---------- save you local changes
git pull ----------- pull the master branch changes
git stash apply -------- merge local changes with master branch changes
git add .
git commit -m "message“ -------- commit local changes to stage
git commit -m "message" --no-verify -------- forcefully commit local changes to stage
git push -u origin master -------- push local changes to master branch
git checkout –b <branch_name> -------- create new branch and move to that new branch
git checkout <branch_name> -------- move to that branch
git merge master -------- merge your changes of master branch to current branch
```

# Folder structure

## A typical top-level directory layout

    Src
    ├── atoms
    ├        ├── components
    ├        ├── directives
    ├        ├── pipes
    ├── molecules
    ├── organisms
    ├── pages
    ├── services
    ├── interface
    └── README.md

# PUSH application

Before push any code you have to pass in lint and test cases

```
1. ng lint
2. ng test
```

# Setting up CI/CD pipeline

source:https://docs.gitlab.com/ee/ci/quick_start/

Make the following changes in the mentioned file while setting up the project environment.

```
1)package.json

"scripts": {
    "ng": "ng",
    "start": "ng serve",
    "build": "ng build",
    "test": "ng test --progress false --watch false",
    "test:ci": "ng test --code-coverage --browsers=Headless --no-watch",
    "lint": "ng lint",
    "e2e": "ng e2e"
  },



```

```
2)karma.config.js

browsers: ['Chrome'],
    customLaunchers: {
      Headless: {
        base: 'ChromeHeadless',
        flags: [
          '--no-sandbox',
          '--disable-setuid-sandbox'
        ]
      }
    }

```
# Git Hooks
```
"husky": "^4.2.5"
"husky": {
  "hooks": {
    "pre-commit": "npm run lint"
  }
}
```

# SCSS

In our project you can use [SASS](http://sass-lang.com/). Sass is the most mature, stable, and powerful professional grade CSS extension language in the world.

Sass is a CSS preprocessor — a layer between the stylesheets you author and the .css files you serve to the browser. Sass (short for Syntactically Awesome Stylesheets) plugs the holes in CSS as a language, allowing you to write DRY code that’ll be faster, more efficient, and easier to maintain. In our WSK we follow Sass [guidelines](https://sass-guidelin.es/#architecture).

So while normal CSS doesn’t yet allow things like variables, mixins (reusable blocks of styles), and other goodies, Sass provides a syntax that does all of that and more—enabling “super functionality” in addition to your normal CSS.

- All custom **scss** files locate in `src/scss/` folder;
- Entry point for all scss is `src/scss/style.scss` you can **import** all your _.scss_ files from here;
- You **don't need** to write **prefixes** for different browsers like `-webkit` it will be done by the gulp.

- All **extensions** must be installed by the [NPM](https://docs.npmjs.com/cli/install);
- After installing the extension you must **include its files**:
  - **css or sass files** must be included in `src/vendor_entries/vendor.scss` using `@import`.

## How do I add Sass compilation in Angular CLI 6: angular.json

```
"schematics": {
        "@schematics/angular:component": {
          "styleext": "scss"
        }
},
```

## Changing the CSS Files to Sass

```
"styles": [
              "src/styles.scss"
          ],
```

## Writing media queries

```
Example: use case of the mixin  to write media queries

@include desktop {
  .foo{
          display:flex;
          ....and other styles
      }
 }
```

## Official components for Angular
[![npm version](https://badge.fury.io/js/%40angular%2Fcdk.svg)](https://www.npmjs.com/package/@angular/cdk)
[![Build status](https://circleci.com/gh/angular/components.svg?style=svg)](https://circleci.com/gh/angular/components)
[![Gitter](https://badges.gitter.im/angular/components.svg)](https://gitter.im/angular/material2?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)

The Angular team builds and maintains both common UI components and tools to help you build your
own custom components. The team maintains several npm packages.

| Package                   | Description                                                                         | Docs             |
| ------------------------- | ----------------------------------------------------------------------------------- | ---------------- |
| `@angular/cdk`            | Library that helps you author custom UI components with common interaction patterns | [Docs][cdk-docs] |
| `@angular/material`       | [Material Design][] UI components for Angular applications                          | [Docs][mat-docs] |


#### Quick links
[Documentation, demos, and guides][mat-docs] |
[Frequently Asked Questions](FAQ.md) |
[Community Google group](https://groups.google.com/forum/#!forum/angular-material2) |
[Contributing](https://github.com/angular/components/blob/master/CONTRIBUTING.md) |
[StackBlitz Template](https://stackblitz.com/fork/components-issue)



## Code coverage

- As and when we write the test for our application we must need to know and understand how much code has been covered under test cases 
- `Code coverage` represents how much `percent of code is covered with unit tests`
- With the Angular CLI, we can run unit tests as well as create code coverage reports - Code coverage reports allow us to see any parts of our code base that may not be properly tested by our unit tests
- `karma.conf.js` consists of a key `coverageIstanbulReporter` for code coverage related settings:

> **If your team decides on a set minimum amount to be unit tested you can enforce this minimum with the Angular CLI:**

- The `thresholds` property will enforce a minimum of `80%` code coverage when the unit tests are run in the project


```typescript

coverageIstanbulReporter: {
 dir: require('path').join(__dirname, '../coverage'),
 reports: ['html', 'lcovonly'],
 fixWebpackSourcePaths: true
},

coverageIstanbulReporter: {
 reports: [ 'html', 'lcovonly' ],
 fixWebpackSourcePaths: true,
 thresholds: {
 statements: 80,
 lines: 80,
 branches: 80,
 functions: 80
 }
}

```

- If you want to `create code-coverage reports every time you test`, you can set the following option in the CLI configuration file, `angular.json`: This will produce code coverage results whenever tests are run for the project

```typescript
"test": {
 "options": {
 "codeCoverage": true
 }
}

```

To find out exact code coverage percentage / To generate a coverage report run the following command in the root of your project:
- `ng test --codeCoverage` OR
- ng test --code-coverage

Generate the code-coverage report at the same time close Karma test window (don't watch unit test cases):
- ng test --no-watch --code-coverage
- ng test --watch=false --code-coverage

> **Output:**
- Angular CLI generates the coverage report in a separate folder called `coverage` at the root
- Every folder in the `coverage/src/app` has his index.html, we can load that in the browser to see the actual report for that particular folder or module
- `coverage/index.html`: To check the final report on code coverage of every individual component or page/files or folders
- `coverage/src/index.html`: Shows report of `polyfills.ts` and `test.ts`


If you load the `coverage/index.html` from this folder in the browser, we can see the full report:


> **Note**: 
- To verify code coverage report percentage, one can `comment-uncomment` some code from `.spec` files and view the report
- In code coverage report, `lines marked in GREEN are covered in test` and lines `highlighted in RED are not covered` in the test (no test written for such lines)
