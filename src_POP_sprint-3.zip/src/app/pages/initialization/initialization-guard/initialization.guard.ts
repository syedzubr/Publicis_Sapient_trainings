import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { AppService } from 'app/app.service';
import { Observable } from 'rxjs';
import { InitializationModule } from '../initialization.module';

@Injectable({
  providedIn: 'root',
})
export class InitializationGuard
  implements CanDeactivate<InitializationModule> {
  constructor(private appService: AppService) {}
  canDeactivate(): Observable<boolean> | Promise<boolean> | boolean {
    const isHardwareChecked = this.appService.hardwareStatus;
    if (isHardwareChecked) {
      this.appService.setStatus(false);
      return true;
    }
    return false;
  }
}
