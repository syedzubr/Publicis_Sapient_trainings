import { TestBed } from '@angular/core/testing';
import { AppService } from 'app/app.service';
import { InitializationGuard } from './initialization.guard';

describe('InitializationGuard', () => {
  let guard: InitializationGuard;
  let appService: AppService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InitializationGuard, AppService],
    });
    guard = TestBed.inject(InitializationGuard);
    appService = TestBed.inject(AppService);
  });

  it('should create guard', () => {
    expect(guard).toBeTruthy();
  });

  it('should setStatus as false and return true if hardwareStatus is true', () => {
    spyOnProperty(appService, 'hardwareStatus').and.returnValue(true);
    spyOn(appService, 'setStatus');

    const retValue = guard.canDeactivate();

    expect(appService.setStatus).toHaveBeenCalledOnceWith(false);
    expect(retValue).toBeTrue();
  });

  it('should return false if hardwareStatus is false', () => {
    spyOnProperty(appService, 'hardwareStatus').and.returnValue(false);
    spyOn(appService, 'setStatus');

    const retValue = guard.canDeactivate();

    expect(retValue).toBeFalse();
  });
});
