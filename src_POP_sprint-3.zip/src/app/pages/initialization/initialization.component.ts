import { AppService } from 'app/app.service';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { timer } from 'rxjs';

export const hardwareCheckToken = 'isHardwareChecked';
@Component({
  selector: 'app-initialization',
  templateUrl: './initialization.component.html',
  styleUrls: ['./initialization.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class InitializationComponent implements OnInit {
  constructor(private router: Router, private appService: AppService) {
    this.appService.setStatus(true);
  }

  ngOnInit(): void {
    const tokenStatus = this.appService.hardwareStatus;
    if (tokenStatus) {
      this.router.navigate(['/login']);
    }
  }

  hardwareCheck(status: boolean): void {
    this.appService.hardwareStatus = status;
    if (this.appService.hardwareStatus) {
      timer(5000).subscribe((_) => {
        this.router.navigate(['/login']);
      });
    }
  }
}
