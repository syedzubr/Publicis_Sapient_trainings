import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AppService } from 'app/app.service';
import { BarcodeSearchPopupComponent } from 'app/molecules/barcode-search-popup/barcode-search-popup.component';
import { CouponComponent } from 'app/molecules/coupon/coupon.component';
import { UnlockRewardsComponent } from 'app/molecules/unlock-rewards/unlock-rewards.component';
import { VoidTransactionComponent } from 'app/molecules/void-transaction/void-transaction.component';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
})
export class LandingComponent {
  constructor(public dialog: MatDialog, private appService: AppService) {}

  handleClick(clickedBtn: string): void {
    if (clickedBtn !== '') {
      if (clickedBtn === 'BARCODE SEARCH') {
        this.dialog.open(BarcodeSearchPopupComponent);
      }
      if (clickedBtn === 'UNLOCK REWARDS') {
        this.dialog.open(UnlockRewardsComponent);
      }
      if (clickedBtn === 'APPLY COUPON') {
        this.dialog.open(CouponComponent);
      }
      if (clickedBtn === 'VOID TRANSACTION') {
        this.dialog.open(VoidTransactionComponent);
      }
    }
  }
}
