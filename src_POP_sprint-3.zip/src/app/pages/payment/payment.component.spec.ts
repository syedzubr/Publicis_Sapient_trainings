import { PaymentComponent } from './payment.component';

import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
  flush,
} from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { MockComponent } from 'ng2-mock-component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PaymentSuccessfulComponent } from 'app/molecules/payment-successful/payment-successful.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { CountdownModule } from 'ngx-countdown';

describe('PaymentComponent', () => {
  let component: PaymentComponent;
  let fixture: ComponentFixture<PaymentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        PaymentComponent,
        PaymentSuccessfulComponent,
        MockComponent({
          selector: 'app-cart-container',
          inputs: ['state', 'height'],
        }),
        MockComponent({
          selector: 'app-container',
        }),
        MockComponent({
          selector: 'app-popover',
        }),
        MockComponent({
          selector: 'app-payment-summary',
        }),
        MockComponent({
          selector: 'app-payment-successful',
        }),
      ],
      imports: [
        TranslateModule.forRoot(),
        MatButtonModule,
        MatDialogModule,
        RouterTestingModule,
        HttpClientTestingModule,
        HttpClientModule,
        BrowserAnimationsModule,
        CountdownModule,
      ],
    }).overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [PaymentSuccessfulComponent],
      },
    });
    fixture = TestBed.createComponent(PaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Router: App', () => {
    let router: Router;

    it('navigate to "" redirects you to /selfCheckout', fakeAsync(() => {
      router = TestBed.inject(Router);
      const spy = spyOn(router, 'navigate');
      spyOnProperty(router, 'url', 'get').and.returnValue('/payment');
      component.openPopUp();
      tick(11000);
      expect(spy).toHaveBeenCalledWith(['/selfCheckout']);
      flush();
    }));
  });

  it('should render paymentsucessful component', () => {
    spyOn(component, 'openPopUp');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="credit"]'
    );
    button.click();
    expect(component.openPopUp).toHaveBeenCalled();
  });
  it('should render paymentsucessful component', () => {
    spyOn(component, 'openPopUp');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="cash"]'
    );
    button.click();
    expect(component.openPopUp).toHaveBeenCalled();
  });
  it('should render paymentsucessful component', () => {
    spyOn(component, 'openPopUp');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="debit"]'
    );
    button.click();
    expect(component.openPopUp).toHaveBeenCalled();
  });
  it('should render paymentsucessful component', () => {
    spyOn(component, 'openPopUp');
    const button = fixture.debugElement.nativeElement.querySelector(
      'button[value="wallet"]'
    );
    button.click();
    expect(component.openPopUp).toHaveBeenCalled();
  });
});
