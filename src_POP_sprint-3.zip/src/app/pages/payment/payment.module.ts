import { PaymentComponent } from './payment.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { PaymentSuccessfulComponent } from 'app/molecules/payment-successful/payment-successful.component';
import { PaymentRoutingModule } from './payment-routing.module';
import { SharedModule } from 'app/modules/shared/shared.module';
import { CountdownModule } from 'ngx-countdown';


@NgModule({
  declarations: [PaymentComponent, PaymentSuccessfulComponent],
  imports: [
    CommonModule,
    PaymentRoutingModule,
    TranslateModule,
    SharedModule,
    MatDialogModule,
    MatButtonModule,
    CountdownModule,
   ],
  entryComponents: [PaymentSuccessfulComponent],
})
export class PaymentModule {}
