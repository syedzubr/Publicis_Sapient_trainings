import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PaymentSuccessfulComponent } from 'app/molecules/payment-successful/payment-successful.component';
import { PaymentGuardService } from 'app/services/payment-guard/payment-guard.service';
import { timer } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
})
export class PaymentComponent {
  constructor(
    private dialog: MatDialog,
    private router: Router,
    private paymentGuardService: PaymentGuardService
  ) {}

  openPopUp(): any {
    this.paymentGuardService.paymentSuccess = true;
    this.dialog.open(PaymentSuccessfulComponent, {
    panelClass: 'payment-popup'
  });
    this.navigate();
  }
  navigate(): any {
    timer(10000).subscribe(() => {
      this.router.navigate(['/selfCheckout']);
      this.dialog.closeAll();
    });
  }
}
