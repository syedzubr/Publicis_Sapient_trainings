import { TestBed } from '@angular/core/testing';
import { RouterStateSnapshot } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { PaymentGuardService } from 'app/services/payment-guard/payment-guard.service';
import { PaymentGuard } from './payment.guard';

describe('PaymentGuard', () => {
  let guard: PaymentGuard;
  let paymentGuardService: PaymentGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        {
          provide: PaymentGuardService,
          useValue: { paymentSuccess: true },
        },
      ],
    });
    guard = TestBed.inject(PaymentGuard);
    paymentGuardService = TestBed.inject(PaymentGuardService);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });

  it('should return false when RouteStateSnapshot is "undefined"', () => {
    paymentGuardService.paymentSuccess = false;
    expect(
      guard.canDeactivate(undefined, undefined, undefined, undefined)
    ).toBeFalsy();
  });

  it('should return true when trying to route to "selfCheckout" Page when payment has been made', () => {
    paymentGuardService.paymentSuccess = true;
    expect(
      guard.canDeactivate(
        undefined,
        undefined,
        undefined,
        fakeRouterState('/selfCheckout')
      )
    ).toEqual(true);
  });

  it('should return true when trying to route to "landing" page', () => {
    paymentGuardService.paymentSuccess = false;
    expect(
      guard.canDeactivate(
        undefined,
        undefined,
        undefined,
        fakeRouterState('/landing')
      )
    ).toEqual(true);
  });

  it('should return false when trying to route to "selfCheckout" Page when payment has not been made', () => {
    paymentGuardService.paymentSuccess = false;
    expect(
      guard.canDeactivate(
        undefined,
        undefined,
        undefined,
        fakeRouterState('/selfCheckout')
      )
    ).toBeFalsy();
  });

  it('should return false when trying to route to other pages', () => {
    paymentGuardService.paymentSuccess = false;
    const routerNotAllowed = [
      '/intialization',
      '/login/unlock',
      '/login/detail',
      '**',
    ];

    routerNotAllowed.forEach((url) => {
      expect(
        guard.canDeactivate(
          undefined,
          undefined,
          undefined,
          fakeRouterState(url)
        )
      ).toBeFalsy();
    });
  });
});

const fakeRouterState = (url: string): RouterStateSnapshot => {
  return {
    url,
  } as RouterStateSnapshot;
};
