import { NgModule } from '@angular/core';
import { SelfCheckoutRoutingModule } from './self-checkout-routing.module';
import { SelfCheckoutComponent } from './self-checkout.component';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from 'app/modules/shared/shared.module';

@NgModule({
  declarations: [SelfCheckoutComponent],
  imports: [SelfCheckoutRoutingModule, SharedModule, TranslateModule],
})
export class SelfCheckoutModule {}
