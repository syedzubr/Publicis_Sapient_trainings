import {
  ComponentFixture,
  TestBed,
  fakeAsync,
  tick,
} from '@angular/core/testing';
import { ScoLoginComponent } from './sco-login.component';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SharedModule } from 'app/modules/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { SelfCheckoutComponent } from '../self-checkout/self-checkout.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CredentialsService } from 'app/services/credentials/credentials.service';
import { UserCredentials } from 'app/services/credentials/user-credentials';
import { Observable, of } from 'rxjs';

const userObject: UserCredentials[] = [
  {
    username: 123,
    password: 123,
  },
  {
    username: 12346,
    password: 12399,
  },
  {
    username: 12,
    password: 19990,
  },
];

class MockAuthService {
  public fetchAllCredentials(): Observable<UserCredentials[]> {
    return of(userObject);
  }
}

describe('ScoLoginComponent', () => {
  let component: ScoLoginComponent;
  let fixture: ComponentFixture<ScoLoginComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        SharedModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
      ],
      declarations: [ScoLoginComponent, SelfCheckoutComponent],
      providers: [{ provide: CredentialsService, useClass: MockAuthService }],
    });

    fixture = TestBed.createComponent(ScoLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Testing Functionalities', () => {
    it('should add to userString if parameter is any digit', () => {
      component.numberPassed('1');
      expect(component.userString).toBe('1');
    });

    it('should remove last alphabet from userString if parameter is backspace', () => {
      component.userString = '1234';
      component.numberPassed('backspace');
      expect(component.userString).toBe('123');
    });

    it('should set setUser as false if parameter is done and store userName in nameStore', () => {
      component.userString = '1234';
      component.numberPassed('done');
      expect(component.nameStore).toBe(1234);
      expect(component.setUsername).toBe(false);
    });

    it('should set the user', () => {
      component.ngOnInit();
      expect(component.userCredential).toBe(userObject);
    });

    it('should set setUser as true if userName or password dint match,also set the error as true', () => {
      component.ngOnInit();
      component.nameStore = 12;
      component.userString = '1234';
      component.setUsername = false;
      component.numberPassed('done');

      expect(component.setError).toBe(true);
      expect(component.setUsername).toBe(true);
    });

    it('should navigate to checkout page after authentication', () => {
      const router = TestBed.inject(Router);
      spyOn(router, 'navigate'); // this should be there before all, (ngOninit etc). Gives error if put below.

      component.ngOnInit();
      component.nameStore = 123;
      component.userString = '123';
      component.setUsername = false;
      component.numberPassed('done');

      expect(router.navigate).toHaveBeenCalledWith(['/selfCheckout']);
    });

    it('should authenticate the user with right credentials', () => {
      expect(component.checkAuth(12346, 12399)).toBeTruthy();
    });

    xit('should not authenticate the user with wrong credentials', () => {
      expect(component.checkAuth(1236, 1239)).toBeFalsy();
    });

    it('should call numberPressed() when onKeyDown() is called', () => {
      spyOn(component, 'numberPassed');
      component.onKeyDown();
      expect(component.numberPassed).toHaveBeenCalledWith('done');
    });
  });
});
