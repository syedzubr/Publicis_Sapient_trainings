import {
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { CredentialsService } from 'app/services/credentials/credentials.service';
import { UserCredentials } from 'app/services/credentials/user-credentials';
import { ScoLoginGuardService } from 'app/services/sco-login-guard/sco-login-guard.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-sco-login',
  templateUrl: './sco-login.component.html',
  styleUrls: ['./sco-login.component.scss'],
})
export class ScoLoginComponent implements OnInit, OnDestroy {
  @ViewChild('username') usernameRef: ElementRef;

  userCredential: UserCredentials[];
  userString: string;
  setUsername: boolean;
  nameStore: number;
  setError: boolean;
  CredSubscription: Subscription;

  constructor(
    private router: Router,
    private userCredService: CredentialsService,
    private scoLogin: ScoLoginGuardService
  ) {
    this.userString = '';
    this.setUsername = true;
    this.nameStore = 0;
    this.setError = false;
    this.scoLogin.goToSelfCheckOut = false;
  }

  ngOnInit(): void {
    this.CredSubscription = this.userCredService
      .fetchAllCredentials()
      .subscribe((data) => (this.userCredential = data));
  }

  onKeyDown(): void {
    this.numberPassed('done');
  }

  numberPassed(event: string): void {
    this.usernameRef.nativeElement.focus();

    if (event === 'backspace') {
      this.userString = this.userString.slice(0, -1);
    } else if (event === 'done') {
      // data from userName
      if (this.setUsername) {
        this.setUsername = false;
        this.nameStore = Number(this.userString);
        this.userString = '';
      } else {
        // data from password
        if (!this.checkAuth(this.nameStore, Number(this.userString))) {
          this.setUsername = true;
          this.setError = true;
          this.userString = '';
        } else {
          this.router.navigate(['/selfCheckout']);
        }
      }
    } else {
      this.userString += event;
    }
  }

  checkAuth(username: number, password: number): boolean {
    let authenticate: UserCredentials[];

    authenticate = this.userCredential.filter(
      (data) => data.username === username && data.password === password
    );
    if (authenticate.length) {
      this.scoLogin.goToSelfCheckOut = true;
      return true;
    }
    return false;
  }

  ngOnDestroy(): void {
    this.CredSubscription.unsubscribe();
  }
}
