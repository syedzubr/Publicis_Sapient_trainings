import { SharedModule } from 'app/modules/shared/shared.module';
import { ScoUnlockComponent } from 'app/organisms/sco-unlock/sco-unlock.component';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScoLoginRoutingModule } from './sco-login-routing.module';
import { ScoLoginComponent } from './sco-login.component';

@NgModule({
  imports: [
    ScoLoginRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  declarations: [
    ScoLoginComponent,
    ScoUnlockComponent],
  exports: [],
})
export class ScoLoginModule {}
