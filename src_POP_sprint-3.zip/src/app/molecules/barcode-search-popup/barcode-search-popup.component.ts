import {
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChild,
  ViewChildren,
  ViewEncapsulation,
} from '@angular/core';
import { BarcodeDataService } from 'app/services/barcode-data/barcode-data.service';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { Product } from 'app/services/cart-table/product.interface';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-barcode-search-popup',
  templateUrl: './barcode-search-popup.component.html',
  styleUrls: ['./barcode-search-popup.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class BarcodeSearchPopupComponent implements OnInit, OnDestroy {
  @ViewChild('panel', { read: ElementRef }) public panel: ElementRef<any>;
  @ViewChild('row', { read: ElementRef }) public eachRow: ElementRef<any>;
  @ViewChildren('row') row: QueryList<ElementRef>;

  enteredNumber: string;
  products: Product[] = [];
  inputString = '';
  searchedData: Product[] = [];
  resultString: string;
  valueAdded = false;
  selectedId: number;
  upDownBtn: string;
  searchType = 'barcode';
  selectedIndex = 0;
  size: number;
  fraction: number;
  private dataSubscrition: Subscription;

  constructor(
    private barcodeService: BarcodeDataService,
    private cartService: CartProductService
  ) {}

  ngOnInit(): void {
    this.dataSubscrition = this.barcodeService
      .fetchAllProducts()
      .subscribe((info: Product[]) => {
        this.products = info;
      });
  }

  public changeSearchType(str: string): void {
    if (str !== '') {
      this.searchType = str;
    }
  }

  public handleClick(id: string): void {
    if (id !== null) {
      if (id === 'backspace') {
        this.inputString = this.inputString.slice(0, -1);
      } else if (id && id !== 'done') {
        this.inputString = this.inputString + id;
      }
      this.enteredNumber = this.inputString;
      if (id === 'done') {
        this.valueAdded = true;
        this.search();
      }
    }
  }

  public search(): void {
    if (this.searchType === 'barcode') {
      this.searchedData = this.products.filter((item) =>
        item.barcode.toString().includes(this.inputString)
      );
    } else {
      this.searchedData = this.products.filter((item) =>
        item.sku.toString().includes(this.inputString)
      );
    }

    this.resultString = `${this.searchedData.length} results found for "${this.inputString}"`;
    if (this.searchedData.length) {
      this.selectedId = this.searchedData[this.selectedIndex].barcode;
    }
  }

  public navigate(key: string): void {
    const indx = this.selectedIndex;
    this.size = 0;
    this.fraction =
      this.panel.nativeElement.clientHeight /
      (this.eachRow.nativeElement.clientHeight + 28);

    while (this.fraction > 1) {
      this.size++;
      this.fraction--;
    }
    if (
      key === 'down' &&
      this.searchedData.length > 1 &&
      this.searchedData[this.selectedIndex].barcode !==
        this.searchedData[this.searchedData.length - 1].barcode
    ) {
      this.selectedIndex++;
      this.selectedId = this.searchedData[this.selectedIndex].barcode;

      if (indx >= this.size - 1 && this.eachRow) {
        this.panel.nativeElement.scrollTop += this.eachRow.nativeElement.clientHeight;
      }
    } else if (
      this.searchedData[0].barcode !== this.selectedId &&
      key === 'up' &&
      this.searchedData.length > 1
    ) {
      this.selectedIndex--;
      this.selectedId = this.searchedData[this.selectedIndex].barcode;

      if (indx < this.searchedData.length - this.size + 1 && this.eachRow) {
        this.panel.nativeElement.scrollTop -= this.eachRow.nativeElement.clientHeight;
      }
    }
  }

  addProduct(productBarcode): void {
    if (productBarcode !== null) {
      const sendProduct: Product | undefined = this.products.find(
        (item: Product) => item.barcode === productBarcode
      );
      if (sendProduct !== undefined) {
        this.cartService.addProduct(sendProduct);
      }
    }
  }

  ngOnDestroy(): void {
    this.dataSubscrition.unsubscribe();
  }
}
