import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LandingGuardService } from 'app/services/landing-guard/landing-guard.service';
import { MockComponent } from 'ng2-mock-component';
import { TranslateModule } from '@ngx-translate/core';
import { VoidTransactionComponent } from './void-transaction.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MaterialModule } from 'app/modules/shared/material/material.module';

describe('VoidTransactionComponent', () => {
  let component: VoidTransactionComponent;
  let fixture: ComponentFixture<VoidTransactionComponent>;
  let dialogRef;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        VoidTransactionComponent,
        MockComponent({
          selector: 'app-button',
          inputs: ['label', 'width', 'type', 'height'],
        }),
        MockComponent({
          selector: 'app-popover',
        }),
      ],
      imports: [RouterTestingModule, TranslateModule.forRoot(), MaterialModule],
      providers: [
        {
          provide: LandingGuardService,
          useValue: {
            goToSelfCheckout: false,
          },
        },
        { provide: MatDialogRef, useValue: { close: () => {} } },
        { provide: MAT_DIALOG_DATA, useValue: [] },
      ],
    });
    fixture = TestBed.createComponent(VoidTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    dialogRef = TestBed.inject(MatDialogRef);
    spyOn(dialogRef, 'close');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('toSelfCheckout', () => {
    it('on clicking on yes it should navigate to self checkout page', () => {
      const service = TestBed.inject(LandingGuardService);

      component.redirectToSelfCheckout();

      expect(service.goToSelfCheckout).toEqual(true);
      expect(dialogRef.close).toHaveBeenCalled();
    });

    it('should call closeDialog() and close dialog ', () => {
      component.closeDialog();

      expect(dialogRef.close).toHaveBeenCalled();
    });
  });
});
