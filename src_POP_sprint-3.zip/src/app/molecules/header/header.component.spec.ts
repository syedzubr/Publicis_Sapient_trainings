import { HeaderComponent } from 'app/molecules/header/header.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ComponentFixtureAutoDetect } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MockComponent } from 'ng2-mock-component';

describe('HeaderComponent', () => {
  let header: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [HeaderComponent, MockComponent({selector: 'app-date'})],
      providers: [{ provide: ComponentFixtureAutoDetect, useValue: true }],
    });
    fixture = TestBed.createComponent(HeaderComponent);
    header = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Header Component testing', () => {
    expect(header).toBeTruthy();
  });
});
