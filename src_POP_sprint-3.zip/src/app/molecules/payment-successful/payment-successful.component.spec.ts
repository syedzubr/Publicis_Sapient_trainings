import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PaymentSuccessfulComponent } from './payment-successful.component';
import { CountdownModule } from 'ngx-countdown';
import { PopoverComponent } from '../../atoms/components/popover/popover.component';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('PaymentSuccessfulComponent', () => {
  let component: PaymentSuccessfulComponent;
  let fixture: ComponentFixture<PaymentSuccessfulComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CountdownModule, MatButtonModule, MatDialogModule, HttpClientTestingModule, HttpClientModule, RouterTestingModule],
      declarations: [PaymentSuccessfulComponent, PopoverComponent],
    }).compileComponents();

  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentSuccessfulComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
