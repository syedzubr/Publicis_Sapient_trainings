import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { CouponCode } from 'app/services/apply-coupon/coupon-code.interface';
import { ApplyCouponService } from 'app/services/apply-coupon/apply-coupon.service';
import { RouterTestingModule } from '@angular/router/testing';
import { CouponComponent } from './coupon.component';
import { MockComponent } from 'ng2-mock-component';
import { of } from 'rxjs';
import { CartProductService } from 'app/services/cart-table/cart-product.service';

describe('CouponComponent', () => {
  let component: CouponComponent;
  let fixture: ComponentFixture<CouponComponent>;
  let couponService: ApplyCouponService;
  let couponCodes: CouponCode[];
  let cartService: CartProductService;

  const mockDialog = {
    close: jasmine.createSpy('close'),
  };
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        CouponComponent,
        MockComponent({
          selector: 'app-on-screen-keypad',
        }),

        MockComponent({
          selector: 'app-popover',
        }),
      ],
      imports: [
        MatDialogModule,
        MatButtonModule,
        MatIconModule,
        TranslateModule.forRoot(),
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([]),
      ],
      providers: [
        {
          provide: MatDialogRef,
          useValue: mockDialog,
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    couponService = TestBed.inject(ApplyCouponService);
    cartService = TestBed.inject(CartProductService);

    couponCodes = [
      {
        couponCode: 55,
        discountPercent: 5,
      },
      {
        couponCode: 1010,
        discountPercent: 10,
      },
    ];
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render enteredNumber ViewChild', () => {
    expect(component.enteredNumber).toBeTruthy();
  });

  it('should return the particular string on pressing number on keypad', () => {
    component.handleClick('1');
    component.handleClick('2');
    component.handleClick('3');
    expect(component.inputString).toEqual('123');
  });

  it('should return the particular string on pressing backspace on keypad', () => {
    component.handleClick('1');
    component.handleClick('2');
    component.handleClick('3');
    component.handleClick('backspace');
    expect(component.inputString).toEqual('12');
  });

  it('should call applyDiscount on pressing done', () => {
    spyOn(component, 'applyDiscount');
    component.handleClick('1');
    component.handleClick('2');
    component.handleClick('3');
    component.handleClick('done');
    fixture.detectChanges();
    expect(component.applyDiscount).toHaveBeenCalled();
  });

  it('should set error to true when searchData is undefined', () => {
    component.couponCodes = couponCodes;
    component.inputString = 'abc';
    spyOn(couponService, 'updateDiscount');

    component.applyDiscount();

    expect(component.setError).toEqual(true);
  });

  it('should call updateDiscount on getting searchedData', () => {
    component.couponCodes = couponCodes;
    component.inputString = '55';
    component.searchedData = couponService.coupon[0];
    spyOn(couponService, 'updateDiscount');

    component.applyDiscount();

    expect(couponService.updateDiscount).toHaveBeenCalledWith(5);
  });

  it('should fetch data from the service', () => {
    const response: CouponCode[] = [];
    spyOn(couponService, 'fetchAllCoupon').and.returnValue(of(response));

    component.ngOnInit();
    fixture.detectChanges();

    expect(component.couponCodes).toEqual(response);
  });

  it('should set error if data is not found', () => {
    component.applyDiscount();
    expect(component.noError).toBeFalse();
  });

  it('should call next total price', () => {
    component.couponCodes = couponCodes;
    component.inputString = '55';
    spyOn(cartService, 'nextTotalPrice');
    component.applyDiscount();
    fixture.detectChanges();
    expect(cartService.nextTotalPrice).toHaveBeenCalled();
  });
});
