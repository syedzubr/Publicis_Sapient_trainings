import { CardTableBridgeService } from 'app/services/card-table-bridge-service/card-table-bridge.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { Product } from 'app/services/cart-table/product.interface';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss'],
})
export class ProductDetailComponent implements OnInit, OnDestroy {
  product: Product;
  disableQuantitybtn: boolean;
  disableDeleteBtn: boolean;
  cartbridgeSubscription: Subscription;
  cartSubscription: Subscription;

  constructor(
    private cartserivce: CartProductService,
    private cardBridgeService: CardTableBridgeService
  ) {
    this.disableDeleteBtn = false;
    this.disableQuantitybtn = false;
  }

  ngOnInit(): void {
    this.cartbridgeSubscription = this.cardBridgeService.productIdSource$.subscribe(
      (data) => (this.product = data)
    );

    this.cartSubscription = this.cartserivce.length.subscribe((data) => {
      if (data > 1) {
        this.disableDeleteBtn = false;
      }
      this.disableQuantitybtn = false;
    });
  }

  incrementProduct(barcode: number): void {
    this.cartserivce.incrementQuantity(barcode);
    this.disableQuantitybtn = false;
  }

  decrementProduct(barcode: number): void {
    const ProductsInCart: number = this.cartserivce.totalProductInCart();
    if (ProductsInCart > 1 && this.product.qty >= 1) {
      this.cartserivce.decrementQuantity(barcode);
    } else {
      if (ProductsInCart === 1 && this.product.qty === 1) {
        this.disableQuantitybtn = true;
      } else {
        this.disableQuantitybtn = false;
        this.cartserivce.decrementQuantity(barcode);
      }
    }
  }

  deleteItem(barcode: number): void {
    if (this.cartserivce.totalProductInCart() > 1) {
      this.cartserivce.deleteProduct(barcode);
    } else {
      this.disableDeleteBtn = true;
    }
  }

  ngOnDestroy(): void {
    this.cartbridgeSubscription.unsubscribe();
    this.cartSubscription.unsubscribe();
  }
}
