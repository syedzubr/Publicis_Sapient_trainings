import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContainerComponent } from './container.component';
import { TranslateModule } from '@ngx-translate/core';
import { MockComponent } from 'ng2-mock-component';

describe('ContainerComponent', () => {
  let component: ContainerComponent;
  let fixture: ComponentFixture<ContainerComponent>;

  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [
        ContainerComponent,
        MockComponent({
          selector: 'app-header',
        }),
      ],
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create skeleton', () => {
    expect(component).toBeTruthy();
  });

  it('should display header', () => {
    const header = fixture.debugElement.children;
    expect(header).toBeTruthy();
  });
});
