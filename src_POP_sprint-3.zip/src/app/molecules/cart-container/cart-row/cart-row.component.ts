import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Product } from 'app/services/cart-table/product.interface';

@Component({
  selector: 'app-cart-row',
  templateUrl: './cart-row.component.html',
  styleUrls: ['./cart-row.component.scss'],
})
export class CartRowComponent {
  @Input() status: number;
  @Input() product: any;

  @Output() productDetails = new EventEmitter();

  constructor() {
    this.status = 1;
  }

  sendProductDetails(data: Product): void {
    this.productDetails.emit(data);
  }
}
