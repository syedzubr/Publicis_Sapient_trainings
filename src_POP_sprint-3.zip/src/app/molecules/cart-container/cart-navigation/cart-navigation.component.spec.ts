import { CartNavigationComponent } from './cart-navigation.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { arrowType } from 'app/atoms/models/common.model';

@Component({ selector: 'app-button', template: '' })
class MockAppButtonComponent {
  @Input() label: string;
  @Input() width: number;
  @Input() type: any;
  @Output() clicked: EventEmitter<void> = new EventEmitter();
}

describe('CartNavigationComponent', () => {
  let component: CartNavigationComponent;
  let fixture: ComponentFixture<CartNavigationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), HttpClientTestingModule],
      declarations: [CartNavigationComponent, MockAppButtonComponent],
    });

    fixture = TestBed.createComponent(CartNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit arrow type', () => {
    spyOn(component.moveType, 'emit');
    component.moveArrowUp();
    expect(component.moveType.emit).toHaveBeenCalledWith(arrowType.UP);
  });

  it('should emit arrow type down on moveArrowDown', () => {
    spyOn(component.moveType, 'emit');
    component.moveArrowDown();
    expect(component.moveType.emit).toHaveBeenCalledWith(arrowType.DOWN);
  });

});
