import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { arrowType, ButtonType } from 'app/atoms/models/common.model';

@Component({
  selector: 'app-cart-navigation',
  templateUrl: './cart-navigation.component.html',
  styleUrls: ['./cart-navigation.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CartNavigationComponent {
  @Input() status: number;
  @Output() moveType: EventEmitter<arrowType> = new EventEmitter();
  btnType = ButtonType;

  moveArrowUp(): void {
    this.moveType.emit(arrowType.UP);
  }
  moveArrowDown(): void {
    this.moveType.emit(arrowType.DOWN);
  }
}
