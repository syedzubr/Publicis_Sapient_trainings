import { CartContainerComponent } from './cart-container.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CardTableBridgeService } from 'app/services/card-table-bridge-service/card-table-bridge.service';
import { TranslateModule } from '@ngx-translate/core';
import { MockComponent } from 'ng2-mock-component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { Product } from 'app/services/cart-table/product.interface';
import { of } from 'rxjs';
import { arrowType } from 'app/atoms/models/common.model';

describe('CartContainerComponent', () => {
  let component: CartContainerComponent;
  let fixture: ComponentFixture<CartContainerComponent>;
  let cartService: CartProductService;
  let bridgeService: CardTableBridgeService;
  let products: Product[];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        CartContainerComponent,
        MockComponent({
          selector: 'app-cart-row',
          inputs: ['status', 'product'],
          outputs: ['productDetails'],
        }),
        MockComponent({ selector: 'app-cart-navigation', inputs: ['status'] }),
      ],
      imports: [TranslateModule.forRoot(), HttpClientTestingModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CartContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    cartService = TestBed.inject(CartProductService);
    bridgeService = TestBed.inject(CardTableBridgeService);
    products = [
      {
        productId: 1,
        productName: 'test',
        price: 120,
        productUrl: 'test',
        qty: 3,
        barcode: 1234,
        sku: 123,
      },
      {
        productId: 2,
        productName: 'test2',
        price: 120,
        productUrl: 'test2',
        qty: 3,
        barcode: 1234,
        sku: 123,
      },
      {
        productId: 3,
        productName: 'test3',
        price: 125,
        productUrl: 'test3',
        qty: 4,
        barcode: 12345,
        sku: 1234,
      },
    ];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render panel ViewChild', () => {
    expect(component.panel).toBeTruthy();
  });

  describe('sendToCard', () => {
    it('should set selected data', () => {
      component.sendToCard(products[0]);

      expect(component.selectedData).toBe(products[0]);
    });

    it('should call showProduct if state is set', () => {
      component.state = 1;

      spyOn(bridgeService, 'showProduct');

      component.sendToCard(products[0]);

      expect(bridgeService.showProduct).toHaveBeenCalledWith(products[0]);
    });

    it('should not call showProduct if state is not set', () => {
      component.state = 0;

      spyOn(bridgeService, 'showProduct');

      component.sendToCard(products[0]);

      expect(bridgeService.showProduct).not.toHaveBeenCalled();
    });
  });

  describe('ngOnInit', () => {
    it('should call fetchAllProduct if product length is zero', () => {
      const response: Product[] = [];

      spyOn(bridgeService, 'showProduct');
      spyOn(cartService, 'fetchAllProduct').and.returnValue(of(response));

      component.ngOnInit();
      fixture.detectChanges();

      expect(component.products).toEqual(response);
      expect(bridgeService.showProduct).toHaveBeenCalledWith(response[0]);
    });
    it('should directly assign when product length is not zero', () => {
      cartService.products = products;
      component.ngOnInit();
      fixture.detectChanges();

      expect(component.products).toEqual(cartService.products);
    });
  });

  describe('moveArrow', () => {
    it('should get fraction of height of rows with respect to a row', () => {
      component.products = products;
      component.selectedData = products[0];
      fixture.detectChanges();

      spyOnProperty(
        component.panel.nativeElement,
        'clientHeight'
      ).and.returnValue(1000);

      spyOnProperty(
        component.eachRow.nativeElement,
        'clientHeight'
      ).and.returnValue(100);

      component.moveArrow(arrowType.UP);

      expect(component.size).toBe(9);
      expect(component.fraction).toBe(1);
    });

    it('should select the above product on moveArrow(arrowType.UP) ', () => {
      component.products = products;
      component.selectedData = products[1];
      fixture.detectChanges();
      component.moveArrow(arrowType.UP);
      const indx = component.products.indexOf(component.selectedData);
      expect(indx).toBe(0);
    });

    it('should not select the above product on moveArrow(arrowType.UP) if it is the first product ', () => {
      component.products = products;
      component.selectedData = products[0];
      fixture.detectChanges();
      component.moveArrow(arrowType.UP);
      const indx = component.products.indexOf(component.selectedData);
      expect(indx).toBe(0);
    });

    it('should select the below product on moveArrow(arrowType.DOWN) ', () => {
      component.products = products;
      component.selectedData = products[0];
      fixture.detectChanges();
      component.moveArrow(arrowType.DOWN);
      const indx = component.products.indexOf(component.selectedData);
      expect(indx).toBe(1);
    });

    it('should  not select the below product on moveArrow(arrowType.DOWN) if it is the last product', () => {
      component.products = products;
      component.selectedData = products[2];
      fixture.detectChanges();
      component.moveArrow(arrowType.DOWN);
      const indx = component.products.indexOf(component.selectedData);
      expect(indx).toBe(2);
    });

    it('should scroll up when up arrow is clicked', () => {
      component.products = products;
      component.selectedData = products[2];
      fixture.detectChanges();

      spyOnProperty(
        component.panel.nativeElement,
        'clientHeight'
      ).and.returnValue(1000);

      spyOnProperty(
        component.eachRow.nativeElement,
        'clientHeight'
      ).and.returnValue(100);

      cartService.products.length = 11;

      const spy = spyOnProperty(
        component.panel.nativeElement,
        'scrollTop',
        'set'
      );

      component.moveArrow(arrowType.UP);
      fixture.detectChanges();

      expect(spy).toHaveBeenCalled();
    });

    it('should scroll down when up arrow is clicked', () => {
      component.products = products;
      component.selectedData = products[0];
      fixture.detectChanges();

      spyOnProperty(
        component.panel.nativeElement,
        'clientHeight'
      ).and.returnValue(200);

      spyOnProperty(
        component.eachRow.nativeElement,
        'clientHeight'
      ).and.returnValue(100);

      cartService.products.length = 3;

      const spy = spyOnProperty(
        component.panel.nativeElement,
        'scrollTop',
        'set'
      );

      component.moveArrow(arrowType.DOWN);
      fixture.detectChanges();

      expect(spy).toHaveBeenCalled();
    });
  });
});
