import { arrowType } from 'app/atoms/models/common.model';
import { CardTableBridgeService } from 'app/services/card-table-bridge-service/card-table-bridge.service';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { Product } from 'app/services/cart-table/product.interface';
import {
  Component,
  Input,
  OnInit,
  ViewChild,
  ElementRef,
  ViewChildren,
  QueryList,
} from '@angular/core';

import { Subscription } from 'rxjs';

@Component({
  selector: 'app-cart-container',
  templateUrl: './cart-container.component.html',
  styleUrls: ['./cart-container.component.scss'],
})
export class CartContainerComponent implements OnInit {
  @Input() state: number;
  @Input() height: number;

  @ViewChild('panel', { read: ElementRef }) public panel: ElementRef<any>;
  @ViewChild('row', { read: ElementRef }) public eachRow: ElementRef<any>;
  @ViewChildren('row') row: QueryList<ElementRef>;

  productsSubscribed: Subscription;
  selectionSubscribed: Subscription;
  selectedData: Product;
  products: Product[];
  fraction: number;
  size: number;
  constructor(
    private service: CartProductService,
    private bridgeService: CardTableBridgeService
  ) {
    this.state = 1;
  }

  ngOnInit(): void {
    this.selectionSubscribed = this.service.selectedSource.subscribe(
      (data) => (this.selectedData = data)
    );

    if (this.service.products.length === 0) {
      this.productsSubscribed = this.service
        .fetchAllProduct()
        .subscribe((data) => {
          this.products = data;
          this.bridgeService.showProduct(this.products[0]);
        });
    } else {
      this.products = this.service.products;
    }
  }

  sendToCard(product: Product): void {
    this.selectedData = product;
    if (this.state) {
      this.bridgeService.showProduct(product);
    }
  }

  // -----------  cart-navigation -----------------

  moveArrow(type: arrowType): void {
    const indx = this.products.indexOf(this.selectedData);

    this.size = 0;

    this.fraction =
      this.panel.nativeElement.clientHeight /
      this.eachRow.nativeElement.clientHeight;

    while (this.fraction > 1) {
      this.size++;
      this.fraction--;
    }

    if (type === arrowType.UP) {
      if (indx > 0) {
        this.selectedData = this.products[indx - 1];
        this.bridgeService.showProduct(this.selectedData);
      }

      if (indx < this.service.products.length - this.size + 1 && this.eachRow) {
        this.panel.nativeElement.scrollTop -= this.eachRow.nativeElement.clientHeight;
      }
    } else {
      // Down movement

      if (indx < this.products.length - 1) {
        this.selectedData = this.products[indx + 1];
        this.bridgeService.showProduct(this.selectedData);
      }

      if (indx >= this.size - 1 && this.eachRow) {
        this.panel.nativeElement.scrollTop += this.eachRow.nativeElement.clientHeight;
      }
    }
  }
  // -----------  cart-navigation -------------
}
