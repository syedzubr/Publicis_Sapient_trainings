import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';
import { UserCredentials } from './user-credentials';

@Injectable({
  providedIn: 'root',
})
export class CredentialsService {
  constructor(private httpClient: HttpClient) {}

  fetchAllCredentials(): Observable<UserCredentials[]> {
    return this.httpClient.get<UserCredentials[]>(
      environment.LOGIN_CREDENTIALS
    );
  }
}
