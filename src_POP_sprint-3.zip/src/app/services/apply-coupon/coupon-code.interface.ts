export interface CouponCode {
  couponCode: number;
  discountPercent: number;
}
