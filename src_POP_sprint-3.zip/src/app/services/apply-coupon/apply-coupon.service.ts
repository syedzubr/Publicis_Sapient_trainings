import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'environments/environment';
import { CouponCode } from 'app/services/apply-coupon/coupon-code.interface';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ApplyCouponService {
  constructor(private httpClient: HttpClient) {}
  coupon: CouponCode[] = [];
  discount = 0;
  couponSubject = new BehaviorSubject(this.discount);
  change = this.couponSubject.asObservable();

  fetchAllCoupon(): Observable<CouponCode[]> {
    return this.httpClient.get<CouponCode[]>(environment.COUPON_DATA).pipe(
      tap((data) => {
        this.coupon = data;
      })
    );
  }

  updateDiscount(disc: number): any {
    this.discount = disc;
    this.couponSubject.next(this.discount);
  }
}
