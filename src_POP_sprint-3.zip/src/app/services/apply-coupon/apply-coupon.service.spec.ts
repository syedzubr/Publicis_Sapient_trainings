import { HttpErrorResponse } from '@angular/common/http';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { CouponCode } from 'app/services/apply-coupon/coupon-code.interface';
import { environment } from 'environments/environment';
import { throwError } from 'rxjs';
import { skip } from 'rxjs/operators';
import { ApplyCouponService } from './apply-coupon.service';

describe('ApplyCouponService', () => {
  let service: ApplyCouponService;
  let httpMock: HttpTestingController;
  let couponCodes: CouponCode[];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ApplyCouponService],
    });
    service = TestBed.inject(ApplyCouponService);
    httpMock = TestBed.inject(HttpTestingController);

    couponCodes = [
      {
        couponCode: 55,
        discountPercent: 5,
      },
      {
        couponCode: 1010,
        discountPercent: 10,
      },
    ];
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('fetchAllCoupon', () => {
    it('should return the data', () => {
      service.fetchAllCoupon().subscribe((data) => {
        expect(service.coupon.length).toBe(2);
      });

      const mockRequest = httpMock.expectOne(environment.COUPON_DATA);
      expect(mockRequest.request.method).toBe('GET');
      mockRequest.flush(couponCodes);
      httpMock.verify();
    });

    it('Observable - Invalid or No data', () => {
      const fakeError = {
        message: '404 NOT FOUND',
        status: 404,
        statusText: 'NOT FOUND',
      };
      spyOn(service, 'fetchAllCoupon').and.returnValue(throwError(fakeError));

      service.fetchAllCoupon().subscribe(
        (data: CouponCode[]) => {},
        (error: HttpErrorResponse) => {
          expect(error).toBeTruthy();
          expect(error.message).toBe('404 NOT FOUND');
        }
      );
    });
  });

  describe('updateDiscount', () => {
    it('should update discount', () => {
      service.coupon = couponCodes;

      service.change.pipe(skip(1)).subscribe((data: number) => {
        expect(data).toEqual(10);
      });
      service.updateDiscount(10);
    });
  });
});
