import { Injectable } from '@angular/core';
import { Observable, interval } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TimerService {
  getTimer(): Observable<string> {
    return new Observable<string>((observer) => {
      const timer = interval(1000);
      timer.subscribe(() => {
        observer.next(new Date().toString());
      });
    });
  }
}
