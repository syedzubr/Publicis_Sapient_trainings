import { TestBed } from '@angular/core/testing';

import { PaymentGuardService } from './payment-guard.service';

describe('PaymentGuardService', () => {
  let service: PaymentGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PaymentGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set the value when setter is called', () => {
    service.paymentSuccess = true;
    expect(service['paymentSuccessful']).toBeTruthy();
  });

  it('should send the value when getter is called', () => {
    service.paymentSuccess = true;
    expect(service.paymentSuccess).toBeTruthy();
  });

});
