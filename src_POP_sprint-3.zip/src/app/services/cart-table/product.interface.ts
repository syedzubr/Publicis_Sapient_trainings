export interface Product {
  productId: number;
  productName: string;
  price: number;
  productUrl: string;
  qty: number;
  barcode: number;
  sku: number;
}
