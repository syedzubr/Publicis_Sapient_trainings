import { TestBed } from '@angular/core/testing';
import { CardTableBridgeService } from '../card-table-bridge-service/card-table-bridge.service';
import { CartProductService } from './cart-product.service';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { environment } from 'environments/environment';
import { Product } from './product.interface';
import { skip } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

describe('CartProductService', () => {
  let cartService: CartProductService;
  let cratBridge: CardTableBridgeService;
  let httpMock: HttpTestingController;
  let product: Product[];

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CartProductService, CardTableBridgeService],
    });
    cartService = TestBed.inject(CartProductService);
    cratBridge = TestBed.inject(CardTableBridgeService);
    httpMock = TestBed.inject(HttpTestingController);

    product = [
      {
        productId: 1,
        productName: 'Country fresh tomatoes, 500gms',
        price: 2.5,
        productUrl: 'assets/products/tomatoes.jpg',
        qty: 1,
        barcode: 123456789012,
        sku: 154397,
      },
      {
        productId: 2,
        productName: 'Fresh Avocado, 1pc',
        price: 0.75,
        productUrl: 'assets/products/avacado.jpg',
        qty: 3,
        barcode: 123456789022,
        sku: 154390,
      },
    ];
  });

  it('should be created', () => {
    expect(cartService).toBeTruthy();
  });

  describe('fetchAllProduct', () => {
    it('should return the data', () => {
      spyOn(cartService, 'selectProduct');
      spyOn(cartService, 'nextTotalPrice');
      cartService.fetchAllProduct().subscribe((allProducts) => {
        expect(cartService.products.length).toBe(2);
        expect(cartService.selectProduct).toHaveBeenCalled();
        expect(cartService.nextTotalPrice).toHaveBeenCalled();
      });

      const mockRequest = httpMock.expectOne(environment.PRODUCT_DATA);
      expect(mockRequest.request.method).toBe('GET');
      mockRequest.flush(product);
      httpMock.verify();
    });

    it('Observable - Invalid or No data', () => {
      const fakeError = {
        message: '404 NOT FOUND',
        status: 404,
        statusText: 'NOT FOUND',
      };
      spyOn(cartService, 'fetchAllProduct').and.returnValue(throwError(fakeError));

      cartService.fetchAllProduct().subscribe(
        (products: Product[]) => {},
        (error: HttpErrorResponse) => {
          expect(error).toBeTruthy();
          expect(error.message).toBe('404 NOT FOUND');
        }
      );
    });
  });

  describe('incrementQuantity', () => {
    it('should increment if present', () => {
      cartService.products = product;
      spyOn(cartService, 'nextTotalPrice');
      cartService.incrementQuantity(123456789012);

      expect(cartService.products[0].qty).toBe(2);
      expect(cartService.nextTotalPrice).toHaveBeenCalled();
    });

    it('should not increment if not present', () => {
      cartService.products = product;
      spyOn(cartService, 'nextTotalPrice');
      cartService.incrementQuantity(1245412);

      expect(cartService.products[0].qty).toBe(1);
      expect(cartService.nextTotalPrice).toHaveBeenCalled();
    });
  });

  describe('decrementQuantity', () => {
    it('should decrement if present with quantity greater than 1', () => {
      cartService.products = product;
      spyOn(cartService, 'nextTotalPrice');
      cartService.decrementQuantity(123456789022);

      expect(cartService.products[1].qty).toBe(2);
      expect(cartService.nextTotalPrice).toHaveBeenCalled();
    });

    it('should delete if present with quantity equal to 1', () => {
      cartService.products = product;
      spyOn(cartService, 'nextTotalPrice');
      cartService.decrementQuantity(123456789012);

      cartService.deleteProduct(123456789012);

      expect(cartService.products.length).toBe(1);
      expect(cartService.nextTotalPrice).toHaveBeenCalled();
    });

    it('should not decrement if not present', () => {
      cartService.products = product;
      spyOn(cartService, 'nextTotalPrice');
      cartService.decrementQuantity(178904545412);

      expect(cartService.products[1].qty).toBe(3);
      expect(cartService.nextTotalPrice).toHaveBeenCalled();
    });
  });

  describe('deleteProduct', () => {
    it('should not delete if not present', () => {
      cartService.products = product;

      cartService.deleteProduct(1234);

      expect(cartService.products.length).toBe(2);
    });

    it('should delete if present', () => {
      cartService.products = product;

      spyOn(cratBridge, 'showProduct');
      spyOn(cartService, 'selectProduct');
      spyOn(cartService, 'nextTotalPrice');

      cartService.deleteProduct(123456789012);

      expect(cartService.products.length).toBe(1);
      expect(cratBridge.showProduct).toHaveBeenCalledWith(cartService.products[0]);
      expect(cartService.selectProduct).toHaveBeenCalled();
      expect(cartService.nextTotalPrice).toHaveBeenCalled();
    });
  });

  describe('addProduct', () => {
    it('should add the product if not present', () => {
      cartService.products = product;

      const data = {
        productId: 3,
        productName: 'Fresh Avocado, 1pc',
        price: 0.7,
        productUrl: 'assets/products/avacado.jpg',
        qty: 5,
        barcode: 123453333,
        sku: 154344,
      };
      spyOn(cartService, 'nextTotalPrice');
      cartService.addProduct(data);

      expect(cartService.products).toContain(data);
      expect(cartService.products.length).toBe(3);
      expect(cartService.nextTotalPrice).toHaveBeenCalled();
    });

    it('should not add the product if present', () => {
      cartService.products = product;

      const data = {
        productId: 1,
        productName: 'Country fresh tomatoes, 500gms',
        price: 2.5,
        productUrl: 'assets/products/tomatoes.jpg',
        qty: 1,
        barcode: 123456789012,
        sku: 154397,
      };
      spyOn(cartService, 'nextTotalPrice');
      cartService.addProduct(data);

      expect(cartService.products.length).toBe(2);
      expect(cartService.nextTotalPrice).toHaveBeenCalled();
    });
  });

  describe('getTotalPrice', () => {
    it('should return total price', () => {
      cartService.products = product;

      const totalPrice = cartService.getTotalPrice();

      expect(totalPrice).toBe(4.75);
    });
  });

  describe('selectProduct', () => {
    it('should select first product', () => {
      cartService.products = product;

      cartService.selectedSource.pipe(skip(1)).subscribe((selectedProduct: Product) => {
        expect(selectedProduct).toEqual(cartService.products[0]);
      });
      cartService.selectProduct();
    });
  });

  describe('nextTotalPrice', () => {
    it('should get next total price', () => {
      cartService.products = product;

      cartService.totalPrice.pipe(skip(1)).subscribe((price: number) => {
        expect(price).toEqual(4.75);
      });
      cartService.nextTotalPrice();
    });
  });

  describe('totalProductInCart', () => {
    it('should return number of products', () => {
      cartService.products = product;

      const totalProducts = cartService.totalProductInCart();

      expect(totalProducts).toBe(2);

      cartService.deleteProduct(123456789012);

      const total = cartService.totalProductInCart();

      expect(total).toBe(1);
    });
  });
});
