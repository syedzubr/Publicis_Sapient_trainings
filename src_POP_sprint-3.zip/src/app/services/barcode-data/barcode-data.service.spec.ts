import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { BarcodeDataService } from './barcode-data.service';
import { throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { environment } from 'environments/environment';

describe('BarcodeDataService', () => {
  let service: BarcodeDataService;
  let httpMock: HttpTestingController;
  let serviceSpy: jasmine.SpyObj<BarcodeDataService>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BarcodeDataService],
    });
    service = TestBed.inject(BarcodeDataService);
    httpMock = TestBed.inject(HttpTestingController);
    serviceSpy = jasmine.createSpyObj(BarcodeDataService, [
      'fetchAllProducts',
    ]);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Observable - Data is being fetched', () => {
    const data = [
      {
        productId: 1,
        productName: 'Country fresh tomatoes, 500gms',
        price: 2.5,
        productUrl: 'assets/products/tomatoes.jpg',
        qty: 1,
        barcode: 123456789012,
        sku: 154397,
      },
      {
        productId: 2,
        productName: 'Fresh Avocado, 1pc',
        price: 0.75,
        productUrl: 'assets/products/avacado.jpg',
        qty: 3,
        barcode: 123456789022,
        sku: 154390,
      },
    ];

    service.fetchAllProducts().subscribe((item) => {
      expect(item).toBeTruthy();
      expect(item.length).toBe(2);
    });

    const mockRequest = httpMock.expectOne(environment.BARCODE_DATA);
    expect(mockRequest.request.method).toBe('GET');
    mockRequest.flush(data);
    httpMock.verify();
  });

  it('Observable - Invalid or No data', () => {
    const fakeError = {
      message: '404 NOT FOUND',
      status: 404,
      statusText: 'NOT FOUND',
    };

    serviceSpy.fetchAllProducts.and.returnValue(throwError(fakeError));

    serviceSpy.fetchAllProducts().subscribe(
      () => {},
      (error: HttpErrorResponse) => {
        expect(error).toBeTruthy();
        expect(error.message).toBe('404 NOT FOUND');
      }
    );
  });
});
