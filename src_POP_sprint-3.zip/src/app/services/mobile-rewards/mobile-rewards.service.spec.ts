import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { MobileRewardsService } from './mobile-rewards.service';
import { throwError } from 'rxjs';
import { Rewards } from './mobile-rewards.interface';
import { HttpErrorResponse } from '@angular/common/http';
import { environment } from 'environments/environment';

describe('MobileRewardsService', () => {
  let service: MobileRewardsService;
  let httpMock: HttpTestingController;
  let serviceSpy: jasmine.SpyObj<MobileRewardsService>;
  let functionSpy: jasmine.SpyObj<MobileRewardsService>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [MobileRewardsService],
    });
    service = TestBed.inject(MobileRewardsService);
    httpMock = TestBed.inject(HttpTestingController);
    serviceSpy = jasmine.createSpyObj(MobileRewardsService, [
      'fetchCustomerData',
    ]);
    functionSpy = jasmine.createSpyObj(MobileRewardsService, [
      'fetchCustomerDataById',
    ]);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Observable - Data is being fetched', () => {
    const data = [
      {
        id: 1,
        mobile: 1234567890,
        points: 25,
        name: 'John Doe',
      },
      {
        id: 2,
        mobile: 8160052926,
        points: 30,
        name: 'Parth Vaghela',
      },
    ];

    service.fetchCustomerData().subscribe((item) => {
      expect(item).toBeTruthy();
      expect(item.length).toBe(2);
    });

    const mockRequest = httpMock.expectOne(environment.MOBILE_REWARDS_DATA);
    expect(mockRequest.request.method).toBe('GET');
    mockRequest.flush(data);
    httpMock.verify();
  });

  it('Observable - Invalid or No data', () => {
    const fakeError = {
      message: '404 NOT FOUND',
      status: 404,
      statusText: 'NOT FOUND',
    };
    serviceSpy.fetchCustomerData.and.returnValue(throwError(fakeError));

    serviceSpy.fetchCustomerData().subscribe(
      (data: Rewards[]) => {},
      (error: HttpErrorResponse) => {
        expect(error).toBeTruthy();
        expect(error.message).toBe('404 NOT FOUND');
      }
    );
  });

  it('Testing Data using ID Function', () => {
    const data = {
      id: 1,
      mobile: 1234567890,
      points: 25,
      name: 'John Doe',
    };
    const dataReceived = service.fetchCustomerDataById(1);
    const mockRequest = httpMock.expectOne(environment.MOBILE_REWARDS_DATA);
    expect(mockRequest.request.method).toBe('GET');
    mockRequest.flush(data);
    httpMock.verify();
  });

  it('should call the updateRewardPoints', () => {
    spyOn(service['rewardPoints'], 'next');
    service.updateRewardPoints('100');

    expect(service['rewardPoints'].next).toHaveBeenCalled();
  });
});
