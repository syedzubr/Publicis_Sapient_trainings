import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { Observable, Subject } from 'rxjs';
import { Rewards } from './mobile-rewards.interface';

@Injectable({
  providedIn: 'root',
})
export class MobileRewardsService {
  private rewardPoints = new Subject();
  rewardPoints$ = this.rewardPoints.asObservable();

  constructor(private httpClient: HttpClient) {}

  fetchCustomerData(): Observable<Rewards[]> {
    return this.httpClient.get<Rewards[]>(environment.MOBILE_REWARDS_DATA);
  }

  fetchCustomerDataById(id: number): Rewards[] | [] {
    let tempData: Rewards[] = [];
    this.httpClient
      .get<Rewards[]>(environment.MOBILE_REWARDS_DATA)
      .subscribe((data) => {
        tempData = data;
      });
    const dataToBeSent = tempData;
    if (dataToBeSent) {
      return dataToBeSent;
    }
    return [];
  }

  public updateRewardPoints(points): void {
    this.rewardPoints.next(points);
  }
}
