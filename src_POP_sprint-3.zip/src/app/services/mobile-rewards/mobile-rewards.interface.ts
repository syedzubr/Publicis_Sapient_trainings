export interface Rewards {
  id: number;
  mobile: number;
  points: number;
  name: string;
}
