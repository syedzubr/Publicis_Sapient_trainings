import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { environment } from 'environments/environment';
import { HardwareCheck } from './hardware-check.interface';

@Injectable({
  providedIn: 'root',
})
export class InitialCheckService {
  private hardwareData: HardwareCheck = {
    printer: false,
    scanner: false,
    barCodeReader: false,
  };

  constructor(private httpClient: HttpClient) {}

  getHardwareData(): Observable<HardwareCheck> {
    return this.httpClient.get<HardwareCheck>(environment.HARDWARE_DATA).pipe(
      tap((payload) => {
        this.hardwareData = payload;
      })
    );
  }

  initCheck(): boolean {
    for (const isWorking of Object.values(this.hardwareData)) {
      if (!isWorking) {
        return false;
      }
    }
    return true;
  }
  setHardwareData(data: HardwareCheck): void {
    this.hardwareData = data;
  }
}
