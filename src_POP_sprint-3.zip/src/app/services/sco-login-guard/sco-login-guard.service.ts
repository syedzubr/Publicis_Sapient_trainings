import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ScoLoginGuardService {
  private forwardToCheckOut: boolean;

  set goToSelfCheckOut(goToSelfCheckOut: boolean) {
    this.forwardToCheckOut = goToSelfCheckOut;
  }

  get goToSelfCheckOut(): boolean {
    return this.forwardToCheckOut;
  }
}
