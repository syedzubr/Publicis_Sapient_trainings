import { PaymentSummaryComponent } from './payment-summary.component';
import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { ApplyCouponService } from 'app/services/apply-coupon/apply-coupon.service';
import { Product } from 'app/services/cart-table/product.interface';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CouponCode } from 'app/services/apply-coupon/coupon-code.interface';
import { skip } from 'rxjs/operators';
import { of } from 'rxjs';
import { Observable } from 'rxjs';




describe('PaymentSummaryComponent', () => {
  let component: PaymentSummaryComponent;
  let fixture: ComponentFixture<PaymentSummaryComponent>;
  let cartService: CartProductService;
  let couponService: ApplyCouponService;
  let product: Product[];
  let coupons: CouponCode[];
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [PaymentSummaryComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentSummaryComponent);
    component = fixture.componentInstance;
    cartService = TestBed.inject(CartProductService);
    couponService = TestBed.inject(ApplyCouponService);
    fixture.detectChanges();
    product = [
      {
        productId: 1,
        productName: 'Country fresh tomatoes, 500gms',
        price: 2.5,
        productUrl: 'assets/products/tomatoes.jpg',
        qty: 1,
        barcode: 123456789012,
        sku: 154397,
      },
      {
        productId: 2,
        productName: 'Fresh Avocado, 1pc',
        price: 0.75,
        productUrl: 'assets/products/avacado.jpg',
        qty: 3,
        barcode: 123456789022,
        sku: 154390,
      },
    ];
    coupons = [
      {
        couponCode: 55,
        discountPercent: 5,
      },
      {
        couponCode: 1010,
        discountPercent: 10,
      },
    ];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get total price', () => {
    cartService.products = product;
    fixture.detectChanges();
    cartService.nextTotalPrice();
    cartService.totalPrice.subscribe((price) => {
      expect(component.price).toBe(4.75);
    });
  });

  it('should get the discount', () => {
    couponService.coupon = coupons;
    fixture.detectChanges();
    couponService.updateDiscount(5);

    couponService.change.subscribe((discount) => {
      expect(component.temp).toBe(5);
    });
  });
});
