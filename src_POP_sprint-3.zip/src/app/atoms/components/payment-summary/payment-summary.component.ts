import { Component, OnInit, OnDestroy } from '@angular/core';
import { ApplyCouponService } from 'app/services/apply-coupon/apply-coupon.service';
import { CartProductService } from 'app/services/cart-table/cart-product.service';
import { Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-payment-summary',
  templateUrl: './payment-summary.component.html',
  styleUrls: ['./payment-summary.component.scss'],
})
export class PaymentSummaryComponent implements OnInit, OnDestroy {
  constructor(
    private productService: CartProductService,
    private couponService: ApplyCouponService
  ) {}
  price: number;
  temp: number;
  discount: number;
  dataSubscribed: Subscription;
  ngOnInit(): void {
    this.dataSubscribed = this.productService.totalPrice
      .pipe(
        tap(() => {
          this.couponService.change.subscribe((data) => {
            this.temp = data;
          });
        })
      )
      .subscribe((totalPrice) => {
        this.price = totalPrice;
        this.discount = (this.temp / 100) * this.price;
      });
  }

  ngOnDestroy(): void {
    this.dataSubscribed.unsubscribe();
  }
}
