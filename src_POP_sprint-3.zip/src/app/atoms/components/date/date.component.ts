import { TimerService } from 'app/services/timer/timer.service';
import { Component } from '@angular/core';

import { Observable } from 'rxjs';

@Component({
  selector: 'app-date',
  templateUrl: './date.component.html',
  styleUrls: ['./date.component.scss'],
})
export class DateComponent {
  timer: Observable<string>;

  constructor(private timerService: TimerService) {
    this.timer = this.timerService.getTimer();
  }
}
