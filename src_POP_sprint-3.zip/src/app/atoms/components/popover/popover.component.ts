import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-popover',
  templateUrl: './popover.component.html',
  styleUrls: ['./popover.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class PopoverComponent {
   constructor(private router: Router ) {}

  navigateToSelfCheckout(): void {
    if (this.router.url === '/payment' )
    {
      this.router.navigate(['/selfCheckout']);
    }
  }
}
