import {
  Component,
  ElementRef,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { fromEvent, Subscription } from 'rxjs';

@Component({
  selector: 'app-on-screen-keypad',
  templateUrl: './on-screen-keypad.component.html',
  styleUrls: ['./on-screen-keypad.component.scss'],
})
export class OnScreenKeypadComponent implements OnInit, OnDestroy {
  @Output() numberClicked = new EventEmitter();

  @ViewChild('keypadContainer', { static: true }) keypad: ElementRef;

  subscribedClick: Subscription;

  ngOnInit(): void {
    this.subscribedClick = fromEvent<MouseEvent>(
      this.keypad.nativeElement,
      'click'
    ).subscribe((event: MouseEvent) => {
      this.numberClicked.emit((event.target as Element).textContent);
    });
  }

  ngOnDestroy(): void {
    this.subscribedClick.unsubscribe();
  }
}
