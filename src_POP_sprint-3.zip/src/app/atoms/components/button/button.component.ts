import { ButtonType } from 'app/atoms/models/common.model';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
})
export class ButtonComponent {
  @Input() type: string;
  @Input() width: number;
  @Input() height: number;
  @Input() label: string;
  @Output() clicked: EventEmitter<void> = new EventEmitter();

  get button(): string {
    switch (this.type) {
      case ButtonType.PRIMARY_BUTTON:
        return ButtonType.PRIMARY_BUTTON;
      case ButtonType.SECONDARY_BUTTON:
        return ButtonType.SECONDARY_BUTTON;
      default:
        return '';
    }
  }

  click(): void {
    this.clicked.emit();
  }
}
