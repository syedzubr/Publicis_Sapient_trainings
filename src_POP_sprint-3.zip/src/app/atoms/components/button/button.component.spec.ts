import { ButtonComponent } from 'app/atoms/components/button/button.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';
import { ButtonType } from 'app/atoms/models/common.model';

describe('ButtonComponent', () => {
  let component: ButtonComponent;
  let fixture: ComponentFixture<ButtonComponent>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [ButtonComponent],
    });
    fixture = TestBed.createComponent(ButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should assign primary button value', () => {
    const btnType = ButtonType.PRIMARY_BUTTON;
    component.type = btnType;
    expect(component.button).toBe(btnType);
  });

  it('should assign secondary button value', () => {
    const btnType = ButtonType.SECONDARY_BUTTON;
    component.type = btnType;
    expect(component.button).toBe(btnType);
  });

  it('Should emit event on click', () => {
    spyOn(component.clicked, 'emit');
    const nativeElement = fixture.nativeElement;
    const mockButton = nativeElement.querySelector('button');
    mockButton.dispatchEvent(new Event('click'));
    fixture.detectChanges();
    expect(component.clicked.emit).toHaveBeenCalled();
  });
});
