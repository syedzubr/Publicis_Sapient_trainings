import { AppService } from './app.service';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { NavigationStart, Router } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'PoP-Store';
  dummy = 'new';
  isOtherPage: boolean;
  urlString: string;
  statusSubscription: Subscription;
  subscription: Subscription;

  constructor(
    private translate: TranslateService,
    private appService: AppService,
    private router: Router
  ) {
    this.translate.setDefaultLang('en');
  }

  ngOnInit(): void {
    this.statusSubscription = this.appService.statusSubject$.subscribe(
      (payload) => {
        this.isOtherPage = payload;
      }
    );
    this.router.events
      .pipe(
        filter((event): event is NavigationStart => {
          if (event['url'] === '/initialization' || event['url'] === '/') {
            return false;
          }
          return event instanceof NavigationStart;
        })
      )
      .subscribe((event) => {
        if (event.id === 1) {
          this.router.navigate(['/login']);
        }
      });
  }

  ngOnDestroy(): void {
    this.statusSubscription.unsubscribe();
    window.sessionStorage.clear();
  }
}
