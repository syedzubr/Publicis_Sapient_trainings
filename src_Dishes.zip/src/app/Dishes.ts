export interface Dishes {
    id:number,
    name : string,
    calories: number,
    price : number,
    rating: number
}