import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Dishes } from '../Dishes';
import { DishesService } from '../dishes.service';

@Component({
  selector: 'app-dish-details',
  templateUrl: './dish-details.component.html',
  styleUrls: ['./dish-details.component.css']
})
export class DishDetailsComponent implements OnInit {

  // dish: number;
  dishServiceSubscription: any;
  Dish: Dishes;
  // Dish: Dishes = {
  //   id : 2,
  //   name : "asd",
  //   calories: 123,
  //   price : 1000,
  //   rating: 5
  // }

  constructor(private dishService:DishesService) { }

  ngOnInit(): void {
    this.dishServiceSubscription = this.dishService
                                      .dishChanged
                                      .subscribe(dishPlate => {this.Dish = dishPlate;console.log(this.Dish,"here in main")});

  // this.dishService
  // .fetchDishById(this.dish)
  // .subscribe(data => {console.log(data); this.Dish = data});
  // this.dishService.fetchDishById(this.dish);
  }

  // dishId: number = 1;
  // private dishSubject = new BehaviorSubject(this.dish);
  // dishChanged = this.dishSubject.asObservable().subscribe(dishId => this.dish = dishId,
  //   err => console.log("error"),
  //   () => this.dishService.fetchDishById(this.dish).subscribe(data => {console.log("Inside bro here"); this.Dish = data}));
  
  ngOnDestroy(): void {
    this.dishServiceSubscription.unsubscribe();
  }

}
