import { Component, OnInit } from '@angular/core';
import { DishesService } from '../dishes.service';
import { Dishes } from '../Dishes';


@Component({
  selector: 'app-dish',
  templateUrl: './dish.component.html',
  styleUrls: ['./dish.component.css']
})
export class DishComponent implements OnInit {

  dishes:Dishes[] = []
  constructor(private dish:DishesService) { }

  ngOnInit(): void {
    this.dish
    .fetchAllDishes()
    .subscribe(data => {console.log(data); this.dishes = data}, 
               error => console.log("The courses were not fetched"),
               () => console.log("completed "));
  }

  pushData(dish:Dishes){
    console.log("--------------",dish);
    this.dish.pushData(dish);
  }
}
