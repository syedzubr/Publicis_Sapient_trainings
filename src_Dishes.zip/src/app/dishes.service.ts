import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Dishes } from './Dishes';

@Injectable({
  providedIn: 'root'
})
export class DishesService {

  dishes:Dishes[] = []
  dish: Dishes | any = [];

  constructor(private httpClient: HttpClient){console.log("Inside the constructor of the Dishes Service ....")}

  fetchAllDishes(): Observable<Dishes[]>{
    return this.httpClient
        .get<Dishes[]>(environment.API_URL)
  }

  
  private dishSubject = new BehaviorSubject(this.dish);
  dishChanged = this.dishSubject.asObservable();


  fetchDishById(id:number): Observable<Dishes>{
    return this.httpClient.get<Dishes>(environment.API_URL+id)
  }

  pushData(di:Dishes){
    this.dish = di;
    this.dishSubject.next(this.dish);
  }
  

}
