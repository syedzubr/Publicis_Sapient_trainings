# Inventory Management 

A business app for automated record-keeping and maintenance of the corporate computer equipment. The app allows to keep records of the users and devices as well as to create various reports.